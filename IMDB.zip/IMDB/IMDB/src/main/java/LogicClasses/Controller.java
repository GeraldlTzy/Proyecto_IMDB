/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import Connect.ConnectDB;
import static Connect.ConnectDB.getConnection;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Controller {
    private static Controller instance = null;
    private Connection conn;
    private Controller(){
        conn = ConnectDB.getConnection();
    }
    
    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }
    
    public Map<Integer,String> getNationalities() {
        try {
            CallableStatement stmt = conn.prepareCall("{?= call pkgBasic.getNationalities}");
            stmt.registerOutParameter(1, OracleTypes.CURSOR);
            
            stmt.executeQuery();
            ResultSet r = (ResultSet) stmt.getObject(1);
            Map<Integer,String> nationalities = new HashMap<Integer,String>();
            while (r.next()) {
                nationalities.put(r.getInt("idNationality"), r.getString("name"));
            }
            return nationalities;
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    public static void insertUser (int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID, int nationality, boolean hasImage)throws FileNotFoundException, IOException, Exception{
        try {
            Person.insertUser(sex, firstName, secondName, firstSurname, secondSurname,
                    birthdate, image, username, identification, phoneNumber, email,
                    password, typeOfID, nationality, hasImage);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
       public static ArrayList<String> validUser (String username, String password){
        try {
            return Person.validUser(username, password);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
      
    public void insertNationality(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertNationality(?)}");
        sql.setString(1, name);
        sql.execute();
    }
}
