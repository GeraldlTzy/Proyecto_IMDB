/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import javax.swing.Icon;

public class ImgNText {
    private String text;
    private Icon img;
    
    public ImgNText(String text, Icon img) {
        this.text = text; this.img = img;
    }

    public String getText() {
        return text;
    }

    public Icon getImg() {
        return img;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setImg(Icon img) {
        this.img = img;
    }
    
}
