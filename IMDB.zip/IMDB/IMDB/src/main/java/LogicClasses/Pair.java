/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

/**
 *
 * @author kakas
 */
public class Pair<F, S> {
    private F first;
    private S second;
    public Pair(F first, S second){
        this.first = first;
        this.second = second;
    }
    public void setFirst(F first) {this.first = first;}
    public void setSecond(S second){this.second = second;}
    public F getFirst() {return first;}
    public S getSecond(){return second;}
    public boolean equals (Pair<F, S> other){
        if (other.first != this.first) return false;
        if (other.second != this.second) return false;
        return true;
    }
}
