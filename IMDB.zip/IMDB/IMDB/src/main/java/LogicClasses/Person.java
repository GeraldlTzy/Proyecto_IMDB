package LogicClasses;

import Connect.ConnectDB;
import static Connect.ConnectDB.getConnection;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Person {
    
    public static int[] checkRegister(String username, String email, int phone)throws SQLException {
        
        Connection con= ConnectDB.getConnection();
        CallableStatement stmt = con.prepareCall("?= call pkgBasic.validateRegister(?,?,?)}");
        stmt.registerOutParameter(1, OracleTypes.CURSOR);
        stmt.setString(2, username);
        stmt.setString(3,email);
        stmt.setInt(4,phone);
        stmt.executeQuery();
        ResultSet rs = (ResultSet) stmt.getObject(1);
        int[] response = new int[2];
        response[0] = rs.getInt("usernamesCount");
        response[1] = rs.getInt("emailsCount");
        response[2] = rs.getInt("phoneNumber");
        return response;
    }
    
    public static void insertUser(Integer sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID, int nationality, boolean hasImage) throws FileNotFoundException, IOException, Exception {
        
        try {
            Connection con= ConnectDB.getConnection();
            //CAMBIAR EL ATRIBUTO DE PHOTO
            CallableStatement stmt = con.prepareCall("{ call pkgEnd_user.insertUser(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'), ?,?,?,?,?,?,?,?)}");
            stmt.setInt(1, sex);
            stmt.setString(2, firstName);
            stmt.setString(3, secondName);
            stmt.setString(4, firstSurname);
            stmt.setString(5, secondSurname);
            stmt.setString(6, birthdate);
            if (hasImage) {
                stmt.setBytes(7,image);
            } else {
                FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
                stmt.setBytes(7,image);
            }
            stmt.setString(8, username);
            stmt.setInt(9, identification);
            stmt.setInt(10, phoneNumber);
            stmt.setString(11, email);
            stmt.setString(12, password);
            stmt.setInt(13, typeOfID);
            stmt.setInt(14, nationality);
            stmt.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    public static void insertAdmin(int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID) throws SQLException {
        
        Connection conn = ConnectDB.getConnection();
        
        CallableStatement stmt = conn.prepareCall("{ call pkgAdmin.insertAdmin(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?,?)}");
        stmt.setInt(1, sex);
        stmt.setString(2, firstName);
        stmt.setString(3, secondName);
        stmt.setString(4, firstSurname);
        stmt.setString(5, secondSurname);
        stmt.setString(6, birthdate);
        stmt.setString(7, username);
        stmt.setInt(8, identification);
        stmt.setInt(9, phoneNumber);
        stmt.setString(10, email);
        stmt.setString(11, password);
        stmt.setInt(12, typeOfID);
        stmt.execute();
    }
    
    public static ArrayList<String> getUserInfo() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call pkgEnd_user.getInfo(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<String> userInfo = new ArrayList<>();
        
        userInfo.add(rs.getString("NombreColumna"));
        userInfo.add(Integer.toString(rs.getInt("idUser")));
        userInfo.add("Hola");
        
        return userInfo;
    }
    public static ArrayList<String> validUser(String username, String password) throws SQLException {
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getSystemUserInfo(?, ?)}");
        
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.setString(2, username);
        sql.setString(3, password);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        //for (int i = 0; i < 5; i++){
        ArrayList<String> userInfo = new ArrayList();
        //}
        while (rs.next()){
            if (rs.getInt(1) != 2) {
                return null;
            }
            System.out.println("Valor " + 1 + ": " + rs.getString(1));
            System.out.println("Valor " + 1 + ": " + rs.getString(2));
            System.out.println("Valor " + 1 + ": " + rs.getString(3));
            
            userInfo.add(rs.getString(1));
            userInfo.add(rs.getString(2));
        }
        
        
        //return (Integer) sql.getObject(1);
        return userInfo;
    }
}
