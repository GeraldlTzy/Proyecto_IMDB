/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*package LogicClasses;

import Connect.ConnectDB;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import oracle.jdbc.OracleTypes;


public class Product {
    private static Connection conn = ConnectDB.getConnection();
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    
}*/


