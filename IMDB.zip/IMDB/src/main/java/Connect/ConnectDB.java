package Connect;

import LogicClasses.Episode;
import LogicClasses.Pair;
import LogicClasses.Participant;
import LogicClasses.Product;
import LogicClasses.Triple;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

public class ConnectDB {
    private static Connection conn;
    private static ConnectDB connect;
    
    public ConnectDB(){
        try {
            String host = "jdbc:oracle:thin:@localhost:1521:BD1GERALD";
            String uName = "su";
            String uPass = "su";
            
            conn = DriverManager.getConnection(host, uName, uPass);
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public static ConnectDB getObject(){
        if (connect == null) {
            connect = new ConnectDB();
        }
        return connect;
    }
    /**************************************************************************/
    /*********************ALL BASIC INSERTS FOR GENERAL THINGS*****************/
    public void insertNationality(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertNationality(?)}");
        sql.setString(1, name);
        sql.execute();
    }
     public void insertCountry(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCountry(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertCity(String name, Integer idCountry) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCity(?, ?)}");
        sql.setString(1, name);
        sql.setInt(2, idCountry);
        sql.execute();
    }
    public void insertTypeIdent(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeIdent(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertTypeParticipant(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeParticipant(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertTypeProduct(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeProduct(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertCatalog(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCatalog(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertPlatform(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertPlatform(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertSex(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertSex(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    /**************************************************************************/
    /**************************ALL GETS FOR GENERAL OBJECT
     * @throws java.sql.SQLExceptionS********************/
    public ArrayList<ArrayList<Pair<Integer,String>>> getInfoRegister() throws SQLException {
        
        CallableStatement sql = conn.prepareCall("call pkgBasic.getInfoRegister(?,?,?)");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs1 = (ResultSet) sql.getObject(1);
        ResultSet rs2 = (ResultSet) sql.getObject(2);
        ResultSet rs3 = (ResultSet) sql.getObject(3);
        ArrayList<ArrayList<Pair<Integer,String>>> information = new ArrayList<ArrayList<Pair<Integer,String>>>();

        ArrayList<Pair<Integer,String>> sexes = new ArrayList<Pair<Integer,String>>();
        ArrayList<Pair<Integer,String>> typesOfId = new ArrayList<Pair<Integer,String>>();
        ArrayList<Pair<Integer,String>> nationalities = new ArrayList<Pair<Integer,String>>();

        //Addition of sexes
        Integer id;
        String name;
        while (rs1.next()) {
            id = rs1.getInt("idSex");
            name = rs1.getString("sexname");
            Pair<Integer,String> sex = new Pair<Integer,String>(id, name);
            sexes.add(sex);
        }
        //Adittion of types of identification
        while (rs2.next()) {
            id = rs2.getInt("idTypeIdent");
            
            name = rs2.getString("nameTypeIdent");
            
            Pair<Integer,String> typeOfIdent = new Pair<Integer,String>(id, name);
            typesOfId.add(typeOfIdent);
        }
        while (rs3.next()) {
            id = rs3.getInt("idNationality");
            name = rs3.getString("name");
            Pair<Integer,String> nationality = new Pair<Integer,String>(id, name);
            nationalities.add(nationality);
        }
        information.add(sexes);
        information.add(typesOfId);
        information.add(nationalities);
        return information;
        
    }
    public ArrayList<ArrayList<Pair<Integer, String>>> getInfoInsertParticipant (Integer id) throws SQLException {
        ArrayList<ArrayList<Pair<Integer, String>>> data = new ArrayList<>();
        
        ArrayList<Pair<Integer, String>> nationalities = new ArrayList<>();
        ArrayList<Pair<Integer, String>> cities = new ArrayList<>();
        
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getInfoInsertParticipant(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        if (id != null) sql.setInt(2, id);
        else sql.setNull(2, OracleTypes.NULL);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        
        while (rs.next()){
            Pair<Integer, String> object = new Pair(rs.getInt(1), rs.getString(2));
            if (rs.getString(3).equals("Nationality")){
                nationalities.add(object);
            } else if (rs.getString(3).equals("Sex")){
                //sexs.add(object);
            } else {
                cities.add(object);
            }
        }
        data.add(nationalities);
        data.add(cities);
        return data;
    }
    /**************************************************************************/
    /****************************ALL FUNCTIONS ABOUT PERSON********************/
//private static Connection conn = ConnectDB.getConnection();
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    /*private Person(){
        conn = ConnectDB.getConnection();
    }*/
    public int[] checkRegister(String username, String email, long phone)throws SQLException {
        CallableStatement stmt = conn.prepareCall("{?= call pkgBasic.validateRegister(?,?,?)}");
        stmt.registerOutParameter(1, OracleTypes.CURSOR);
        stmt.setString(2, username);
        stmt.setString(3,email);
        stmt.setLong(4,phone);
        stmt.executeQuery();
        ResultSet rs = (ResultSet) stmt.getObject(1);
        int response [] = new int[3];
        rs.next();
        response[0] = rs.getInt("usernamesCount");
        response[1] = rs.getInt("emailsCount");
        response[2] = rs.getInt("phonesCount");
        return response;
    }
    public static void insertUser(Integer sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, long identification, long phoneNumber, 
            String email, String password, int typeOfID, int nationality, boolean hasImage) throws FileNotFoundException, IOException, Exception {
        try {
            //CAMBIAR EL ATRIBUTO DE PHOTO
            CallableStatement stmt = conn.prepareCall("{ call pkgEnd_user.insertUser(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'), ?,?,?,?,?,?,?,?)}");
            stmt.setInt(1, sex);
            stmt.setString(2, firstName);
            stmt.setString(3, secondName);
            stmt.setString(4, firstSurname);
            stmt.setString(5, secondSurname);
            stmt.setString(6, birthdate);
            if (hasImage) {
                stmt.setBytes(7,image);
            } else {
                FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
                stmt.setBytes(7,image);
            }
            stmt.setString(8, username);
            stmt.setLong(9, identification);
            stmt.setLong(10, phoneNumber);
            stmt.setString(11, email);
            stmt.setString(12, password);
            stmt.setInt(13, typeOfID);
            stmt.setInt(14, nationality);
            stmt.execute();
        } catch (SQLException ex) {
            throw ex;
        }
    }
    
    public static void insertAdmin(int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID) throws SQLException {
        
        //Connection conn = ConnectDB.getConnection();
        
        CallableStatement stmt = conn.prepareCall("{ call pkgAdmin.insertAdmin(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?,?)}");
        stmt.setInt(1, sex);
        stmt.setString(2, firstName);
        stmt.setString(3, secondName);
        stmt.setString(4, firstSurname);
        stmt.setString(5, secondSurname);
        stmt.setString(6, birthdate);
        stmt.setString(7, username);
        stmt.setInt(8, identification);
        stmt.setInt(9, phoneNumber);
        stmt.setString(10, email);
        stmt.setString(11, password);
        stmt.setInt(12, typeOfID);
        stmt.execute();
    }
    
    public int insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws SQLException, Exception
        {
    
        CallableStatement sql = conn.prepareCall("{ call pkgParticipant.insertParticipant(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?,?)}");
        sql.setInt(1, pSex);
        sql.setString(2, pFirstName);
        sql.setString(3, pSecondName);
        sql.setString(4, pFirstSurname);
        sql.setString(5, pSecondSurname);
        sql.setString(6, pDateBirth);
        sql.setInt(7, pCity);
        sql.setString(8, pBiography);
        sql.setInt(9, pHeight);
        sql.setString(10, pTrivia);
        sql.setBytes(11, pPhoto);
        sql.registerOutParameter(12, OracleTypes.NUMBER);
        sql.execute();
        return sql.getInt(12);
    }
    public void updateParticipant (int pId, Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws Exception {
        
        CallableStatement sql = conn.prepareCall("{ call pkgParticipant.updateParticipant(?,?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?)}");
        sql.setInt(1, pId);
        sql.setInt(2, pSex);
        sql.setString(3, pFirstName);
        sql.setString(4, pSecondName);
        sql.setString(5, pFirstSurname);
        sql.setString(6, pSecondSurname);
        sql.setString(7, pDateBirth);
        sql.setInt(8, pCity);
        sql.setString(9, pBiography);
        sql.setInt(10, pHeight);
        sql.setString(11, pTrivia);
        sql.setBytes(12, pPhoto);
        sql.execute();
    }
    
    public void addNationalityToPerson(int idPerson, int idNationality) throws SQLException{
        CallableStatement sql = conn.prepareCall("{ call pkgBasic.insertNationalityPerson(?,?)}");
        sql.setInt(1, idNationality);
        sql.setInt(2, idPerson);
        sql.execute();
    }
    
    public static ArrayList<String> getUserInfo() throws SQLException{
        //Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call pkgEnd_user.getInfo(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<String> userInfo = new ArrayList<>();
        
        userInfo.add(rs.getString("NombreColumna"));
        userInfo.add(Integer.toString(rs.getInt("idUser")));
        userInfo.add("Hola");
        
        return userInfo;
    }
    public static Pair<ArrayList<String>,byte[]> validUser(String username, String password) throws SQLException {
        //Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getSystemUserInfo(?, ?)}");
        
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.setString(2, username);
        sql.setString(3, password);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        //for (int i = 0; i < 5; i++){
        Pair<ArrayList<String>,byte[]> userInfo;
        ArrayList<String> infoList = new ArrayList<String>();
        //}
        if (rs == null) {
            return null;
        }
        rs.next();
        infoList.add(rs.getString(1));
        infoList.add(rs.getString(2));
        infoList.add(rs.getString(3));
        infoList.add(rs.getString(4));
        infoList.add(rs.getString(5));
        byte[] image = rs.getBytes(6);
        infoList.add(rs.getString(7));
        infoList.add(rs.getString(8));
        infoList.add(rs.getString(9));
        infoList.add(rs.getString(10));
               
        userInfo = new Pair<>(infoList,image);
        return userInfo;
    }
        
    public static ArrayList<Participant> getParticipants(Integer id) throws SQLException {
        ArrayList<Participant> participants = new ArrayList();
        
        CallableStatement sql = conn.prepareCall("{call pkgParticipant.getParticipant(?, ?, ?)}");
        
        
        sql.setInt(1, id);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(2);
        ResultSet rsNat = (ResultSet) sql.getObject(3);
        while (rs.next()){
            Participant participant;
            
            int idParticipant = rs.getInt(1);
            String firstName = rs.getString(2);
            String secondName = rs.getString(3);
            String firstSurname = rs.getString(4);
            String secondSurname = rs.getString(5);
            Date datebirth = rs.getDate(6);
            String date = formatDate.format(datebirth);
            Blob blob = rs.getBlob(7);
            byte[] photo = blob.getBytes(1, (int) blob.length());
            int idCity = rs.getInt(8);
            String biography = rs.getString(9);
            int height = rs.getInt(10);
            String trivia = rs.getString(11);
            int idSex = rs.getInt(12);
            
            participant = new Participant(idParticipant, firstName, secondName, firstSurname, 
                    secondSurname, date, photo, idCity, biography, height, trivia, idSex);
            while (rsNat.next()){
                participant.addNationality(rsNat.getInt(1));
            }
            participants.add(participant);
        }
        return participants;
    }
    public ArrayList<Triple<Integer, String, byte[]>> getInfoParticipants() throws SQLException, FileNotFoundException, IOException{
        CallableStatement sql = conn.prepareCall("{? = call pkgParticipant.getInfoParticipants}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Triple<Integer, String, byte[]>> participants = new ArrayList<>();
        Triple<Integer, String, byte[]> participant;
        int idParticipant = -1;
        while (rs.next()) {
            if (rs.getInt(1) != idParticipant) {
                idParticipant = rs.getInt(1);
                String name = rs.getString(2);
                Blob blob = rs.getBlob(3);
                byte[] photo;
                if (blob != null) {
                    photo = blob.getBytes(1, (int) blob.length());
                } else {
                    FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                    photo = new byte[fis.available()];
                    fis.read(photo);
                    fis.close();
                }
                participant = new Triple<>(idParticipant, name, photo);
                participants.add(participant);
            }
        }
        return participants;
    }
    /***************************************************************************/
    //Cambiar para que las nacionalidades sean un arreglo
    public Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String>>> getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgBasic.getInfoCreationProduct(?, ?, ?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rsParticipants = (ResultSet) sql.getObject(1);
        ResultSet rsTypeParticipants = (ResultSet) sql.getObject(2);
        ResultSet rsTypeProducts = (ResultSet) sql.getObject(3);
        /**********************************************************************/
        ArrayList<Pair<byte[], String>> participants = new ArrayList<>();
        ArrayList<String[]> typeParticipants = new ArrayList<>();
        ArrayList<String[]> typeProducts = new ArrayList<>();
        Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String>>> data;

        /**********************************************************************/
        while (rsParticipants.next()){
            
            Pair<byte[], String> participant;
            Blob blob = rsParticipants.getBlob(3);
            byte[] blobBytes = blob.getBytes(1, (int) blob.length());
            participant = new Pair<>(blobBytes, rsParticipants.getString(2));
            participant.setId(rsParticipants.getInt(1));
            
            participants.add(participant);
        }
        while (rsTypeParticipants.next()){
            String[] typeParticipant = new String[2];
            typeParticipant[0] = rsTypeParticipants.getString(1);
            typeParticipant[1] = rsTypeParticipants.getString(2);
            typeParticipants.add(typeParticipant);
        }
        while (rsTypeProducts.next()) {
            String[] typeProduct = new String[2];
            typeProduct[0] = rsTypeProducts.getString(1);
            typeProduct[1] = rsTypeProducts.getString(2);
            typeProducts.add(typeProduct);
        }
        /**********************************************************************/
        data = new Triple<>(typeParticipants, typeProducts, participants);
        return data;
    }
    public Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgProduct.insertProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idTypeProduct);
        sql.setInt(2, releaseYear);
        sql.setString(3, title);
        sql.setInt(4, duration);
        sql.setString(5, synopsis);
        sql.setString(6, trailer);
        sql.setInt(7, price);
        sql.registerOutParameter(8, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdProduct = sql.getInt(8);
        System.out.println(""+rsIdProduct);
        return rsIdProduct;
    }
    public void updateProduct(Integer idProduct, Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgProduct.updateProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idProduct);
        sql.setInt(2, idTypeProduct);
        sql.setInt(3, releaseYear);
        sql.setString(4, title);
        sql.setInt(5, duration);
        sql.setString(6, synopsis);
        sql.setString(7, trailer);
        sql.setInt(8, price);
        sql.execute();
    }
    /**************************************************************************/
    /*PROCEDURE addParticipant(pIdProduct IN NUMBER, pIdParticipant IN NUMBER, pRol IN NUMBER);
    PROCEDURE addSeason(pIdProduct IN NUMBER, pNumberSeason IN NUMBER, pDuration IN NUMBER);
    PROCEDURE addEpisode(pIdSeason IN NUMBER,pNumberEpisode IN NUMBER, pName IN VARCHAR2,
    pDuration IN NUMBER);
    PROCEDURE addPhoto(pIdProduct IN NUMBER, pImage IN BLOB);*/
    public void addParticipant(Integer pIdProduct, Integer pIdParticipant,
            Integer pRol) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addParticipant(?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdParticipant);
        sql.setInt(3, pRol);
        sql.execute();
    }
    public void removeParticipantToProduct(int idProduct, int idParticipant) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call pkgProduct.deleteParticipant(?, ?)}");
        sql.setInt(1, idProduct);
        sql.setInt(2, idParticipant);
        sql.execute();
    }
    public Integer addSeason(Integer pIdProduct, Integer pNumberSeason,
            Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addSeason(?, ?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pNumberSeason);
        sql.setInt(3, pDuration);
        sql.registerOutParameter(4, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdSeason = sql.getInt(4);
        return rsIdSeason;
    }
     public void removeSeason(int pIdSeason) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call pkgProduct.removeSeason(?)}");
        sql.setInt(1, pIdSeason);
        sql.execute();
    }
    
    public void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addEpisode(?, ?, ?, ?)}");
        sql.setInt(1, pIdSeason);
        sql.setInt(2, pNumberEpisode);
        sql.setString(3, pName);
        sql.setInt(4, pDuration);
        sql.execute();
    }
    public void removeEpisode(int idEpisode) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call pkgProduct.removeEpisode(?)}");
        sql.setInt(1, idEpisode);
        sql.execute();
    }
    public void addPhoto(int pIdProduct, byte[] pImage) throws SQLException, Exception {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addPhoto(?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setBytes(2, pImage);
        sql.execute();
    }
    
    public void removePhoto(int idImage) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call pkgProduct.removePhoto(?)}");
        sql.setInt(1, idImage);
        sql.execute();
    }
    
    public ArrayList<Triple<Integer, String, byte[]>> getProducts() throws SQLException, FileNotFoundException, IOException{
        CallableStatement sql = conn.prepareCall("{? = call pkgProduct.getProducts}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Triple<Integer, String, byte[]>> products = new ArrayList<>();
        Triple<Integer, String, byte[]> product;
        int idProduct = -1;
        while (rs.next()) {
            if (rs.getInt(1) != idProduct) {
                idProduct = rs.getInt(1);
                String title = rs.getString(2);
                Blob blob = rs.getBlob(3);
                byte[] blobBytes;
                if (blob != null) {
                    blobBytes = blob.getBytes(1, (int) blob.length());
                } else {
                    FileInputStream fis = new FileInputStream("DefaultImageProduct.png");
                    blobBytes = new byte[fis.available()];
                    fis.read(blobBytes);
                    fis.close();
                }
                product = new Triple<>(idProduct, title, blobBytes);
                products.add(product);
            }
        }
        return products;
        
    }
    public Product getProduct(int pIdProduct) throws SQLException, FileNotFoundException, IOException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.getProductInfo(?, ?, ?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(4, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(5, OracleTypes.REF_CURSOR);
        sql.execute();
        /**********************************************************************/
        ResultSet rsInfoProduct = (ResultSet) sql.getObject(2);
        ResultSet rsParticipantsProduct = (ResultSet) sql.getObject(3);
        ResultSet rsSeasonsProduct = (ResultSet) sql.getObject(4);
        ResultSet rsImagesProduct = (ResultSet) sql.getObject(5);
        /**********************************************************************/
        /*********************Return Variables*********************************/
        /*Extract basic information about products*/
        Product product = null;
        while (rsInfoProduct.next()) {
            product = new Product(rsInfoProduct.getInt(1), rsInfoProduct.getInt(2),
            rsInfoProduct.getInt(3), rsInfoProduct.getString(4), rsInfoProduct.getInt(5),
            rsInfoProduct.getString(6), rsInfoProduct.getString(7), rsInfoProduct.getInt(8));
        }
        /*************************Particpant x product*************************/
        while (rsParticipantsProduct.next()) {
            String rol = rsParticipantsProduct.getString(4);
            String firstName = rsParticipantsProduct.getString(2);
            String firstSurname = rsParticipantsProduct.getString(3);
            String participantInformation = rol + " - " + firstName + " " + firstSurname ;
            int id = rsParticipantsProduct.getInt(1);
            product.addParticipant(id, participantInformation);
        }
        /********************Get seasons with episodes*************************/
        String infoSeason[];
        int lastId = -1;
        while (rsSeasonsProduct.next()) {
            /*Season atributes*/
            int idSeason = rsSeasonsProduct.getInt(1);
            if (idSeason == lastId) {
                addEpisodeToSeason(rsSeasonsProduct, product);
            } else {
                infoSeason = new String[2];
                infoSeason[0] = rsSeasonsProduct.getString(2);
                infoSeason[1] = rsSeasonsProduct.getString(3);
                product.addSeason(idSeason, infoSeason);
                addEpisodeToSeason(rsSeasonsProduct, product);
                lastId = idSeason;
            }
        }
        /*****************************Images***********************************/
        while (rsImagesProduct.next()){
            int idImage = rsImagesProduct.getInt(1);
            Blob blob = rsImagesProduct.getBlob(2);
            byte[] image;
            if (blob != null) {
                image = blob.getBytes(1, (int) blob.length());
                product.addImage(idImage, image);
            } else {
                FileInputStream fis = new FileInputStream("DefaultImageProduct.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
                product.addImage(idImage, image);
            }
            
        }
        /**********************************************************************/
        return product;
    }
    private void addEpisodeToSeason(ResultSet rs, Product product) throws SQLException {
        Integer id = rs.getInt(4);
        int idSeason = rs.getInt(1);
        if (id == 0) {
        } else {
            String[] infoEpisode = new String[4];
            infoEpisode[0] = rs.getString(4);
            infoEpisode[1] = rs.getString(5);
            infoEpisode[2] = rs.getString(6);
            infoEpisode[3] = rs.getString(7);
            product.addEpisodes(idSeason, infoEpisode);
            
            /*LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>> seasons = product.getSeasons();
            seasons.forEach((k,v) -> {
                
                
                //modelListAddedSeasons.addElement(v.getFirst()[0] + " Duración: " + v.getFirst()[1]);
            for (String[] episode : v.getSecond()) {
                Episode epi = new Episode(Integer.parseInt(episode[0]), k,
                Integer.parseInt(episode[3]), episode[2], Integer.parseInt(episode[1]));
                System.out.println("Episodio name: " + epi.getInfo());

            }
                
            });*/
        }
    }
    
}
