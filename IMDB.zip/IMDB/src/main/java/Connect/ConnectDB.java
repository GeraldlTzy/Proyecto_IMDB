package Connect;

import LogicClasses.Binnacle;
import LogicClasses.DataCreation;
import LogicClasses.Pair;
import LogicClasses.Participant;
import LogicClasses.Product;
import LogicClasses.Stats;
import LogicClasses.Triple;
import LogicClasses.User;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

public class ConnectDB {
    private static Connection conn;
    private static ConnectDB connect;
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    private static SimpleDateFormat mariaFormatDate = new SimpleDateFormat("yyyy-MM-dd");
    public ConnectDB(){
        try {
            String host = "jdbc:mariadb://localhost:3307/su";
            String uName = "su";
            String uPass = "su";
            
            conn = DriverManager.getConnection(host, uName, uPass);
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public static ConnectDB getObject(){
        if (connect == null) {
            connect = new ConnectDB();
        }
        return connect;
    }
    /**************************************************************************/
    /*********************ALL BASIC INSERTS FOR GENERAL THINGS*****************/
    
    /**************************************************************************/
    /**************************ALL GETS FOR GENERAL OBJECT
     * @return 
     * @throws java.sql.SQLException********************/
    public Stats getStatistics() throws SQLException {
        CallableStatement sql = conn.prepareCall("call getProductStatistics()");
        ResultSet rs1 = sql.executeQuery();
        
        sql = conn.prepareCall("call getUsersStatisticsByAge()");
        ResultSet rs2 = sql.executeQuery();
        
        sql = conn.prepareCall("call getUsersStatisticsBySex()");
        ResultSet rs3 = sql.executeQuery();
        
        sql = conn.prepareCall("call getProductsXGenre()");
        ResultSet rs4 = sql.executeQuery();
        //Products statistics
        Stats stats = new Stats();
        Map<String,Float[]> productsStats = new HashMap<>();
        while(rs1.next()) {
            productsStats.put(rs1.getString(1), new Float[]{rs1.getFloat(2),rs1.getFloat(3)});
        }
        stats.setProductsStats(productsStats);
        
        //Users information
        List<User> users = new ArrayList<>();
        User user;
        while (rs2.next()) {
            Date datebirth = rs2.getDate(2);
            String date = formatDate.format(datebirth);
            user = new User();
            user.UpdateUser(rs2.getString(1),date,rs2.getInt(3),rs2.getInt(4));
            users.add(user);
        }
        stats.setUsers(users);
        
        //userStats
        Map<String,Integer> usersBySex = new HashMap<>();
        while (rs3.next()) {
            usersBySex.put(rs3.getString(1),rs3.getInt(2));
        }
        stats.setUsersBySex(usersBySex);
        //products
        ArrayList<Pair<Integer,Product>> products = new ArrayList<>();
        Pair<Integer,Product> productPair = new Pair<>(0,null);
        Product product = null;
        int idProduct = -1;
        ArrayList<String> genres = new ArrayList<>();
        while (rs4.next()) {
            if (rs4.getInt(3)!=idProduct) {
                idProduct = rs4.getInt(3);
                product = new Product(idProduct,rs4.getString(1));
                genres = new ArrayList<>();
                product.setStatsGenres(genres);
                products.add(new Pair<>(idProduct,product));
                genres.add(rs4.getString(2));
            } else {
                genres.add(rs4.getString(2));
            }
        }
        stats.setProducts(products);
        return stats;
    }
    
    public ArrayList<ArrayList<Pair<Integer,String>>> getInfoRegister() throws SQLException {
        
        CallableStatement sql;
        sql = conn.prepareCall("call getSexs()");
        ResultSet rs1 = sql.executeQuery();
        sql = conn.prepareCall("call getTypesIdents()");
        ResultSet rs2 = sql.executeQuery();
        sql = conn.prepareCall("call getNationality(NULL)");
        ResultSet rs3 = sql.executeQuery();
        ArrayList<ArrayList<Pair<Integer,String>>> information = new ArrayList<>();
        
        ArrayList<Pair<Integer,String>> sexes = new ArrayList<>();
        ArrayList<Pair<Integer,String>> typesOfId = new ArrayList<>();
        ArrayList<Pair<Integer,String>> nationalities = new ArrayList<>();

        //Addition of sexes
        Integer id;
        String name;
        while (rs1.next()) {
            id = rs1.getInt("idSex");
            name = rs1.getString("sexname");
            Pair<Integer,String> sex = new Pair<>(id, name);
            sexes.add(sex);
        }
        //Adittion of types of identification
        while (rs2.next()) {
            id = rs2.getInt("idTypeIdent");
            
            name = rs2.getString("nameTypeIdent");
            
            Pair<Integer,String> typeOfIdent = new Pair<>(id, name);
            typesOfId.add(typeOfIdent);
        }
        while (rs3.next()) {
            id = rs3.getInt("idNationality");
            name = rs3.getString("name");
            Pair<Integer,String> nationality = new Pair<>(id, name);
            nationalities.add(nationality);
        }
        information.add(sexes);
        information.add(typesOfId);
        information.add(nationalities);
        return information;
    }
    public ArrayList<ArrayList<Pair<Integer, String>>> getInfoInsertParticipant (Integer id) throws SQLException {
        ArrayList<ArrayList<Pair<Integer, String>>> data = new ArrayList<>();
        
        ArrayList<Pair<Integer, String>> nationalities, cities, kindships, participants;
        
        nationalities = new ArrayList<>();
        cities = new ArrayList<>();
        kindships = new ArrayList<>();
        participants = new ArrayList<>();
        
        CallableStatement sql;
        sql = conn.prepareCall("{call getCities()");
        ResultSet rsCities = sql.executeQuery();
        sql = conn.prepareCall("{call getNationality(NULL)");
        ResultSet rsNationalities = sql.executeQuery();
        sql = conn.prepareCall("{call getKindship()");
        ResultSet rsKindships = sql.executeQuery();
        sql = conn.prepareCall("{call getInfoParticipants()");
        ResultSet rsParticipants = sql.executeQuery();
        sql = conn.prepareCall("{call getSexs()");
        ResultSet rsSexs = sql.executeQuery();
        
        Pair<Integer, String> object;
        while (rsCities.next()){
             object = new Pair(rsCities.getInt(1), rsCities.getString(2));
             cities.add(object);
        }
        while (rsNationalities.next()){
             object = new Pair(rsNationalities.getInt(1), rsNationalities.getString(2));
             nationalities.add(object);
        }
        while (rsKindships.next()){
             object = new Pair(rsKindships.getInt(1), rsKindships.getString(2));
             kindships.add(object);
        }
        while (rsParticipants.next()){
             object = new Pair(rsParticipants.getInt(1), rsParticipants.getString(2));
             participants.add(object);
        }
        data.add(nationalities);
        data.add(cities);
        data.add(kindships);
        data.add(participants);
        return data;
    }
    /**************************************************************************/
    /****************************ALL FUNCTIONS ABOUT PERSON********************/
    public boolean checkRegister(String username, String email, long phone)throws SQLException {
        CallableStatement stmt = conn.prepareCall("{? = call validateRegister(?, ?)}");
        stmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
        stmt.setString(2, username);
        stmt.setString(3,email);
        stmt.execute();
        return stmt.getBoolean(1);
    }
    public int insertUser(Integer sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, long identification, long phoneNumber, 
            String email, String password, int typeOfID, boolean hasImage) throws FileNotFoundException, IOException, Exception {
        try {
            CallableStatement stmt = conn.prepareCall("{ call insertUser(?,?,?,?,?,?, ?,?,?,?,?,?,?,?)}");
            stmt.registerOutParameter(14,OracleTypes.NUMBER);
            stmt.setInt(1, sex);
            stmt.setString(2, firstName);
            stmt.setString(3, secondName);
            stmt.setString(4, firstSurname);
            stmt.setString(5, secondSurname);
            Date date = formatDate.parse(birthdate);
            // Format the date to mariaDB
            birthdate = mariaFormatDate.format(date);
            stmt.setString(6, birthdate);
            if (hasImage) {
                stmt.setBytes(7,image);
            } else {
                /*FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();*/
                stmt.setNull(7, java.sql.Types.VARCHAR);
            }
            stmt.setString(8, username);
            stmt.setLong(9, identification);
            stmt.setLong(10, phoneNumber);
            stmt.setString(11, email);
            //String encript = DigestUtils.shaHex(password);
            stmt.setString(12, password);
            stmt.setInt(13, typeOfID);
            stmt.execute();
            return stmt.getInt(14);
        } catch (SQLException ex) {
            throw ex;
        }
    }
    public int insertAdmin(Integer sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, long identification, long phoneNumber, 
            String email, String password, int typeOfID, boolean hasImage) throws FileNotFoundException, IOException, Exception {
        try {
            CallableStatement stmt = conn.prepareCall("{ call insertAdministrator(?,?,?,?,?,?, ?,?,?,?,?,?,?,?)}");
            stmt.registerOutParameter(14,OracleTypes.NUMBER);
            stmt.setInt(1, sex);
            stmt.setString(2, firstName);
            stmt.setString(3, secondName);
            stmt.setString(4, firstSurname);
            stmt.setString(5, secondSurname);
            Date date = formatDate.parse(birthdate);
            // Format the date to mariaDB
            birthdate = mariaFormatDate.format(date);
            stmt.setString(6, birthdate);
            if (hasImage) {
                stmt.setBytes(7,image);
            } else {
                /*FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();*/
                stmt.setNull(7, java.sql.Types.VARCHAR);
            }
            stmt.setString(8, username);
            stmt.setLong(9, identification);
            stmt.setLong(10, phoneNumber);
            stmt.setString(11, email);
            //String encript = DigestUtils.shaHex(password);
            stmt.setString(12, password);
            stmt.setInt(13, typeOfID);
            stmt.execute();
            return stmt.getInt(14);
        } catch (SQLException ex) {
            throw ex;
        }
    }
    public int insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws SQLException, Exception
        {
    
        CallableStatement sql = conn.prepareCall("{ call insertParticipant(?,?,?,?,?,?,?,?,?,?,?,?)}");
        sql.setInt(1, pSex);
        sql.setString(2, pFirstName);
        sql.setString(3, pSecondName);
        sql.setString(4, pFirstSurname);
        sql.setString(5, pSecondSurname);
        Date date = formatDate.parse(pDateBirth);
        // Format the date to mariaDB
        pDateBirth = mariaFormatDate.format(date);
        sql.setString(6, pDateBirth);
        sql.setInt(7, pCity);
        sql.setString(8, pBiography);
        sql.setInt(9, pHeight);
        sql.setString(10, pTrivia);
        sql.setBytes(11, pPhoto);
        sql.registerOutParameter(12, OracleTypes.NUMBER);
        sql.execute();
        return sql.getInt(12);
    }
    //Pendiente
    public void updateParticipant (int pId, Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws Exception {
        
        CallableStatement sql = conn.prepareCall("{ call updateParticipant(?,?,?,?,?,?, ?,?,?,?,?,?)}");
        sql.setInt(1, pId);
        sql.setInt(2, pSex);
        sql.setString(3, pFirstName);
        sql.setString(4, pSecondName);
        sql.setString(5, pFirstSurname);
        sql.setString(6, pSecondSurname);
        Date date = formatDate.parse(pDateBirth);
        // Format the date to mariaDB
        pDateBirth = mariaFormatDate.format(date);
        sql.setString(7, pDateBirth);
        sql.setInt(8, pCity);
        sql.setString(9, pBiography);
        sql.setInt(10, pHeight);
        sql.setString(11, pTrivia);
        sql.setBytes(12, pPhoto);
        sql.execute();
    }
    public void addNationalityToPerson(int idPerson, int idNationality) throws SQLException{
        CallableStatement sql = conn.prepareCall("{CALL insertNationalityPerson(?,?)}");
        sql.setInt(1, idNationality);
        sql.setInt(2, idPerson);
        sql.execute();
    }
    
    public static Pair<ArrayList<String>,byte[]> validUser(String username, String password) throws SQLException {
        CallableStatement sql = conn.prepareCall("{CALL getSystemUserInfo(?, ?)}");
        
        sql.setString(1, username);
        sql.setString(2, password);
        boolean hasResultSet = sql.execute();
        ResultSet rs;
        if (hasResultSet){
            rs = sql.executeQuery();
            if (rs == null)
                return null;
        } else {
            return null;
        }
        Pair<ArrayList<String>,byte[]> userInfo;
        ArrayList<String> infoList = new ArrayList<>();
        
        
        rs.next();
        infoList.add(rs.getString(1));
        infoList.add(rs.getString(2));
        infoList.add(rs.getString(3));
        infoList.add(rs.getString(4));
        infoList.add(rs.getString(5));
        byte[] image = rs.getBytes(6);
        infoList.add(rs.getString(7));
        infoList.add(rs.getString(8));
        infoList.add(rs.getString(9));
        infoList.add(rs.getString(10));
        infoList.add(rs.getString(11));
        
        if (image == null){
            FileInputStream fis;
            try {
                fis = new FileInputStream("defaultProfilePicture.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        userInfo = new Pair<>(infoList,image);
        return userInfo;
    }
    public static ArrayList<Participant> getParticipants(Integer id) throws SQLException {
        ArrayList<Participant> participants = new ArrayList();
        
        CallableStatement sql;
        sql = conn.prepareCall("{call getParticipantInfo(?)}");
        sql.setInt(1, id);
        ResultSet rs = sql.executeQuery();
        sql = conn.prepareCall("{call getParticipantNat(?)}");
        sql.setInt(1, id);
        ResultSet rsNat = sql.executeQuery();
        sql = conn.prepareCall("{call getParticipantRelatives(?)}");
        sql.setInt(1, id);
        ResultSet rsRelatives = sql.executeQuery();
        
        while (rs.next()){
            Participant participant;
            
            int idParticipant = rs.getInt(1);
            String firstName = rs.getString(2);
            String secondName = rs.getString(3);
            String firstSurname = rs.getString(4);
            String secondSurname = rs.getString(5);
            Date datebirth = rs.getDate(6);
            String date = formatDate.format(datebirth);
            Blob blob = rs.getBlob(7);
            byte[] photo = null;
            if (blob != null){
                photo = blob.getBytes(1, (int) blob.length());
            }
            int idCity = rs.getInt(8);
            String biography = rs.getString(9);
            int height = rs.getInt(10);
            String trivia = rs.getString(11);
            int idSex = rs.getInt(12);
            
            participant = new Participant(idParticipant, firstName, secondName, firstSurname, 
                    secondSurname, date, photo, idCity, biography, height, trivia, idSex);
            while (rsNat.next()){
                participant.addNationality(rsNat.getInt(1));
            }
            while (rsRelatives.next()){
                participant.addRelative(rsRelatives.getInt(1));
            }
            participants.add(participant);
        }
        return participants;
    }
    public ArrayList<Triple<Integer, String, byte[]>> getInfoParticipants() throws SQLException, FileNotFoundException, IOException{
        CallableStatement sql = conn.prepareCall("{call getInfoParticipants()}");
        ResultSet rs = sql.executeQuery();
        ArrayList<Triple<Integer, String, byte[]>> participants = new ArrayList<>();
        Triple<Integer, String, byte[]> participant;
        int idParticipant = -1;
        while (rs.next()) {
            if (rs.getInt(1) != idParticipant) {
                idParticipant = rs.getInt(1);
                String name = rs.getString(2);
                Blob blob = rs.getBlob(3);
                byte[] photo;
                if (blob != null) {
                    photo = blob.getBytes(1, (int) blob.length());
                } else {
                    FileInputStream fis = new FileInputStream("defaultProfilePicture.png");
                    photo = new byte[fis.available()];
                    fis.read(photo);
                    fis.close();
                }
                participant = new Triple<>(idParticipant, name, photo);
                participants.add(participant);
            }
        }
        return participants;
    }
    public DataCreation getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        CallableStatement sql;
        sql = conn.prepareCall("{call getInfoParticipants()}");
        ResultSet rsParticipants = sql.executeQuery();
        sql = conn.prepareCall("{call getTypesParticipant()}");
        ResultSet rsTypeParticipants = sql.executeQuery();
        sql = conn.prepareCall("{call getTypesProducts()}");
        ResultSet rsTypeProducts = sql.executeQuery();
        sql = conn.prepareCall("{call getCatalogs()}");
        ResultSet rsGenres = sql.executeQuery();
        sql = conn.prepareCall("{call getPlatforms()}");
        ResultSet rsPlatforms = sql.executeQuery();
        
        /**********************************************************************/
        DataCreation data = new DataCreation();
        /**********************************************************************/
        while (rsParticipants.next()){
            Blob blob = rsParticipants.getBlob(3);
            byte [] blobBytes;
            if (blob == null) {
                blobBytes = null;
            } else {
                blobBytes = blob.getBytes(1, (int) blob.length());
            }
            data.addParticipant(rsParticipants.getInt(1), blobBytes, rsParticipants.getString(2));
        }
        while (rsTypeParticipants.next()){
            data.addRol(rsTypeParticipants.getInt(1), rsTypeParticipants.getString(2));
        }
        while (rsTypeProducts.next()) {
            data.addType(rsTypeProducts.getInt(1), rsTypeProducts.getString(2));
        }
        while (rsGenres.next()) {
            data.addGenre(rsGenres.getInt(1), rsGenres.getString(2));
        }
        while (rsPlatforms.next()) {
            data.addPlatform(rsPlatforms.getInt(1), rsPlatforms.getString(2));
        }
        return data;
    }
    
    public Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call insertProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idTypeProduct);
        sql.setInt(2, releaseYear);
        sql.setString(3, title);
        sql.setInt(4, duration);
        sql.setString(5, synopsis);
        sql.setString(6, trailer);
        sql.setInt(7, price);
        sql.registerOutParameter(8, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdProduct = sql.getInt(8);
        return rsIdProduct;
    }
    
    public void updateProduct(Integer idProduct, Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call updateProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idProduct);
        sql.setInt(2, idTypeProduct);
        sql.setInt(3, releaseYear);
        sql.setString(4, title);
        sql.setInt(5, duration);
        sql.setString(6, synopsis);
        sql.setString(7, trailer);
        sql.setInt(8, price);
        sql.execute();
    }
    /**************************************************************************/
    
    public void addParticipant(Integer pIdProduct, Integer pIdParticipant,
            Integer pRol) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call addParticipant(?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdParticipant);
        sql.setInt(3, pRol);
        sql.execute();
    }
    
    public void removeParticipantToProduct(int idProduct, int idParticipant) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call deleteParticipant(?, ?)}");
        sql.setInt(1, idProduct);
        sql.setInt(2, idParticipant);
        sql.execute();
    }
    public Integer addSeason(Integer pIdProduct, Integer pNumberSeason) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call addSeason(?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pNumberSeason);
        sql.registerOutParameter(3, java.sql.Types.INTEGER);
        sql.execute();
        Integer rsIdSeason = sql.getInt(3);
        return rsIdSeason;
    }
     public void removeSeason(int pIdSeason) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call removeSeason(?)}");
        sql.setInt(1, pIdSeason);
        sql.execute();
    }
    
    public void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call addEpisode(?, ?, ?, ?)}");
        sql.setInt(1, pIdSeason);
        sql.setInt(2, pNumberEpisode);
        sql.setString(3, pName);
        sql.setInt(4, pDuration);
        sql.execute();
    }
    public void removeEpisode(int idEpisode) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call removeEpisode(?)}");
        sql.setInt(1, idEpisode);
        sql.execute();
    }
    public void addPhoto(int pIdProduct, byte[] pImage) throws SQLException, Exception {
        CallableStatement sql = conn.prepareCall("{call addPhoto(?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setBytes(2, pImage);
        sql.execute();
    }
    
    public void removePhoto(int idImage) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call removePhoto(?)}");
        sql.setInt(1, idImage);
        sql.execute();
    }
    
    public Pair<ArrayList<Product>, Map<Integer, String>> getProducts() throws SQLException, FileNotFoundException, IOException{
        CallableStatement sql;
        sql = conn.prepareCall("{call getProducts()}");
        ResultSet rs = (ResultSet) sql.executeQuery();
        sql = conn.prepareCall("{call getProductsXGenre()}");
        ResultSet rs2 = (ResultSet) sql.executeQuery();
        
        ArrayList<Product> products = new ArrayList<>();
        Map<Integer, String> genres;
        genres = new java.util.LinkedHashMap();
        //Triple<Integer, String, byte[]> product;
        int idProduct = -1;
        Product product;
        while (rs.next()) {
            if (rs.getInt(1) != idProduct) {
                idProduct = rs.getInt(1);
                String title = rs.getString(2);
                Blob blob = rs.getBlob(3);
                int price = rs.getInt(4);
                byte[] blobBytes;
                if (blob != null) {
                    blobBytes = blob.getBytes(1, (int) blob.length());
                } else {
                    FileInputStream fis = new FileInputStream("DefaultImageProduct.png");
                    blobBytes = new byte[fis.available()];
                    fis.read(blobBytes);
                    fis.close();
                }
                product = new Product(idProduct, title, price);
                product.addImage(1, blobBytes);
                
                while (rs2.next()){
                    int idGenre = rs2.getInt(4);
                    if (rs2.getInt(3) == idProduct){
                        product.addGenre(idGenre, rs2.getString(2));
                    }
                    else {
                        rs2.previous();
                        break;
                    }
                    if (!genres.containsKey(idGenre)){
                        genres.put(idGenre, rs2.getString(2));
                    }
                }
                products.add(product);
            }
        }
        Pair<ArrayList<Product>, Map<Integer, String>> data = new Pair(products, genres);
        return data;
    }
    public Product getProduct(int pIdProduct) throws SQLException, FileNotFoundException, IOException {
        CallableStatement sql = conn.prepareCall("{call getProductInfo(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsInfoProduct = (ResultSet) sql.executeQuery();
        
        sql = conn.prepareCall("{call getProductParticipants(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsParticipantsProduct = (ResultSet) sql.executeQuery();
        
        sql = conn.prepareCall("{call getProductSeasons(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsSeasonsProduct = (ResultSet) sql.executeQuery();
        
        sql = conn.prepareCall("{call getProductImages(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsImagesProduct = (ResultSet) sql.executeQuery();
        
        sql = conn.prepareCall("{call getProductGenres(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsGenresProduct = (ResultSet) sql.executeQuery();
        
        sql = conn.prepareCall("{call getProductPlatforms(?)}");
        sql.setInt(1, pIdProduct);
        ResultSet rsPlatformsProduct = (ResultSet) sql.executeQuery();
        /**********************************************************************/
        /*********************Return Variables*********************************/
        /*Extract basic information about products*/
        Product product = null;
        while (rsInfoProduct.next()) {
            product = new Product(rsInfoProduct.getInt(1), rsInfoProduct.getInt(2),
            rsInfoProduct.getInt(3), rsInfoProduct.getString(4), rsInfoProduct.getInt(5),
            rsInfoProduct.getString(6), rsInfoProduct.getString(7), rsInfoProduct.getInt(8));
        }
        /*************************Particpant x product*************************/
        while (rsParticipantsProduct.next()) {
            String rol = rsParticipantsProduct.getString(4);
            String firstName = rsParticipantsProduct.getString(2);
            String firstSurname = rsParticipantsProduct.getString(3);
            String participantInformation = rol + " - " + firstName + " " + firstSurname ;
            int id = rsParticipantsProduct.getInt(1);
            product.addParticipant(id, participantInformation);
        }
        /********************Get seasons with episodes*************************/
        String infoSeason[];
        int lastId = -1;
        while (rsSeasonsProduct.next()) {
            /*Season atributes*/
            int idSeason = rsSeasonsProduct.getInt(1);
            if (idSeason == lastId) {
                addEpisodeToSeason(rsSeasonsProduct, product);
            } else {
                infoSeason = new String[2];
                infoSeason[0] = rsSeasonsProduct.getString(2);
                //infoSeason[1] = rsSeasonsProduct.getString(3);
                product.addSeason(idSeason, infoSeason);
                addEpisodeToSeason(rsSeasonsProduct, product);
                lastId = idSeason;
            }
        }
        /*****************************Images***********************************/
        while (rsImagesProduct.next()){
            int idImage = rsImagesProduct.getInt(1);
            Blob blob = rsImagesProduct.getBlob(2);
            byte[] image;
            if (blob != null) {
                image = blob.getBytes(1, (int) blob.length());
                product.addImage(idImage, image);
            }
        }
        /**************************Genres**************************************/
        while (rsGenresProduct.next()){
            product.addGenre(rsGenresProduct.getInt(1), rsGenresProduct.getString(2));
        }
        while (rsPlatformsProduct.next()){
            product.addPlatform(rsPlatformsProduct.getInt(1), rsPlatformsProduct.getString(2));
        }
        
        return product;
    }
    private void addEpisodeToSeason(ResultSet rs, Product product) throws SQLException {
        Integer id = rs.getInt(3);
        int idSeason = rs.getInt(1);
        if (id == 0) {
        } else {
            String[] infoEpisode = new String[4];
            infoEpisode[0] = rs.getString(3);
            infoEpisode[1] = rs.getString(4);
            infoEpisode[2] = rs.getString(5);
            infoEpisode[3] = rs.getString(6);
            product.addEpisodes(idSeason, infoEpisode);
        }
    }
    
    public void addGenreProduct(int pIdGenre, int pIdProduct) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call addGenre(?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdGenre);
        sql.execute();
    }
    public void addPlatformProduct(int pIdPlatform, int pIdProduct) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call addPlatform(?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdPlatform);
        sql.execute();
    }
    
    public ArrayList<String[]> getFullReview (int pIdProduct) throws SQLException, FileNotFoundException, IOException {
        CallableStatement sql = conn.prepareCall("{call getFullReview(?)}");
        sql.setInt(1, pIdProduct);
        /**********************************************************************/
        ResultSet rsComment = (ResultSet) sql.executeQuery();
        ArrayList<String[]> fullReviews = new ArrayList();
        while (rsComment.next()){
            String [] fullReview = new String[5];
            for (int i = 0; i < 5; i ++){
                fullReview[i] = rsComment.getString(i+1);
            }
            fullReviews.add(fullReview);
        }
        return fullReviews;
    }
    
    public void addCommentary(int idUser, int idProduct, String comment) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call commentProduct(?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.setString(3, comment);
        sql.execute();
    }
    
    public void addReview(int idUser, int idProduct, int stars) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call reviewProduct(?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.setInt(3, stars);
        sql.execute();
    }
    public void updateCommentary(int idUser, int idProduct, String comment) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call updateComment(?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.setString(3, comment);
        sql.execute();
    }
    
    public void updateReview(int idUser, int idProduct, int stars) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call updateReview(?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.setInt(3, stars);
        sql.execute();
    }
    public void insertCard(int idUser, int cardNumber, String date, int ccv, String owner) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call insertCard(?, ?, ?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, cardNumber);
        sql.setString(3, date);
        sql.setInt(4, ccv);
        sql.setString(5, owner);
        sql.execute();
    }
    public ArrayList<String[]> getPaymentMethods(int idUser) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call getPaymentMethods(?)}");
        sql.setInt(1, idUser);
        ResultSet rs = sql.executeQuery();
        ArrayList<String[]> methods;
        methods = new ArrayList();
        while (rs.next()){
            String [] method = new String[5];
            for (int i = 0; i < 5; i++){
                method[i] = rs.getString(i+1);
            }
            methods.add(method);
        }
        return methods;
    }
    public void buyProduct(int idUser, int idProduct, int idPayment) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call buyProduct(?, ?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.setInt(3, idPayment);
        sql.execute();
    }
    public void addFavorite(int idUser, int idProduct) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call insertFavorite(?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.execute();
    }
    public void deleteFavorite(int idUser, int idProduct) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call deleteFavorite(?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, idProduct);
        sql.execute();
    }
    public ArrayList<Triple<Integer, String, byte[]>> getUserFavorites(int idUser) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call getWishlist(?)}");
        sql.setInt(1, idUser);
        ResultSet rs = sql.executeQuery();
        Triple<Integer, String, byte[]> product;
        ArrayList<Triple<Integer, String, byte[]>> products;
        products = new ArrayList();
        while (rs.next()){
            product = new Triple(rs.getInt(1), rs.getString(2), rs.getBytes(3));
            products.add(product);
        }
        return products;
    }

    public void insertBasicObject(String objectToAdd, String name, int second) throws SQLException {
        CallableStatement sql;
        sql = null;
        
        switch (objectToAdd) {
            case "Nationality" -> {
                sql = conn.prepareCall("{call insertNationality(?)}");
            }
            case "Country" -> {
                sql = conn.prepareCall("{call insertCountry(?)}");
            }
            case "Province" -> {
                sql = conn.prepareCall("{call insertCity(?, ?)}");
            }
            case "TypeIdent" -> {
                sql = conn.prepareCall("{call insertTypeIdent(?)}");
            }
            case "Catalog" -> {
                sql = conn.prepareCall("{call insertCatalog(?)}");
            }
            case "TypeProduct" -> {
                sql = conn.prepareCall("{call insertTypeProduct(?)}");
            }
            case "TypeParticipant" -> {
                sql = conn.prepareCall("{call insertTypeParticipant(?)}");
            }
            case "Platform" -> {
                sql = conn.prepareCall("{call insertPlatform(?)}");
            }
            case "Sex" -> {
                sql = conn.prepareCall("{call insertSex(?)}");
            }
            case "Kindship" -> {
                sql = conn.prepareCall("{call insertKindship(?)}");
            }
            default -> System.out.println("Opción no válida");
        }
        sql.setString(1, name);
        if (objectToAdd.equals("Province")){
            sql.setInt(2, second);
        }
        sql.execute();
    }
    
    public ArrayList<Pair<Integer, String>> getBasicObject(String objectToAdd) throws SQLException {
        CallableStatement sql;
        sql = null;
        switch (objectToAdd) {
            case "Nationality" -> {
                sql = conn.prepareCall("{call getNationality(NULL)}");
            }
            case "Country" -> {
                sql = conn.prepareCall("{call getCountries()}");
            }
            case "Province" -> {
                sql = conn.prepareCall("{call getCities()}");
            }
            case "TypeIdent" -> {
                sql = conn.prepareCall("{call getTypesIdents()}");
            }
            case "Catalog" -> {
                sql = conn.prepareCall("{call getCatalogs()}");
            }
            case "TypeProduct" -> {
                sql = conn.prepareCall("{call getTypesProducts()}");
            }
            case "TypeParticipant" -> {
                sql = conn.prepareCall("{call getTypesParticipant()}");
            }
            case "Platform" -> {
                sql = conn.prepareCall("{call getPlatforms()}");
            }
            case "Sex" -> {
                sql = conn.prepareCall("{call getSexs()}");
            }
            case "Kindship" -> {
                sql = conn.prepareCall("{call getKindship()}");
            }
            default -> System.out.println("Opción no válida");
        }
        if (sql != null){
            ResultSet rs = sql.executeQuery();
            Pair<Integer, String> object;
            ArrayList<Pair<Integer, String>> objects;
            objects = new ArrayList();
            while (rs.next()){
                object = new Pair(rs.getInt(1), rs.getString(2));
                objects.add(object);
            }
            return objects;
        } else {
            return null;
        }
    }
    public void updateBasicObject(String objectToAdd, int id, String name, int third) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call setTypeIdent(?, ?)}");
        
        switch (objectToAdd) {
            case "Nationality" -> {
                sql = conn.prepareCall("{call setNationality(?, ?)}");
            }
            case "Country" -> {
                sql = conn.prepareCall("{call setCountry(?, ?)}");
            }
            case "Province" -> {
                sql = conn.prepareCall("{call setCity(?, ?, ?)}");
            }
            case "TypeIdent" -> {
                sql = conn.prepareCall("{call setTypeIdent(?, ?)}");
            }
            case "Catalog" -> {
                sql = conn.prepareCall("{call setCatalog(?, ?)}");
            }
            case "TypeProduct" -> {
                sql = conn.prepareCall("{call setTypeProduct(?, ?)}");
            }
            case "TypeParticipant" -> {
                sql = conn.prepareCall("{call setTypeParticipant(?, ?)}");
            }
            case "Platform" -> {
                sql = conn.prepareCall("{call setPlatform(?, ?)}");
            }
            case "Sex" -> {
                sql = conn.prepareCall("{call setSex(?, ?)}");
            }
            case "Kindship" -> {
                sql = conn.prepareCall("{call setKindship(?, ?)}");
            }
            default -> System.out.println("Opción no válida");
        }
        sql.setInt(1, id);
        sql.setString(2, name);
        
        if (objectToAdd.equals("Province")){
            sql.setInt(3, third);
        }
        sql.execute();
    }
    public void removeBasicObject(String objectToRemove, int id) throws SQLException{
        CallableStatement sql;
        switch (objectToRemove) {
            case "Nationality" -> {
                sql = conn.prepareCall("{call deleteNationality(?)}");
            }
            case "Country" -> {
                sql = conn.prepareCall("{call deleteCountry(?)}");
            }
            case "Province" -> {
                sql = conn.prepareCall("{call deleteCity(?)}");
            }
            case "TypeIdent" -> {
                sql = conn.prepareCall("{call deleteTypeIdent(?)}");
            }
            case "Catalog" -> {
                sql = conn.prepareCall("{call deleteCatalog(?)}");
            }
            case "TypeProduct" -> {
                sql = conn.prepareCall("{call deleteTypeProduct(?)}");
            }
            case "TypeParticipant" -> {
                sql = conn.prepareCall("{call deleteTypeParticipant(?)}");
            }
            case "Platform" -> {
                sql = conn.prepareCall("{call deletePlatform(?)}");
            }
            case "Sex" -> {
                sql = conn.prepareCall("{call deleteSex(?)}");
            }
            case "Kindship" -> {
                sql = conn.prepareCall("{call deleteKindship(?)}");
            }
            default -> sql = null;
        }
        sql.setInt(1, id);
        sql.execute();
    }
    public ArrayList<Triple<Integer, String, byte[]>> getTopNPurchases(int N) throws SQLException, IOException{
        CallableStatement sql = conn.prepareCall("{call getTopNPurchases(?)}");
        sql.setInt(1, N);
        ResultSet rs = sql.executeQuery();
        
        ArrayList<Triple<Integer, String, byte[]>> products;
        Triple<Integer, String, byte[]> product;
        products = new ArrayList();
        while (rs.next()){
            Blob blob = rs.getBlob(3);
            byte[] blobBytes;
            if (blob != null) {
                blobBytes = blob.getBytes(1, (int) blob.length());
            } else {
                FileInputStream fis = new FileInputStream("DefaultImageProduct.png");
                blobBytes = new byte[fis.available()];
                fis.read(blobBytes);
                fis.close();
            }
            product = new Triple<>(rs.getInt(1), rs.getString(2), blobBytes);
            product.setId(rs.getInt(4));
            products.add(product);
        }
        return products;
    }
    
    
    public ArrayList<Integer> getPurchasesHistory(int idUser, int month) throws SQLException{
        ArrayList<Integer> products;
        products = new ArrayList();
        CallableStatement sql = conn.prepareCall("{call getPurchasesInLastNMonths(?, ?)}");
        sql.setInt(1, idUser);
        sql.setInt(2, month);
        ResultSet rs = sql.executeQuery();
        while (rs.next()){
            products.add(rs.getInt(1));
        }
        return products;
    }
    public ArrayList<String[]> getBinnacle() throws SQLException{
        CallableStatement sql = conn.prepareCall("{call getBinnacle()}");
        ResultSet rs = sql.executeQuery();
        //Binnacle binnacle = new Binnacle();
        ArrayList<String[]> binnacle;
        binnacle = new ArrayList();
        while (rs.next()){
            String info[] = new String[5];
            info[0] = "" + rs.getInt(1);
            info[1] = rs.getString(2);
            info[2] = "" + rs.getInt(3);
            info[3] = "" + rs.getInt(4);
            info[4] = rs.getString(5);
            binnacle.add(info);
        }
        return binnacle;
    }
    public List<Integer> getRecentlyVisited(int idUser) throws Exception {
        try {
            CallableStatement sql = conn.prepareCall("call getRecentlyVisited(?)");
            sql.setInt(1,idUser);
            ResultSet rs = sql.executeQuery();
            List<Integer> products = new ArrayList<Integer>();
            while (rs.next()) {
                products.add(rs.getInt(1));
            }
            return products;
        } catch (Exception ex) {
            throw ex;
        }
    }
    public void visitProduct(int idUser, int idProduct) throws SQLException{
        try {
            CallableStatement sql = conn.prepareCall("call visitProduct(?,?)");
            sql.setInt(1,idUser);
            sql.setInt(2, idProduct);
            sql.execute();
        }
        catch (Exception ex) {
            throw ex;
        }
    }
    public void insertRelative(int idParticipant, int idRelative, int idKindship) throws SQLException{
        CallableStatement sql = conn.prepareCall("call insertRelative(?, ?, ?)");
        sql.setInt(1, idParticipant);
        sql.setInt(2, idRelative);
        sql.setInt(3, idKindship);
        sql.execute();
    }
    public void deleteParticipant(int id) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call removeParticipant(?)}");
        sql.setInt(1, id);
        sql.execute();
    }
    public void deleteProduct(int id) throws SQLException{
        CallableStatement sql = conn.prepareCall("{call deleteProduct(?)}");
        sql.setInt(1, id);
        sql.execute();
    }
}