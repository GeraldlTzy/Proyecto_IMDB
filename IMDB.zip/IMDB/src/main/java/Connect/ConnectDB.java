package Connect;

import java.io.FileInputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kakas
 */
public class ConnectDB {
    public static void insertNationality(String name){
        try {
            String host = "jdbc:oracle:thin:@localhost:1521:BD1GERALD";
            String uName = "su";
            String uPass = "su";
            
            Connection con=DriverManager.getConnection(host, uName, uPass);
            CallableStatement stmt = con.prepareCall("{ call insertNationality(?)}");
            stmt.setString(1, name);
            stmt.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void insertImagen() {
        try {
            String host = "jdbc:oracle:thin:@localhost:1521:BD1GERALD";
            String uName = "su";
            String uPass = "su";
            
            Connection con=DriverManager.getConnection(host, uName, uPass);
            // Lee la imagen desde el archivo
            FileInputStream fis = new FileInputStream("C:\\Users\\kakas\\Pictures\\Scarlett_Johansson.jpg"); // Cambia esto por la ruta de tu imagen
            byte[] image = new byte[fis.available()];
            fis.read(image);
            fis.close();
            String sql = "{ call insertImage(?, ?)}";
            CallableStatement stmt = con.prepareCall(sql);
            stmt.setInt(1, 1);
            stmt.setBytes(2, image);
            stmt.execute();
        } catch (Exception e) {
            Logger.getLogger(ConnectDB.class.getName()).log(Level.SEVERE, null, e);
        }
        
    }
}
