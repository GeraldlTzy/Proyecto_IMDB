package Interface;

public class AdminWindow extends javax.swing.JFrame {
    
    private AddBasicWindow addBasicWindow;
    private ParticipantWindow participantWindow;
    private ProductWindow productWindow;
    private ViewProductsWindow viewProductsWindow;
    private StatisticsWindow statisticsWindow;
    private RegisterWindow registerWindow = new RegisterWindow();
    private BinnacleWindow binnacleWindow;
    public AdminWindow() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        addBasicWindow = new AddBasicWindow(this, true);
        statisticsWindow = new StatisticsWindow();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnProduct = new javax.swing.JButton();
        btnNationality = new javax.swing.JButton();
        btnCountry = new javax.swing.JButton();
        btnProvince = new javax.swing.JButton();
        btnTypeIdent = new javax.swing.JButton();
        btnTypeProduct = new javax.swing.JButton();
        btnParticipant = new javax.swing.JButton();
        btnTypeParticipant = new javax.swing.JButton();
        btnCatalog = new javax.swing.JButton();
        btnSex = new javax.swing.JButton();
        btnPlatform = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        btnEditParticipant = new javax.swing.JButton();
        btnStatistics = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Agregar");

        jButton1.setText("Administrador");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnProduct.setText("Producto");
        btnProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductActionPerformed(evt);
            }
        });

        btnNationality.setText("Nacionalidad");
        btnNationality.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNationalityActionPerformed(evt);
            }
        });

        btnCountry.setText("País");
        btnCountry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCountryActionPerformed(evt);
            }
        });

        btnProvince.setText("Province");
        btnProvince.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProvinceActionPerformed(evt);
            }
        });

        btnTypeIdent.setText("Tipo de identificación");
        btnTypeIdent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTypeIdentActionPerformed(evt);
            }
        });

        btnTypeProduct.setText("Tipo de producto");
        btnTypeProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTypeProductActionPerformed(evt);
            }
        });

        btnParticipant.setText("Participante");
        btnParticipant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParticipantActionPerformed(evt);
            }
        });

        btnTypeParticipant.setText("Tipo de participante");
        btnTypeParticipant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTypeParticipantActionPerformed(evt);
            }
        });

        btnCatalog.setText("Catálogo");
        btnCatalog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCatalogActionPerformed(evt);
            }
        });

        btnSex.setText("Sexo");
        btnSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSexActionPerformed(evt);
            }
        });

        btnPlatform.setText("Plataforma");
        btnPlatform.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlatformActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(jLabel1)
                    .addComponent(btnProduct)
                    .addComponent(btnNationality)
                    .addComponent(btnCountry)
                    .addComponent(btnProvince)
                    .addComponent(btnParticipant))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTypeIdent)
                    .addComponent(btnTypeProduct)
                    .addComponent(btnTypeParticipant)
                    .addComponent(btnCatalog)
                    .addComponent(btnSex)
                    .addComponent(btnPlatform))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(btnTypeIdent))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnProduct)
                    .addComponent(btnTypeProduct))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNationality)
                    .addComponent(btnTypeParticipant))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCountry)
                    .addComponent(btnCatalog))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnProvince)
                    .addComponent(btnSex))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnParticipant)
                    .addComponent(btnPlatform))
                .addContainerGap(51, Short.MAX_VALUE))
        );

        jLabel2.setText("Editar");

        jButton2.setText("Producto");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnEditParticipant.setText("Participante");
        btnEditParticipant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditParticipantActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jButton2)
                    .addComponent(btnEditParticipant))
                .addContainerGap(135, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEditParticipant)
                .addGap(0, 99, Short.MAX_VALUE))
        );

        btnStatistics.setText("Ver Estadísticas");
        btnStatistics.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStatisticsActionPerformed(evt);
            }
        });

        jButton3.setText("Bitácora");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnStatistics)
                    .addComponent(jButton3))
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(btnStatistics)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addGap(135, 135, 135))))
        );

        btnClose.setText("Cerrar");
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnClose)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnClose))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        registerWindow.setTypeUser("Admin");
        registerWindow.setTitle("Registro");
        registerWindow.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnNationalityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNationalityActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("Nationality");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnNationalityActionPerformed

    private void btnCountryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCountryActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("Country");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnCountryActionPerformed

    private void btnProvinceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProvinceActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("Province");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnProvinceActionPerformed

    private void btnTypeIdentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTypeIdentActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("TypeIdent");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnTypeIdentActionPerformed

    private void btnTypeProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTypeProductActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("TypeProduct");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnTypeProductActionPerformed

    private void btnParticipantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParticipantActionPerformed
        participantWindow = new ParticipantWindow();
        participantWindow.loadData();
        participantWindow.setPurpose("Create");
        participantWindow.setVisible(true);
    }//GEN-LAST:event_btnParticipantActionPerformed

    private void btnTypeParticipantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTypeParticipantActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("TypeParticipant");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnTypeParticipantActionPerformed

    private void btnCatalogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCatalogActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("Catalog");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnCatalogActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void btnSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSexActionPerformed
        // TODO add your handling code here:
        addBasicWindow.setObject("Sex");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnSexActionPerformed

    private void btnProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductActionPerformed
        productWindow = new ProductWindow();
        productWindow.setPurpose("Create");
        productWindow.LoadData();
        productWindow.setVisible(true);
    }//GEN-LAST:event_btnProductActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        viewProductsWindow = new ViewProductsWindow(this, true);
        viewProductsWindow.LoadData("Admin", "Product");
        viewProductsWindow.setVisible(true);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnEditParticipantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditParticipantActionPerformed
        viewProductsWindow = new ViewProductsWindow(this, true);
        viewProductsWindow.LoadData("Admin", "Participant");
        viewProductsWindow.setVisible(true);
    }//GEN-LAST:event_btnEditParticipantActionPerformed

    private void btnStatisticsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStatisticsActionPerformed
        statisticsWindow.LoadData();
        statisticsWindow.setVisible(true);
    }//GEN-LAST:event_btnStatisticsActionPerformed

    private void btnPlatformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlatformActionPerformed
        addBasicWindow.setObject("Platform");
        addBasicWindow.setVisible(true);
    }//GEN-LAST:event_btnPlatformActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        binnacleWindow = new BinnacleWindow();
        binnacleWindow.loadData();
        binnacleWindow.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCatalog;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnCountry;
    private javax.swing.JButton btnEditParticipant;
    private javax.swing.JButton btnNationality;
    private javax.swing.JButton btnParticipant;
    private javax.swing.JButton btnPlatform;
    private javax.swing.JButton btnProduct;
    private javax.swing.JButton btnProvince;
    private javax.swing.JButton btnSex;
    private javax.swing.JButton btnStatistics;
    private javax.swing.JButton btnTypeIdent;
    private javax.swing.JButton btnTypeParticipant;
    private javax.swing.JButton btnTypeProduct;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
