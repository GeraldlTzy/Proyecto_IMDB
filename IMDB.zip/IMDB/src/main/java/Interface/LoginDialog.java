package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import LogicClasses.User;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class LoginDialog extends javax.swing.JDialog {

    private Controller controller = Controller.getInstance();
    private AdminWindow adminWindow;
    private UserWindow userWindow;
    private User user = User.getInstance();
 
    public LoginDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setDefaultCloseOperation(javax.swing.JDialog.DISPOSE_ON_CLOSE);
        adminWindow = new AdminWindow();
        userWindow = new UserWindow();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtUser = new javax.swing.JTextField();
        btnAccess = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        txtPswd = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Usuario");

        jLabel2.setText("Contraseña");

        txtUser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitSize(evt);
            }
        });

        btnAccess.setText("Acceder");
        btnAccess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAccessActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancelar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtUser, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(txtPswd)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(btnAccess)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancel)))
                .addContainerGap(117, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtPswd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAccess)
                    .addComponent(btnCancel))
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAccessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAccessActionPerformed
        Pair<ArrayList<String>,byte[]> userInfo;
        
        userInfo = controller.validUser(txtUser.getText(), txtPswd.getText());
        if (userInfo != null) {
            txtUser.setText("");
            txtPswd.setText("");
            ArrayList<String> listInfo = userInfo.getFirst();
            int typeUser = Integer.parseInt(listInfo.get(0));
            if (typeUser == 2) {adminWindow.setVisible(true);dispose();}
            if (typeUser == 1) {
                
                String userType = listInfo.get(0);
                int id = Integer.parseInt(listInfo.get(1));
                String firstName = listInfo.get(2);
                String firstSurname = listInfo.get(3);
                String birthdate = listInfo.get(4);
                String username = listInfo.get(5);
                String phoneNumber = listInfo.get(6);
                String email = listInfo.get(7);
                byte[] image = userInfo.getSecond();
                String sex = listInfo.get(9);
                String secondName = listInfo.get(10);
                String secondSurname = listInfo.get(11);
                int identification = Integer.parseInt(listInfo.get(12));
                user.UpdateUser(userType, id, firstName, firstSurname, birthdate,
                        image, username, phoneNumber, email,sex, secondName, 
                        secondSurname, identification);
                userWindow.loadPhoto();
                userWindow.setVisible(true);
                dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "El usuario o la contraseña están incorrectos");
        }
        
    }//GEN-LAST:event_btnAccessActionPerformed

    private void LimitSize(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LimitSize
        JTextField txt = (JTextField) evt.getComponent();
        if (txt.getText().length() > 20) evt.consume();
    }//GEN-LAST:event_LimitSize

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAccess;
    private javax.swing.JButton btnCancel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txtPswd;
    private javax.swing.JTextField txtUser;
    // End of variables declaration//GEN-END:variables
}
