package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import LogicClasses.Participant;
import LogicClasses.RenderCell;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ParticipantWindow extends javax.swing.JFrame {
    private Controller controller;
    private javax.swing.DefaultListModel modelListNationalities, modelListParticipants,
            modelListRelatives;
    private ArrayList<Pair<Integer, String>> cities, kindships, nationalities, participants;
    private ArrayList<ArrayList<Pair<Integer, String>>> data;
    private JFileChooser fileWindow;
    private byte[] image;
    Participant participant;
    SimpleDateFormat sdf;
    private String purpose;
    /**
     * Creates new form ParticipantWindow
     */
    public ParticipantWindow() {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        controller = Controller.getInstance();
        fileWindow = new JFileChooser();
        sdf = new SimpleDateFormat("dd/MM/yyyy");
        cmbNationalities.removeAllItems();
        modelListNationalities = new javax.swing.DefaultListModel();
        listNationalities.setModel(modelListNationalities);
        listNationalities.setCellRenderer(new RenderCell());
        modelListParticipants = new javax.swing.DefaultListModel();
        listParticipants.setModel(modelListParticipants);
        
        modelListRelatives = new javax.swing.DefaultListModel();
        listRelatives.setModel(modelListRelatives);
        listRelatives.setCellRenderer(new RenderCell());
        cmbProvinces.removeAllItems();
        data = new ArrayList<>();
        nationalities = new ArrayList<>();
        cities = new ArrayList<>();
        kindships = new ArrayList<>();
        image = null;
        cmbSex.removeAllItems();
        cmbSex.addItem("Masculino");
        cmbSex.addItem("Femenino");
        participant = null;
        purpose = null;
    }
    
    public void setPurpose(String purpose){
        this.purpose = purpose;
        if (purpose.equals("View")) setEnabledFields(false);
        else setEnabledFields(true);
    }
    
    public void setParticipant(int idParticipant){
        try {
            loadData();
            participant = controller.getParticipant(idParticipant).get(0);
            txtFirstName.setText(participant.firstName);
            txtSecondName.setText(participant.secondName);
            txtFirstSurname.setText(participant.firstSurname);
            txtSecondSurname.setText(participant.secondSurname);
            String pDate = participant.birthdate;
            Date date = sdf.parse(pDate);
            dateChooser.setDate(date);
            txtBiograph.setText(participant.biography);
            txtHeight.setText(""+participant.heigth);
            txtTrivia.setText(participant.trivia);
            image = participant.photo;
            UpdateImage();
            cmbSex.setSelectedIndex(participant.idSex - 1);
            
            
            int i = 0;
            for (Pair<Integer, String> city : cities){
                if (city.getFirst() == participant.idCity){
                    cmbProvinces.setSelectedIndex(i);
                    break;
                }
                i++;
            }
            
            for (Pair<Integer, String> nationality : nationalities){
                if (participant.getNationalities().contains(nationality.getFirst())){
                    nationality.setText(nationality.getSecond());
                    modelListNationalities.addElement(nationality);
                }
            }
            LinkedHashMap<Integer, String> relatives = participant.getRelatives();
            for (Pair<Integer, String> participantToAdd : participants){
                if (relatives.containsKey(participantToAdd.getFirst())){
                    participantToAdd.setText(participantToAdd.getSecond() + " : "
                    + relatives.get(participantToAdd.getFirst()));
                    modelListRelatives.addElement(participantToAdd);
                }
            }
            
            
         } catch (SQLException | ParseException ex) {
             JOptionPane.showMessageDialog(this, "No se pudo cargar la información del participante.", "Error", JOptionPane.ERROR_MESSAGE);
         }
    }

    
    private void setEnabledFields(boolean state) {
        txtFirstName.setEnabled(state);
        txtSecondName.setEditable(state);
        txtFirstSurname.setEditable(state);
        txtSecondSurname.setEditable(state);
        txtHeight.setEnabled(state);
        txtTrivia.setEnabled(state);
        txtBiograph.setEditable(state);
        dateChooser.setEnabled(state);
        
        cmbNationalities.setVisible(state);
        
        cmbProvinces.setEditable(state);
        cmbProvinces.setEnabled(state);
        
        
        btnSelectImage.setVisible(state);
        lblPhoto.setVisible(state);
        btnAddNationality.setEnabled(state);
        btnAddNationality.setVisible(state);
        
        btnAddRelative.setEnabled(state);
        btnAddRelative.setVisible(state);
        listParticipants.setVisible(state);
        cmbKindship.setVisible(state);
    }
    
    public void loadData() {
        //clear();
        try {
            data = controller.getInfoInsertParticipant(null);
            nationalities = data.get(0);
            cities = data.get(1);
            kindships = data.get(2);
            participants = data.get(3);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se han cargado los datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        for (Pair<Integer, String> nationality : nationalities) {
            cmbNationalities.addItem(nationality.getSecond());
        }
        for (Pair<Integer, String> city : cities) {
            cmbProvinces.addItem(city.getSecond());
        }
        for (Pair<Integer, String> kindship : kindships) {
            cmbKindship.addItem(kindship.getSecond());
        }
        for (Pair<Integer, String> participantToAdd : participants) {
            modelListParticipants.addElement(participantToAdd.getSecond());
        }
    }
    public void UpdateImage(){
        try{
            lblImage.setText("");
            
            //Codigo para reescalar imagen en: https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon
            ImageIcon imageIcon = new ImageIcon(image); // load the image to a imageIcon
            Image imageTemp = imageIcon.getImage(); // transform it 
            imageTemp = imageTemp.getScaledInstance(lblImage.getWidth(), lblImage.getHeight(),  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
            imageIcon = new ImageIcon(imageTemp);

            lblImage.setIcon(imageIcon);
        } catch (Exception e){
            lblImage.setIcon(null);
            lblImage.setText("No se encontró imagen");
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblPhoto = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtSecondName = new javax.swing.JTextField();
        txtFirstSurname = new javax.swing.JTextField();
        txtSecondSurname = new javax.swing.JTextField();
        txtHeight = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtBiograph = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtTrivia = new javax.swing.JTextArea();
        cmbNationalities = new javax.swing.JComboBox<>();
        cmbProvinces = new javax.swing.JComboBox<>();
        cmbSex = new javax.swing.JComboBox<>();
        btnTip = new javax.swing.JButton();
        btnSelectImage = new javax.swing.JButton();
        dateChooser = new com.toedter.calendar.JDateChooser();
        lblImage = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listNationalities = new javax.swing.JList<>();
        btnAddNationality = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        listRelatives = new javax.swing.JList<>();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        listParticipants = new javax.swing.JList<>();
        btnAddRelative = new javax.swing.JButton();
        cmbKindship = new javax.swing.JComboBox<>();
        btnAccept = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Agregar participantes");

        jLabel2.setText("Sexo");

        jLabel3.setText("Primer nombre:");

        jLabel4.setText("Segundo nombre:");

        jLabel5.setText("Primer apellido:");

        jLabel6.setText("Segundo apellido:");

        jLabel7.setText("Fecha de nacimiento:");

        jLabel8.setText("Ciudad de nacimiento:");

        jLabel9.setText("Biografía:");

        jLabel10.setText("Altura:");

        jLabel11.setText("Dato de trivia:");

        lblPhoto.setText("Foto:");

        txtFirstName.setName("txtFirstName"); // NOI18N
        txtFirstName.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtFirstNameInputMethodTextChanged(evt);
            }
        });
        txtFirstName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });

        txtSecondName.setName("txtSecondName"); // NOI18N
        txtSecondName.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });

        txtFirstSurname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });

        txtSecondSurname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });

        jLabel13.setText("Nacionalidad:");

        txtBiograph.setColumns(20);
        txtBiograph.setRows(5);
        txtBiograph.setName("txtBiograph"); // NOI18N
        txtBiograph.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });
        jScrollPane1.setViewportView(txtBiograph);

        txtTrivia.setColumns(20);
        txtTrivia.setRows(5);
        txtTrivia.setName("txtTrivia"); // NOI18N
        txtTrivia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                LimitString(evt);
            }
        });
        jScrollPane2.setViewportView(txtTrivia);

        cmbProvinces.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbProvincesActionPerformed(evt);
            }
        });

        btnTip.setText("?");
        btnTip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTipActionPerformed(evt);
            }
        });

        btnSelectImage.setText("Seleccionar archivo");
        btnSelectImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectImageActionPerformed(evt);
            }
        });

        listNationalities.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(listNationalities);

        btnAddNationality.setText("+");
        btnAddNationality.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNationalityActionPerformed(evt);
            }
        });

        listRelatives.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listRelatives);

        jLabel12.setText("Familiares");

        listParticipants.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(listParticipants);

        btnAddRelative.setText("Añadir");
        btnAddRelative.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddRelativeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel10)
                            .addComponent(jLabel13)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFirstSurname, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSecondName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtSecondSurname, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtHeight)
                                    .addComponent(cmbNationalities, 0, 150, Short.MAX_VALUE)
                                    .addComponent(cmbProvinces, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnTip, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAddNationality, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(cmbSex, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel6)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                .addComponent(jScrollPane3))
                            .addComponent(jLabel12))
                        .addGap(154, 154, 154)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(btnAddRelative)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(cmbKindship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(110, 110, 110)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(lblPhoto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSelectImage)
                        .addGap(140, 140, 140))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPhoto)
                    .addComponent(btnSelectImage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblImage, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jLabel11)
                                .addGap(8, 8, 8)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnAddRelative)
                                    .addComponent(cmbKindship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(129, 129, 129))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtSecondName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtFirstSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtSecondSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cmbProvinces, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTip, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(cmbNationalities, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAddNationality))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        btnAccept.setText("Aceptar");
        btnAccept.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                btnAcceptInputMethodTextChanged(evt);
            }
        });
        btnAccept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAcceptActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancelar");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnAccept)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCancel)
                .addGap(45, 45, 45))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAccept)
                    .addComponent(btnCancel))
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAcceptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAcceptActionPerformed
        if (purpose.equals("View")) dispose();
        
        int pSex = cmbSex.getSelectedIndex()+1;
        String pFirstName = txtFirstName.getText();
        String pSecondName = txtSecondName.getText();
        String pFirstSurname = txtFirstSurname.getText();
        String pSecondSurname = txtSecondSurname.getText();
        int index = cmbProvinces.getSelectedIndex();
        int pCity, pNationality;
        if (index != -1) {
            pCity = cities.get(index).getFirst();
        } else {
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna ciudad","Error operación", 0);
            return;
        }
        
        if (modelListNationalities.getSize() == 0) {
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna nacionalidad", "Error operación", 0);
            return;
        }
        
        String pBiography = txtBiograph.getText();
        String pTrivia = txtTrivia.getText();
        //String pPhotoPath = imagePath;
        
        if (image == null) {
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna imagen.", "Error operación", 0);
        } else if (dateChooser.getDate() == null) {
            JOptionPane.showMessageDialog(this, "No se ha seleccionado ninguna fecha de nacimiento.", "Error operación", 0);
        } else if (pFirstName.equals("")) {
            JOptionPane.showMessageDialog(this, "No se ha ingresado dato en el campo: 'Primer nombre'", "Error operación", 0);
        } else if (pFirstSurname.equals("")) {
            JOptionPane.showMessageDialog(this, "No se ha ingresado dato en el campo: 'Primer apellido'", "Error operación", 0);
        } else if (pBiography.equals("")) {
            JOptionPane.showMessageDialog(this, "No se ha ingresado dato en el campo: 'Biografía'", "Error operación", 0);
        } else if (pTrivia.equals("")) {
            JOptionPane.showMessageDialog(this, "No se ha ingresado dato en el campo: 'Dato de Trivia'", "Error operación", 0);
        }
        
        else {
            String pDateBirth = sdf.format(dateChooser.getDate());
            try {
                Integer pHeight = Integer.valueOf(txtHeight.getText());
                
                int idParticipant = -1;
                if (purpose.equals("Create")) {
                    idParticipant = controller.insertParticipant (pSex, pFirstName, pSecondName,
                    pFirstSurname, pSecondSurname, pDateBirth, pCity,
                    pBiography, pHeight, pTrivia, image);
                } else if (purpose.equals("Edit")){
                    controller.updateParticipant (participant.idParticipant, pSex, pFirstName, pSecondName,
                    pFirstSurname, pSecondSurname, pDateBirth, pCity,
                    pBiography, pHeight, pTrivia, image);
                    idParticipant = participant.idParticipant;
                }
                
                for (int i = 0; i < modelListNationalities.getSize(); i++){
                    Pair<Integer, String> nationality = (Pair<Integer, String>) modelListNationalities.get(i);
                    int idNationality = nationality.getFirst();
                    if (participant == null) {
                        controller.addNationalityToPerson(idParticipant, idNationality);
                    } else {
                        if (!participant.getNationalities().contains(idNationality)){
                        controller.addNationalityToPerson(idParticipant, idNationality);
                        }
                    }
                }
                
                for (int i = 0; i < modelListRelatives.getSize(); i++){
                    Pair<Integer, String> relative = (Pair<Integer, String>) modelListRelatives.get(i);
                    int idRelative = relative.getFirst();
                    if (participant == null) {
                        
                        controller.insertRelative(idParticipant, idRelative, relative.getId());
                    } else {
                        if (!participant.getRelatives().containsKey(idRelative)){
                            controller.insertRelative(idParticipant, idRelative, relative.getId());
                        } 
                    }
                }
                
                JOptionPane.showMessageDialog(null, "Se ha insertado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Falló de conversión, tipo de dato altura debe ser númerico entero.", "Error operación", 0);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                JOptionPane.showMessageDialog(this, "Fallo inesperado. Vuelva a intentar.", "Error operación", 0);
            }
        }
        dispose();
    }//GEN-LAST:event_btnAcceptActionPerformed

    private void btnTipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTipActionPerformed
        // TODO add your handling code here:
        String msg = "Puedes seleccionar una letra y se mostraran los resultados que coincidan.";
        JOptionPane.showMessageDialog(null, msg, "Tip", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnTipActionPerformed

    private void btnSelectImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectImageActionPerformed
        // TODO add your handling code here:
        int result = fileWindow.showOpenDialog(this);
        
        if (result == JFileChooser.APPROVE_OPTION){
            File file = new File(fileWindow.getSelectedFile().getAbsolutePath());
            String imagePath = file.toString();
            FileInputStream fis;
            try {
                fis = new FileInputStream(imagePath);
                image = new byte[fis.available()];
                fis.read(image);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ParticipantWindow.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ParticipantWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        UpdateImage();
    }//GEN-LAST:event_btnSelectImageActionPerformed

    private void btnAcceptInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_btnAcceptInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAcceptInputMethodTextChanged

    private void txtFirstNameInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtFirstNameInputMethodTextChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstNameInputMethodTextChanged

    private void LimitString(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_LimitString
        // TODO add your handling code here:
        String name = evt.getComponent().getName();
        if (name != null && (name.equals("txtBiograph") || name.equals("txtTrivia"))){
            JTextArea txt = (JTextArea) evt.getComponent();
            if (txt.getText().length() > 500) evt.consume();
        }
        else {
            JTextField txt = (JTextField) evt.getComponent();
            if (txt.getText().length() > 20) evt.consume();
        }
    }//GEN-LAST:event_LimitString

    private void cmbProvincesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbProvincesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbProvincesActionPerformed

    private void btnAddNationalityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNationalityActionPerformed
        int index = cmbNationalities.getSelectedIndex();
        if (index != -1){
            Pair<Integer, String> nationality = nationalities.get(index);
            if (!modelListNationalities.contains(nationality)){
                nationality.setText(nationality.getSecond());
                modelListNationalities.addElement(nationality);
            }
        }
    }//GEN-LAST:event_btnAddNationalityActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnAddRelativeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddRelativeActionPerformed
        int index = listParticipants.getSelectedIndex();
        if (index != -1){
            Pair<Integer, String> participantToAdd = participants.get(index);
            int indexKindship = cmbKindship.getSelectedIndex();
            int idKindship = kindships.get(indexKindship).getFirst();
            if (!modelListRelatives.contains(participantToAdd)){
                participantToAdd.setText(participantToAdd.getSecond() + " : " + 
                        kindships.get(indexKindship).getSecond());
                participantToAdd.setId(idKindship);
                modelListRelatives.addElement(participantToAdd);
            }
        }
    }//GEN-LAST:event_btnAddRelativeActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAccept;
    private javax.swing.JButton btnAddNationality;
    private javax.swing.JButton btnAddRelative;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnSelectImage;
    private javax.swing.JButton btnTip;
    private javax.swing.JComboBox<String> cmbKindship;
    private javax.swing.JComboBox<String> cmbNationalities;
    private javax.swing.JComboBox<String> cmbProvinces;
    private javax.swing.JComboBox<String> cmbSex;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblImage;
    private javax.swing.JLabel lblPhoto;
    private javax.swing.JList<String> listNationalities;
    private javax.swing.JList<String> listParticipants;
    private javax.swing.JList<String> listRelatives;
    private javax.swing.JTextArea txtBiograph;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtFirstSurname;
    private javax.swing.JTextField txtHeight;
    private javax.swing.JTextField txtSecondName;
    private javax.swing.JTextField txtSecondSurname;
    private javax.swing.JTextArea txtTrivia;
    // End of variables declaration//GEN-END:variables
}
