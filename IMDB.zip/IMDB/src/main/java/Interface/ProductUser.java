package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import LogicClasses.Product;
import LogicClasses.RenderCell;
import LogicClasses.Triple;
import LogicClasses.User;
import java.awt.Image;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ProductUser extends javax.swing.JFrame {
    private PurchaseWindow purchaseWindow;
    
    private javax.swing.DefaultListModel modelListParticipants;
    ArrayList<Pair<Integer, String>> participants;
    LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>>seasons;
    private Controller controller = Controller.getInstance();
    private Product product;
    
    private ParticipantWindow participantWindow;
    private ReviewWindow reviewWindow;
    private ArrayList<Pair<Integer, byte[]>> images;
    private int imgIndex;
    private User user;
    private ArrayList<Triple<Integer, String, byte[]>> wishlist;
    private boolean hasFavorite;
    //private boolean historyView;
    
    /**
     * Creates new form ProductUser
     */
    public ProductUser() {
        initComponents();
        hasFavorite = false;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        purchaseWindow = new PurchaseWindow(this, true);
        participantWindow = new ParticipantWindow();
        reviewWindow = new ReviewWindow();
        modelListParticipants = new javax.swing.DefaultListModel();
        listParticipants.setCellRenderer(new RenderCell());
        listParticipants.setModel(modelListParticipants);
        user = User.getInstance();
        
        
        ImageIcon img = new ImageIcon("add-favorite-icon.png");
        Image imgA = img.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        
        ImageIcon imgIconBuy = new ImageIcon("buy-icon.png");
        Image imgBuy = imgIconBuy.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        imgIconBuy = new ImageIcon(imgBuy);
        
        btnAddFavorite.setIcon(new ImageIcon(imgA));
        btnAddFavorite.setText("Favoritos");
        btnAddFavorite.setContentAreaFilled(false);
        
        btnBuy.setIcon(imgIconBuy);
        btnBuy.setText("Comprar");
        btnBuy.setContentAreaFilled(false);
    }
    
    public void update() {
        hasFavorite = false;
        try {
                wishlist = controller.getUserFavorites(user.getId());
                int idProd = product.getIdProduct();
                for (Triple<Integer, String, byte[]> product : wishlist) {
                    product.setText(product.getSecond());
                    if (product.getFirst()==idProd) {
                        hasFavorite = true;
                    }
                }
                if (hasFavorite) {
                    labelFavorite.setText("Favorito");
                } else {
                    labelFavorite.setText("No Favorito");
                }
                //scrollWishlist.setVisible(true);
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "No se pudo cargar la lista de favoritos");
                Logger.getLogger(ProfileWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    private void clear(){
        modelListParticipants.clear();
        cmbSeasons.removeAllItems();
        cmbPlatforms.removeAllItems();
        cmbGenres.removeAllItems();
    }
    
    public void setAtributes(int idProduct) {
        clear();
        try {
            product = controller.getProductInfo(idProduct);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ProductUser.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        
        lblTitle.setText(product.getTitle());
        lblReleaseYear.setText("" + product.getReleaseYear());
        lblDuration.setText("" + product.getDuration());
        //lblTrailer.setText(trailer);
        lblPrice.setText("" + product.getPrice());
        txtSynopsis.setText(insertEnter(product.getSynopsis(), 50));
        
        images = product.getImages();
        if (product != null && product.getImages().isEmpty()) {
            byte[] image;
            FileInputStream fis;
            try {
                fis = new FileInputStream("DefaultImageProduct.png");
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
                product.addImage(-1, image);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ProductUser.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ProductUser.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        updateImage();
        
        participants = product.getParticipants();
        for (Pair<Integer, String> participant : participants) {
            participant.setText(participant.getSecond());
            modelListParticipants.addElement(participant);
        }
        
        //if (product.getIdType())
        
        this.seasons = product.getSeasons();
        Set<Integer> keys = seasons.keySet();
        for (Integer key : keys ) {
            String infoSeason;
            Pair<String[], ArrayList<String[]>> season;
            season = seasons.get(key);
            String[] arraySeason = season.getFirst();
            cmbSeasons.addItem(arraySeason[0] + "Duración: " + arraySeason[1]);
        }
        
        for (Pair<Integer, String> genre : product.getGenres()){
            cmbGenres.addItem(genre.getSecond());
        }
        for (Pair<Integer, String> platform : product.getPlatforms()){
            cmbPlatforms.addItem(platform.getSecond());
        }
        //The product is added to reciently visited list
        controller.visitProduct(user.getId(), idProduct);
    }
    public static String insertEnter(String text, int position) {
        StringBuilder strBuilder = new StringBuilder(text);
        int index = position;
        String enter = "\n";
        while (index < strBuilder.length()) {
            while (strBuilder.charAt(index) != ' ' || strBuilder.charAt(index) != '\0'){
                index++;
                if (index >= strBuilder.length()){
                    break;
                }
            }
            if (index < strBuilder.length()){
                strBuilder.insert(index, enter);
                index += position + enter.length();
            }
        }
        return strBuilder.toString();
    }
    public void updateImage(){
        try{
            image_label.setText("");
            ImageIcon imageIcon = new ImageIcon(images.get(imgIndex).getSecond()); // load the image to a imageIcon
            Image image = imageIcon.getImage(); // transform it 
            image = image.getScaledInstance(image_label.getWidth(), image_label.getHeight(),  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
            imageIcon = new ImageIcon(image);
            image_label.setIcon(imageIcon);
        } catch (Exception e){
            image_label.setIcon(null);
            image_label.setText("No se encontró imagen");
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listParticipants = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        labelSynopsis = new javax.swing.JLabel();
        cmbSeasons = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cmbEpisodes = new javax.swing.JComboBox<>();
        jPanel8 = new javax.swing.JPanel();
        bt_antImg1 = new javax.swing.JButton();
        bt_sigImg1 = new javax.swing.JButton();
        image_label = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        labelReleaseYear1 = new javax.swing.JLabel();
        lblReleaseYear = new javax.swing.JLabel();
        labelDuration1 = new javax.swing.JLabel();
        lblDuration = new javax.swing.JLabel();
        labelTrailer1 = new javax.swing.JLabel();
        lblTrailer = new javax.swing.JLabel();
        labelPrice1 = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        txtSynopsi = new javax.swing.JScrollPane();
        txtSynopsis = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        btnAddFavorite = new javax.swing.JButton();
        btnBuy = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        cmbGenres = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        cmbPlatforms = new javax.swing.JComboBox<>();
        labelFavorite = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblTitle.setText("Título");

        listParticipants.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listParticipants);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("Participantes");

        labelSynopsis.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelSynopsis.setText("Synopsis");

        cmbSeasons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbSeasonsActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Episodes");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Seasons");

        bt_antImg1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bt_antImg1.setText("<-");
        bt_antImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_antImg1ActionPerformed(evt);
            }
        });

        bt_sigImg1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bt_sigImg1.setText("->");
        bt_sigImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_sigImg1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(bt_antImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt_sigImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(image_label, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(image_label, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_antImg1)
                    .addComponent(bt_sigImg1))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        labelReleaseYear1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelReleaseYear1.setText("ReleaseYear");

        lblReleaseYear.setText("jLabel2");

        labelDuration1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelDuration1.setText("Duration");

        lblDuration.setText("jLabel2");

        labelTrailer1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelTrailer1.setText("Trailer");

        lblTrailer.setText("jLabel2");

        labelPrice1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelPrice1.setText("Precio");

        lblPrice.setText("jLabel2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelReleaseYear1)
                    .addComponent(lblReleaseYear)
                    .addComponent(labelDuration1)
                    .addComponent(lblDuration)
                    .addComponent(labelTrailer1)
                    .addComponent(lblTrailer)
                    .addComponent(labelPrice1)
                    .addComponent(lblPrice))
                .addContainerGap(123, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelReleaseYear1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblReleaseYear)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelDuration1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDuration)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelTrailer1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTrailer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelPrice1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPrice)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        txtSynopsis.setColumns(20);
        txtSynopsis.setRows(5);
        txtSynopsi.setViewportView(txtSynopsis);

        jButton2.setText("Reseñas");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnAddFavorite.setText("Favoritos");
        btnAddFavorite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddFavoriteActionPerformed(evt);
            }
        });

        btnBuy.setText("Comprar");
        btnBuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuyActionPerformed(evt);
            }
        });

        jButton1.setText("Ver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("Volver");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        cmbGenres.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Géneros");

        label.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        label.setText("Plataformas");

        cmbPlatforms.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSynopsi, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelSynopsis))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3)
                                            .addComponent(cmbSeasons, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(30, 30, 30)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(cmbEpisodes, 0, 154, Short.MAX_VALUE)
                                            .addComponent(jLabel2)
                                            .addComponent(label)
                                            .addComponent(cmbPlatforms, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jButton3)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(15, 15, 15)
                                                        .addComponent(jButton1))
                                                    .addComponent(jButton2))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel1)
                                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnAddFavorite)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnBuy))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelFavorite))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblTitle)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(49, 49, 49)
                                                .addComponent(jButton1)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton2)
                                        .addGap(28, 28, 28)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel2)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cmbSeasons, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbEpisodes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelSynopsis)))
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(txtSynopsi, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(jLabel4))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(label)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbPlatforms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(labelFavorite)
                                .addGap(5, 5, 5)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnAddFavorite)
                                    .addComponent(btnBuy))))))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbSeasonsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSeasonsActionPerformed
        int index = cmbSeasons.getSelectedIndex();
        cmbEpisodes.removeAllItems();
        Pair<String[], ArrayList<String[]>> season = seasons.get(index);
        ArrayList<String[]> episodes = season.getSecond();
        for (String[] episode : episodes ) {
            String episodeInfo = episode[1]+ " " + episode[2] + " Duration: " +episode[3];
            cmbEpisodes.addItem(episodeInfo);
        }
        
    }//GEN-LAST:event_cmbSeasonsActionPerformed

    private void bt_antImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_antImg1ActionPerformed
        if (imgIndex > 0)
            imgIndex --;
        updateImage();
    }//GEN-LAST:event_bt_antImg1ActionPerformed

    private void bt_sigImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_sigImg1ActionPerformed
        if (imgIndex < images.size() - 1)
            imgIndex ++;
        updateImage();
    }//GEN-LAST:event_bt_sigImg1ActionPerformed

    private void btnBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuyActionPerformed
        purchaseWindow.LoadData();
        purchaseWindow.setIdProduct(product.getIdProduct());
        purchaseWindow.setVisible(true);
    }//GEN-LAST:event_btnBuyActionPerformed

    private void btnAddFavoriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddFavoriteActionPerformed
        try {
            hasFavorite = false;
            int idProd = product.getIdProduct();
            int idUser = user.getId();
            Triple<Integer, String, byte[]> productSelected = new Triple<Integer, String, byte[]>(null,null,null);
            for (Triple<Integer, String, byte[]> product: wishlist) {
                if (product.getFirst()==idProd) {
                    hasFavorite = true;
                    productSelected = product;
                }
            } if (!hasFavorite) {
                controller.addFavorite(idUser, idProd);
                wishlist.add(new Triple<Integer,String,byte[]>(idProd,product.getTitle(),product.getImages().getFirst().getSecond()));
            } else {
                wishlist.remove(productSelected);
                controller.deleteFavorite(idUser, idProd);
            }
            if (!hasFavorite) {
                    labelFavorite.setText("Favorito");
                } else {
                    labelFavorite.setText("No Favorito");
                }
        } catch (SQLException ex) {
            Logger.getLogger(ProductUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnAddFavoriteActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        reviewWindow.setProduct(product);
        reviewWindow.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int index = listParticipants.getSelectedIndex();
        int idParticipant = participants.get(index).getFirst();
        participantWindow.setParticipant(idParticipant);
        participantWindow.setPurpose("View");
        participantWindow.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_antImg1;
    private javax.swing.JButton bt_sigImg1;
    private javax.swing.JButton btnAddFavorite;
    private javax.swing.JButton btnBuy;
    private javax.swing.JComboBox<String> cmbEpisodes;
    private javax.swing.JComboBox<String> cmbGenres;
    private javax.swing.JComboBox<String> cmbPlatforms;
    private javax.swing.JComboBox<String> cmbSeasons;
    private javax.swing.JLabel image_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label;
    private javax.swing.JLabel labelDuration1;
    private javax.swing.JLabel labelFavorite;
    private javax.swing.JLabel labelPrice1;
    private javax.swing.JLabel labelReleaseYear1;
    private javax.swing.JLabel labelSynopsis;
    private javax.swing.JLabel labelTrailer1;
    private javax.swing.JLabel lblDuration;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblReleaseYear;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTrailer;
    private javax.swing.JList<String> listParticipants;
    private javax.swing.JScrollPane txtSynopsi;
    private javax.swing.JTextArea txtSynopsis;
    // End of variables declaration//GEN-END:variables
}
