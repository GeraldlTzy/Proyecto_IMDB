package Interface;

import LogicClasses.Controller;
import LogicClasses.DataCreation;
import LogicClasses.Episode;
import LogicClasses.Pair;
import LogicClasses.Product;
import LogicClasses.RenderCell;
import LogicClasses.Triple;
import java.awt.Image;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

public class ProductWindow extends javax.swing.JFrame {

    private Controller controller;
    private ParticipantWindow participantWindow;
    private ArrayList<Pair<byte[], String>> participants;
    private javax.swing.DefaultListModel modelListParticipants;
    private javax.swing.DefaultListModel<String> modelListAddedParticipants;
    private javax.swing.DefaultListModel modelListGenres;
    private javax.swing.DefaultListModel modelListPlatforms;
    
    private ArrayList<Triple<Integer, String, Integer>> addedParticipants;
    private ArrayList<Pair<Integer, String>> roles;
    private ArrayList<Pair<Integer, String>> typeProducts;
    private ArrayList<Pair<Integer, String>> genres;
    private ArrayList<Pair<Integer, String>> platforms;
    private ArrayList<Pair<Integer, byte[]>> images;
    private JFileChooser fileWindow;
    private int imgIndex;
    private String purpose = null;
    private int idProduct;
    private Product product = null;
    
    /**Actualizados*/
    private javax.swing.DefaultListModel modelListAddedSeasons;
    private javax.swing.DefaultListModel modelListEpisodes;
    private ArrayList<Integer> deleteEpisodes;
    private ArrayList<Integer> deleteSeasons;
    private ArrayList<Integer> deleteImages;
    private ArrayList<Integer> addGenres;
    private ArrayList<Integer> addPlatforms;
    /********************For delete elements*******************************/
    private ArrayList<Integer> deleteParticipant;
            
    public ProductWindow() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        controller = Controller.getInstance();
        participantWindow = new ParticipantWindow();
        participants = new ArrayList<>();
        images = new ArrayList<>();
        genres = new ArrayList<>();
        
        fileWindow = new JFileChooser();
        imgIndex = 0;
        addedParticipants = new ArrayList<>();
        modelListParticipants = new javax.swing.DefaultListModel();
        modelListAddedParticipants = new javax.swing.DefaultListModel();
        
        modelListAddedSeasons = new javax.swing.DefaultListModel();
        listParticipants.setModel(modelListParticipants);
        listParticipants.setCellRenderer(new RenderCell());
        listAddedParticipants.setModel(modelListAddedParticipants);
        
        listSeasons.setCellRenderer(new RenderCell());
        listSeasons.setModel(modelListAddedSeasons);
        roles = new ArrayList<>();
        
        modelListEpisodes = new javax.swing.DefaultListModel();
        listEpisode.setCellRenderer(new RenderCell());
        listEpisode.setModel(modelListEpisodes);
        
        addGenres = new ArrayList();
        modelListGenres = new javax.swing.DefaultListModel();
        listGenres.setCellRenderer(new RenderCell());
        listGenres.setModel(modelListGenres);
        
        /*****************************Platforms********************************/
        addPlatforms = new ArrayList();
        platforms = new ArrayList();
        modelListPlatforms = new javax.swing.DefaultListModel();
        listPlatforms.setModel(modelListPlatforms);
        listPlatforms.setCellRenderer(new RenderCell());
        /********************For delete elements*******************************/
        deleteParticipant = new ArrayList<>();
        deleteEpisodes = new ArrayList();
        deleteSeasons = new ArrayList();
        deleteImages = new ArrayList();
        cmbTypeProduct.removeAllItems();
        cmbRoles.removeAllItems();
        
        }
    
    public void setPurpose(String purpose) {
        clear();
        this.purpose = purpose;
    }
    
    public void LoadData() {
        try {
            DataCreation data;
            data = controller.getInfoCreationProduct();
            participants = data.getParticipants();
            roles = data.getRoles();
            typeProducts = data.getTypes();
            genres = data.getGenres();
            platforms = data.getPlatforms();
            
            for (Pair<byte[], String> participant: participants) {
                participant.setText(participant.getSecond());
                modelListParticipants.addElement(participant);
            }
            for (Pair<Integer, String> typeProduct : typeProducts){
                cmbTypeProduct.addItem(typeProduct.getSecond());
            }
            for (Pair<Integer, String> role : roles){
                cmbRoles.addItem(role.getSecond());
            }
            for (Pair<Integer, String> genre : genres){
                cmbGenres.addItem(genre.getSecond());
            }
            for (Pair<Integer, String> platform : platforms){
                cmbPlatforms.addItem(platform.getSecond());
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clear() {
        /****Structures****/
        roles.clear();
        product = null;
        purpose = null;
        idProduct = -1;
        /****Interfaz******/
        cmbTypeProduct.removeAllItems();
        cmbRoles.removeAllItems();
        
        /*******Images**************/
        images.clear();
        deleteImages.clear();
        imgIndex = 0;
        /*******Participants********/
        modelListParticipants.clear();
        modelListAddedParticipants.clear();
        deleteParticipant.clear();
        participants.clear();
        addedParticipants.clear();
        /*******Seasons*************/
        modelListAddedSeasons.clear();
        deleteSeasons.clear();
        /*******Episodes************/
        modelListEpisodes.clear();
        deleteEpisodes.clear();
        /*******Genres**************/
        cmbGenres.removeAllItems();
        modelListGenres.clear();
        genres.clear();
        addGenres.clear();
        /*******Platforms***********/
        cmbPlatforms.removeAllItems();
        modelListPlatforms.removeAllElements();
        platforms.clear();
        addPlatforms.clear();
    }
    
    public void setProductInformation(Integer idProduct) {
        try {
            LoadData();
            product = controller.getProductInfo(idProduct);
            this.idProduct = product.getIdProduct();
            /**************Put the information in the table Product************/
            txtReleaseYear.setText("" + product.getReleaseYear());
            txtTitle.setText("" + product.getTitle());
            txtDuration.setText("" + product.getDuration());
            txtTrailer.setText("" + product.getTrailer());
            txtSynopsis.setText("" + product.getSynopsis());
            txtPrice.setText("" + product.getPrice());
            int i; i = 0;                   
            for (Pair<Integer, String> type : typeProducts){
                int id = type.getFirst();
                if (id == product.getIdType()){
                    cmbTypeProduct.setSelectedIndex(i);
                }
                i++;
            }          
            /********************Participants**********************************/
            ArrayList<Pair<Integer,String>> participantsDB;
            participantsDB = product.getParticipants();
            for (Pair<Integer, String> participant : participantsDB) {
                modelListAddedParticipants.addElement(participant.getSecond());
            }
            /*****************Season and Episodes Tables***********************/
            LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>> seasons;
            seasons = product.getSeasons();

            seasons.forEach((k,v) -> {
                //Number of season
                Pair<String, String> season = new Pair<>(v.getFirst()[1], v.getFirst()[1]);
                season.setId(k);
                season.setText(v.getFirst()[0] + " Duración: " + v.getFirst()[1]);
                modelListAddedSeasons.addElement(season);                
                int index = modelListAddedSeasons.getSize() - 1;

                for (String[] episode : v.getSecond()) {
                    Episode epi = new Episode(Integer.parseInt(episode[0]), index,
                    Integer.parseInt(episode[3]), episode[2], Integer.parseInt(episode[1]));
                    modelListEpisodes.addElement(epi);
                }
            });
            /******************************Images******************************/
            images = product.getImages();
            /******************************************************************/
            for (Pair<Integer, String> genre : product.getGenres()){
                genre.setId(genre.getFirst());
                genre.setText(genre.getSecond());
                modelListGenres.addElement(genre);
            }
            /******************************************************************/
            for (Pair<Integer, String> platform : product.getPlatforms()){
                //platform.setId(genre.getFirst());
                platform.setText(platform.getSecond());
                modelListPlatforms.addElement(platform);
            }
            
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtReleaseYear = new javax.swing.JTextField();
        txtDuration = new javax.swing.JTextField();
        txtTrailer = new javax.swing.JTextField();
        txtTitle = new javax.swing.JTextField();
        cmbTypeProduct = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtSynopsis = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listParticipants = new javax.swing.JList<>();
        btnParticipant = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnAddParticipant = new javax.swing.JButton();
        cmbRoles = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtNumberSeason = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtNumberEpisode = new javax.swing.JTextField();
        txtNameEpisode = new javax.swing.JTextField();
        txtDurationEpisode = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        listSeasons = new javax.swing.JList<>();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btnAddSeason = new javax.swing.JButton();
        btnAddEpisode = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        g = new javax.swing.JScrollPane();
        listEpisode = new javax.swing.JList<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        listGenres = new javax.swing.JList<>();
        jLabel23 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        cmbGenres = new javax.swing.JComboBox<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        listPlatforms = new javax.swing.JList<>();
        jLabel24 = new javax.swing.JLabel();
        cmbPlatforms = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listAddedParticipants = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        image_label = new javax.swing.JLabel();
        bt_antImg1 = new javax.swing.JButton();
        bt_sigImg1 = new javax.swing.JButton();
        bt_agregarImg1 = new javax.swing.JButton();
        bt_eliminarImg1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        btnCancel = new javax.swing.JButton();
        btnAccept = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("Tipo de producto:");

        jLabel3.setText("Año de estreno:");

        jLabel4.setText("Título:");

        jLabel5.setText("Duración:");

        jLabel6.setText("Trailer:");

        jLabel7.setText("Synopsis:");

        txtReleaseYear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                IntFieldText(evt);
            }
        });

        cmbTypeProduct.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbTypeProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTypeProductActionPerformed(evt);
            }
        });

        txtSynopsis.setColumns(20);
        txtSynopsis.setRows(5);
        jScrollPane3.setViewportView(txtSynopsis);

        jLabel12.setText("Precio");

        jLabel1.setText("Agregar Productos");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtDuration, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtReleaseYear)
                            .addComponent(cmbTypeProduct, 0, 150, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTrailer, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(0, 17, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbTypeProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtReleaseYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDuration, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtTrailer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        listParticipants.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listParticipants);

        btnParticipant.setText("Ver información");
        btnParticipant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParticipantActionPerformed(evt);
            }
        });

        jLabel8.setText("Agregar participantes");

        btnAddParticipant.setText("Agregar");
        btnAddParticipant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddParticipantActionPerformed(evt);
            }
        });

        cmbRoles.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbRoles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbRolesActionPerformed(evt);
            }
        });

        jLabel11.setText("Rol:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(btnParticipant))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbRoles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnAddParticipant))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbRoles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(btnAddParticipant))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnParticipant)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jLabel9.setText("Agregar temporadas:");

        jLabel15.setText("Numero de temporada:");

        jLabel17.setText("Agregar episodios: Debe seleccionar la temporada");

        jLabel18.setText("Número de episodio:");

        jLabel19.setText("Nombre:");

        jLabel20.setText("Duración:");

        listSeasons.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(listSeasons);

        jLabel21.setText("Temporadas:");

        jLabel22.setText("Episodios:");

        btnAddSeason.setText("Añadir");
        btnAddSeason.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddSeasonActionPerformed(evt);
            }
        });

        btnAddEpisode.setText("Añadir");
        btnAddEpisode.setToolTipText("");
        btnAddEpisode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddEpisodeActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        listEpisode.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        g.setViewportView(listEpisode);

        listGenres.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(listGenres);

        jLabel23.setText("Agregar categorías");

        jButton4.setText("+");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        cmbGenres.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        listPlatforms.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane6.setViewportView(listPlatforms);

        jLabel24.setText("Plataformas");

        cmbPlatforms.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jButton5.setText("+");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(btnAddSeason))
                        .addGap(143, 143, 143)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel20)
                                    .addComponent(btnAddEpisode))
                                .addGap(27, 27, 27)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNameEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNumberEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDurationEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton4))))
                            .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtNumberSeason, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addGap(115, 115, 115)
                        .addComponent(jLabel22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(g, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(cmbPlatforms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5)))
                .addGap(154, 154, 154))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jButton2)
                .addGap(135, 135, 135)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel17))
                .addGap(5, 5, 5)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtNumberSeason, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(txtNumberEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAddSeason)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(txtNameEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(txtDurationEpisode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAddEpisode)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel21)
                                .addComponent(jLabel22)
                                .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane6)
                            .addComponent(jScrollPane5)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(g))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton3)))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbPlatforms, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5))))
        );

        jLabel10.setText("Participantes");

        listAddedParticipants.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(listAddedParticipants);

        jButton1.setText("Eliminar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jButton1))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(0, 247, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                .addContainerGap())
        );

        bt_antImg1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bt_antImg1.setText("<-");
        bt_antImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_antImg1ActionPerformed(evt);
            }
        });

        bt_sigImg1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bt_sigImg1.setText("->");
        bt_sigImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_sigImg1ActionPerformed(evt);
            }
        });

        bt_agregarImg1.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        bt_agregarImg1.setText("+");
        bt_agregarImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_agregarImg1ActionPerformed(evt);
            }
        });

        bt_eliminarImg1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        bt_eliminarImg1.setText("-");
        bt_eliminarImg1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_eliminarImg1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(image_label, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(bt_antImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt_agregarImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(bt_eliminarImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(bt_sigImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(image_label, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bt_antImg1)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bt_sigImg1)
                        .addComponent(bt_eliminarImg1)
                        .addComponent(bt_agregarImg1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jLabel13.setText("Imagenes");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel14.setText("Agregar elementos al producto:");

        btnCancel.setText("Cancelar");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnAccept.setText("Aceptar");
        btnAccept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAcceptActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(44, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAccept)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancel)
                                .addGap(20, 20, 20))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCancel)
                            .addComponent(btnAccept))
                        .addGap(18, 18, 18))))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnParticipantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParticipantActionPerformed
        // TODO add your handling code here:
        int index = listParticipants.getSelectedIndex();
        int idParticipant = participants.get(index).getId();
        participantWindow.setParticipant(idParticipant);
        participantWindow.setPurpose("Edit");
        participantWindow.setVisible(true);
    }//GEN-LAST:event_btnParticipantActionPerformed

    private void btnAddParticipantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddParticipantActionPerformed
        // TODO add your handling code here:
        int index = listParticipants.getSelectedIndex();
        int indexRole = cmbRoles.getSelectedIndex();
        int roleId = roles.get(indexRole).getFirst();
        String roleName = roles.get(indexRole).getSecond();
        Integer participantId = ((Pair<byte[], String>)modelListParticipants.get(index)).getId();
        String participantName = ((Pair<byte[], String>)modelListParticipants.get(index)).getInfo();
        for (Triple<Integer, String, Integer> participant : addedParticipants){
            if ((int)participant.getFirst() == participantId)
                return;
        }
        Triple<Integer, String, Integer> participant;
        participant = new Triple<>(participantId, participantName, roleId);
        if (purpose.equals("Edit") && product != null){
            if (product.contains(participantId))
                return;
        }
        addedParticipants.add(participant);
        modelListAddedParticipants.addElement(participantName + " - " + roleName);
    }//GEN-LAST:event_btnAddParticipantActionPerformed

    private void bt_antImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_antImg1ActionPerformed
        if (imgIndex > 0)
            imgIndex --;
        updateImage();
    }//GEN-LAST:event_bt_antImg1ActionPerformed

    private void bt_sigImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_sigImg1ActionPerformed
        if (imgIndex < images.size() - 1)
            imgIndex ++;
        updateImage();
    }//GEN-LAST:event_bt_sigImg1ActionPerformed
    public void updateImage(){
        try{
            image_label.setText("");
            //Codigo para reescalar imagen en: https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon
            ImageIcon imageIcon = new ImageIcon(images.get(imgIndex).getSecond()); // load the image to a imageIcon
            Image image = imageIcon.getImage(); // transform it 
            image = image.getScaledInstance(image_label.getWidth(), image_label.getHeight(),  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
            imageIcon = new ImageIcon(image);
            image_label.setIcon(imageIcon);
        } catch (Exception e){
            image_label.setIcon(null);
            image_label.setText("No se encontró imagen");
        }
    }
    private void bt_agregarImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_agregarImg1ActionPerformed
        int result = fileWindow.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION){
            FileInputStream fis = null;
            try {
                File file = new File(fileWindow.getSelectedFile().getAbsolutePath());
                fis = new FileInputStream(file.toString());
                byte[] blobBytes = new byte[fis.available()];
                fis.read(blobBytes);
                fis.close();
                images.add(new Pair<>(-1, blobBytes));
                imgIndex = images.size() - 1;
                updateImage();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (fis != null) fis.close();
                } catch (IOException ex) {
                    Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_bt_agregarImg1ActionPerformed

    private void bt_eliminarImg1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_eliminarImg1ActionPerformed
        if (!images.isEmpty()){
            int idImage;
            idImage = images.get(imgIndex).getFirst();
            if (idImage != -1){
                deleteImages.add(idImage);/*Delete object saved in the DB*/
            }
            images.remove(imgIndex);
            if (imgIndex > 0)
                imgIndex --;
            updateImage();
        }
    }//GEN-LAST:event_bt_eliminarImg1ActionPerformed

    private void btnAcceptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAcceptActionPerformed
        idProduct = setProduct(); /*Add the basic information about products*/
        
        if (idProduct != -1){
            try {
                /*Remove participants*/
                for (int id : deleteParticipant){
                    controller.removeParticipantToProduct(idProduct, id);
                }
                /*Add participant to the product*/
                for (Triple<Integer, String, Integer> participant : addedParticipants) {
                    controller.addParticipantToProduct(idProduct, participant.getFirst(), participant.getThird());
                }
                /*Add the season with there episodes*/
                for (int i = 0; i < modelListAddedSeasons.getSize(); i++){
                    Pair<Integer, Integer> season = (Pair) modelListAddedSeasons.get(i);
                    if (season.getId() == -1) {/*If the id is different that -1, it's saved in the DB*/
                        int idSeason = controller.addSeason(idProduct, season.getFirst());
                        season.setId(idSeason);
                    }
                    /*Add a episode in new season*/
                    for (int j = 0; j < modelListEpisodes.getSize(); j++){
                        Episode episode = (Episode) modelListEpisodes.get(j);
                        if (episode.getId() == -1 && episode.idSeason == i) {
                            controller.addEpisode(season.getId(), episode.number,
                                    episode.name, episode.duration);
                            modelListEpisodes.remove(j);
                            j--;
                        }
                    }
                }
                /*Add the product images*/
                for (Pair<Integer, byte[]> image : images) {
                    if (image.getFirst() == -1)
                        controller.addImageToProduct(idProduct, image.getSecond());
                }
                
                for (int i = 0; i < addGenres.size(); i++){
                    controller.addGenreProduct(addGenres.get(i), idProduct);
                }
                
                for (int i = 0; i < addPlatforms.size(); i++){
                    controller.addPlatformProduct(addPlatforms.get(i), idProduct);
                }
                
                /********Delete episode**********************/
                for (int i = 0; i < deleteEpisodes.size(); i++)
                {controller.removeEpisode(deleteEpisodes.get(i));}
                /*********Delete seasons*********************/
                for (int i = 0; i < deleteSeasons.size(); i++)
                {controller.removeSeason(deleteSeasons.get(i));}
                /***********Delete images********************/
                for (int i = 0; i < deleteImages.size(); i++)
                {controller.removePhoto(deleteImages.get(i));}
                
                JOptionPane.showMessageDialog(null, "Se ha realizado la operación con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
            } catch (SQLException ex) {
                //Logger.getLogger(ProductWindow.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(this, "Error: No se pudo ingresar el producto.", "Error operación", 0);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: No se pudo añadir la imagen al producto.", "Error operación", 0);
            }
        }
        clear();
        dispose();
    }//GEN-LAST:event_btnAcceptActionPerformed
    int setProduct(){
        int idTypeProduct = typeProducts.get(cmbTypeProduct.getSelectedIndex()).getFirst();
        int releaseYear;
        int duration;
        int price;
        /*Valid release year*/
        try {
            releaseYear = Integer.parseInt(txtReleaseYear.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Falló de conversión, tipo de dato 'Fecha de estreno' debe ser númerico entero.", "Error operación", 0);
            return -1;
        }
        /*Valid duration*/
        try {
            duration = Integer.parseInt(txtDuration.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Falló de conversión, tipo de dato 'Duración' debe ser númerico entero.", "Error operación", 0);
            return -1;
        }
        /*Valid price*/
        try {
            price = Integer.parseInt(txtPrice.getText());
        } catch (NumberFormatException ex) {
            throwMessageDialog("Falló de conversión, tipo de dato 'Price' debe ser númerico entero.");
            return -1;
        }
        
        if (txtTitle.getText().equals("")) {
            throwMessageDialog("Error: Título no puede estar vacío.");
        } else if (txtTrailer.getText().equals("")){
            throwMessageDialog("Error: Campo 'Trailer' no puede estar vacío.");
        } else if (txtSynopsis.getText().equals("")) {
            throwMessageDialog("Error: Campo 'Synopsis' no puede estar vacío.");
        } else {
            //int idProduct = -1;
            if (purpose.equals("Create")) {
                try {    
                    idProduct = controller.insertProduct(idTypeProduct, releaseYear, txtTitle.getText(),
                        duration, txtTrailer.getText(), txtSynopsis.getText(), price);
                }
                 catch (SQLException ex) {
                    throwMessageDialog("Error: No se pudo añadir el producto.");
                }
            } else {
                try {
                    controller.updateProduct(idProduct, idTypeProduct, releaseYear, txtTitle.getText(),
                            duration, txtTrailer.getText(), txtSynopsis.getText(), price);
                } catch (SQLException ex) {
                    throwMessageDialog("Error: No se pudo actualizar el producto.");
                    return -1;
                }
            }
            return idProduct;
        }
        return -1;
    }
    private void throwMessageDialog(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error operación", 0);
    }
    private void btnAddSeasonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddSeasonActionPerformed
        // TODO add your handling code here:
        try {
            int numberSeason = Integer.parseInt(txtNumberSeason.getText());
            Pair<Integer, Integer> season = new Pair<>(numberSeason, 0);
            season.setId(-1);
            season.setText(txtNumberSeason.getText());
            modelListAddedSeasons.addElement(season);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: Falló de lectura, campos deben ser númericos.", "Error operación", 0);
        }
        
    }//GEN-LAST:event_btnAddSeasonActionPerformed

    private void btnAddEpisodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddEpisodeActionPerformed
        // TODO add your handling code here:
        int indexSeason = listSeasons.getSelectedIndex();
        if (indexSeason < 0) {
            JOptionPane.showMessageDialog(this, "Error: No ha seleccionado una temporada a la cual añadir el episodio.",
                    "Error operación", 0);
            return;
        }
        try{
            int numberEpisode = Integer.parseInt(txtNumberEpisode.getText());
            int durationEpisode = Integer.parseInt(txtDurationEpisode.getText());
            Episode episode = new Episode(-1, indexSeason, numberEpisode, txtNameEpisode.getText(), durationEpisode);
            modelListEpisodes.addElement(episode);
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: Falló de lectura, campos 'duración' y 'numero de episodio' deben ser númericos.",
                    "Error operación", 0);
        } 
    }//GEN-LAST:event_btnAddEpisodeActionPerformed

    private void cmbTypeProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTypeProductActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTypeProductActionPerformed

    private void IntFieldText(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_IntFieldText
        // TODO add your handling code here:        
        char character = evt.getKeyChar();
        JTextField txt = (JTextField) evt.getComponent();
        if ((character>='0' && character<='9')|| character==8) {
            txt.setEditable(true);
        } else {
            txt.setEditable(false);
            txt.setEditable(false);
        }

    }//GEN-LAST:event_IntFieldText

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        dispose();
        clear();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int index = listAddedParticipants.getSelectedIndex();
        if (index >= 0){
            if(product != null) {
                if (index < product.getParticipants().size()){
                    int idParticipant = product.getParticipants().get(index).getFirst();
                    product.deleteParticipant(idParticipant);
                    deleteParticipant.add(idParticipant);
                } else {
                    int fakeIndex = index-product.getParticipants().size();
                    addedParticipants.remove(fakeIndex);
                }
                modelListAddedParticipants.remove(index);
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (!listSeasons.isSelectionEmpty()){
            int index = listSeasons.getSelectedIndex();
            
            Pair<Integer, Integer> season = (Pair<Integer, Integer>) modelListAddedSeasons.get(index);
            int id = season.getId();
            
            if (id != -1){
                deleteSeasons.add(id);
            }
            for (int i = 0; i < modelListEpisodes.getSize(); i++){
                Episode episode = (Episode) modelListEpisodes.get(i);
                if (episode.idSeason == index){
                    if (episode.id != -1)
                        deleteEpisodes.add(episode.id);
                    modelListEpisodes.remove(i);
                    i--;
                }

            }
            modelListAddedSeasons.remove(index);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (!listEpisode.isSelectionEmpty()){
            int index = listEpisode.getSelectedIndex();
            Episode episode = (Episode) modelListEpisodes.get(index);
            if (episode.id != -1) {
                deleteEpisodes.add(episode.id);
            }
            modelListEpisodes.remove(index);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int indexGenre = cmbGenres.getSelectedIndex();
        Pair<Integer, String> genre = genres.get(indexGenre);
        //genre.setId(genre.getFirst());
        genre.setText(genre.getSecond());
        
        if (purpose.equals("Edit") && product != null){
            if (product.containsGenre(genre))
                return;
        }
        modelListGenres.addElement(genre);
        addGenres.add(genre.getFirst());
    }//GEN-LAST:event_jButton4ActionPerformed

    private void cmbRolesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRolesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRolesActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int indexGenre = cmbPlatforms.getSelectedIndex();
        Pair<Integer, String> platform = platforms.get(indexGenre);
        if (purpose.equals("Edit") && product != null){
            if (modelListPlatforms.contains(platform))
                return;
        }
        platform.setText(platform.getSecond());
        modelListPlatforms.addElement(platform);
        addPlatforms.add(platform.getFirst());
    }//GEN-LAST:event_jButton5ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_agregarImg1;
    private javax.swing.JButton bt_antImg1;
    private javax.swing.JButton bt_eliminarImg1;
    private javax.swing.JButton bt_sigImg1;
    private javax.swing.JButton btnAccept;
    private javax.swing.JButton btnAddEpisode;
    private javax.swing.JButton btnAddParticipant;
    private javax.swing.JButton btnAddSeason;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnParticipant;
    private javax.swing.JComboBox<String> cmbGenres;
    private javax.swing.JComboBox<String> cmbPlatforms;
    private javax.swing.JComboBox<String> cmbRoles;
    private javax.swing.JComboBox<String> cmbTypeProduct;
    private javax.swing.JScrollPane g;
    private javax.swing.JLabel image_label;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JList<String> listAddedParticipants;
    private javax.swing.JList<String> listEpisode;
    private javax.swing.JList<String> listGenres;
    private javax.swing.JList<String> listParticipants;
    private javax.swing.JList<String> listPlatforms;
    private javax.swing.JList<String> listSeasons;
    private javax.swing.JTextField txtDuration;
    private javax.swing.JTextField txtDurationEpisode;
    private javax.swing.JTextField txtNameEpisode;
    private javax.swing.JTextField txtNumberEpisode;
    private javax.swing.JTextField txtNumberSeason;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtReleaseYear;
    private javax.swing.JTextArea txtSynopsis;
    private javax.swing.JTextField txtTitle;
    private javax.swing.JTextField txtTrailer;
    // End of variables declaration//GEN-END:variables
}
