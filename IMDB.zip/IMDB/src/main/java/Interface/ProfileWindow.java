package Interface;

import LogicClasses.Controller;
import LogicClasses.RenderCell;
import LogicClasses.Triple;
import LogicClasses.User;
import java.awt.Image;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class ProfileWindow extends javax.swing.JFrame {

    private Controller controller = Controller.getInstance();
    private User user = User.getInstance();
    ProductUser productUser;
    private UpdateUserWindow updateUserWindow;
    
    private ArrayList<Triple<Integer, String, byte[]>> wishlist;
    private javax.swing.DefaultListModel modelListWishlist;
    public ProfileWindow() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        productUser = new ProductUser();
        
        btnSeeWishlist.setBorderPainted(false);
        
        
        ImageIcon img = new ImageIcon("favorite-icon.png");
        
        Image imgA = img.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        btnSeeWishlist.setIcon(new ImageIcon(imgA));
        btnSeeWishlist.setText("Favoritos");
        btnSeeWishlist.setContentAreaFilled(false);
        
        modelListWishlist = new javax.swing.DefaultListModel();
        listWishlist.setCellRenderer(new RenderCell());
        listWishlist.setModel(modelListWishlist);
        listWishlist.setVisible(false);
        //scrollWishlist.setVisible(false);
        
        wishlist = new ArrayList();
    }

    public void LoadData(){
        ImageIcon icon = new ImageIcon(user.getPhoto());
        Image image = icon.getImage().getScaledInstance(jPanel3.getWidth(),jPanel3.getHeight() , Image.SCALE_SMOOTH);
        icon = new ImageIcon(image);
        lblProfilePicture.setIcon(icon);
        lblUsername.setText(user.getUsername());
        lblBirthdate.setText(user.getBirthdate());
        lblPhone.setText(user.getPhoneNumber());
        lblMail.setText(user.getEmail());
        lblSex.setText(user.getSex());
        lblFirstName.setText(user.getFirstName());
        lblFirstSurname.setText(user.getFirstSurname());
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnSeeWishlist = new javax.swing.JButton();
        scrollWishlist = new javax.swing.JScrollPane();
        listWishlist = new javax.swing.JList<>();
        jPanel2 = new javax.swing.JPanel();
        lblUsername = new javax.swing.JLabel();
        lblMail = new javax.swing.JLabel();
        lblBirthdate = new javax.swing.JLabel();
        lblSex = new javax.swing.JLabel();
        lblIdentification = new javax.swing.JLabel();
        lblPhone = new javax.swing.JLabel();
        lblFirstName = new javax.swing.JLabel();
        lblFirstSurname = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblProfilePicture = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        btnSeeWishlist.setText("jButton1");
        btnSeeWishlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeeWishlistActionPerformed(evt);
            }
        });

        scrollWishlist.setBackground(new java.awt.Color(153, 153, 255));

        listWishlist.setBackground(new java.awt.Color(153, 153, 255));
        listWishlist.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        listWishlist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                SeeFavorite(evt);
            }
        });
        scrollWishlist.setViewportView(listWishlist);

        lblUsername.setText("Username");

        lblMail.setText("Mail");

        lblBirthdate.setText("Birthdate");

        lblSex.setText("Sexo");

        lblIdentification.setText("Identification");

        lblPhone.setText("phone");

        lblFirstName.setText("FirstName");

        lblFirstSurname.setText("FirstSurname");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSex)
                    .addComponent(lblIdentification)
                    .addComponent(lblPhone)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblUsername)
                            .addComponent(lblMail)
                            .addComponent(lblBirthdate))
                        .addGap(83, 83, 83)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblFirstSurname)
                            .addComponent(lblFirstName))))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUsername)
                    .addComponent(lblFirstName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMail)
                    .addComponent(lblFirstSurname))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBirthdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSex)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblIdentification)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPhone)
                .addContainerGap(116, Short.MAX_VALUE))
        );

        lblProfilePicture.setText("Sin foto");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblProfilePicture, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblProfilePicture, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jButton1.setText("Actualizar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(scrollWishlist, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSeeWishlist)
                .addGap(97, 97, 97))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnSeeWishlist, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrollWishlist, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jButton1))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSeeWishlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeeWishlistActionPerformed
        if (!listWishlist.isVisible()){
            try {
                wishlist = controller.getUserFavorites(user.getId());
                for (Triple<Integer, String, byte[]> product : wishlist) {
                    product.setText(product.getSecond());
                    modelListWishlist.addElement(product);
                }
                //scrollWishlist.setVisible(true);
                listWishlist.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(ProfileWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnSeeWishlistActionPerformed

    private void SeeFavorite(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SeeFavorite
        if (listWishlist.getSelectedIndex() >=0) { 
            int indexObject = listWishlist.getSelectedIndex();
            int idObject = wishlist.get(indexObject).getFirst();
            productUser.setAtributes(idObject);
            productUser.setVisible(true);
        }
    }//GEN-LAST:event_SeeFavorite

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        updateUserWindow = new UpdateUserWindow();
        updateUserWindow.setUser();
        updateUserWindow.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSeeWishlist;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblBirthdate;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblFirstSurname;
    private javax.swing.JLabel lblIdentification;
    private javax.swing.JLabel lblMail;
    private javax.swing.JLabel lblPhone;
    private javax.swing.JLabel lblProfilePicture;
    private javax.swing.JLabel lblSex;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JList<String> listWishlist;
    private javax.swing.JScrollPane scrollWishlist;
    // End of variables declaration//GEN-END:variables
}
