package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class RegisterWindow extends javax.swing.JFrame {

    String typeUser;
    String photoDirectory;
    String photoName;
    String date;
    Integer idSex;
    Integer idTypeOfId;
    boolean hasImage;
    boolean allowRegister;
    ArrayList<Pair<Integer,String>> sexes;
    ArrayList<Pair<Integer,String>> typesOfId;
    ArrayList<Pair<Integer,String>> nationalities;
    ArrayList<Integer> personNationalities;
    private Controller controller;
    private javax.swing.DefaultListModel modelListNationalities;
    /**
     * Creates new form RegisterWindow
     */
    public RegisterWindow() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        modelListNationalities = new javax.swing.DefaultListModel();
        listNationalities.setModel(modelListNationalities);
        personNationalities = new ArrayList<>();
        controller = Controller.getInstance();
        typeUser = "User";
        KeyListener listener = new KeyListener() {
            @Override
            
            public void keyTyped(KeyEvent e) {
                if (jTextField1.getText().length()>20) {
                    limitString(jTextField1);
                }
                if (jTextField2.getText().length()>10) {
                    limitString(jTextField2);
                }
                if (jTextField4.getText().length()>20) {
                    limitString(jTextField4);
                }
                if (jTextField5.getText().length()>15) {
                    limitString(jTextField5);
                }
                if (jTextField6.getText().length()>20) {
                    limitString(jTextField6);
                }
                if (jTextField7.getText().length()>20) {
                    limitString(jTextField7);
                }
                if (jTextField8.getText().length()>20) {
                    limitString(jTextField8);
                }
                if (jTextField9.getText().length()>20) {
                    limitString(jTextField9);
                }
                if (jTextField10.getText().length()>20) {
                    limitString(jTextField10);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                char character = e.getKeyChar();
                if ((character>='0' && character<='9')|| character==8) {
                    jTextField5.setEditable(true);
                    jTextField2.setEditable(true);
                } else {
                    jTextField5.setEditable(false);
                    jTextField2.setEditable(false);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
              
            }
        };
        jTextField1.addKeyListener(listener);
        jTextField2.addKeyListener(listener);
        jTextField4.addKeyListener(listener);
        jTextField5.addKeyListener(listener);
        jTextField6.addKeyListener(listener);
        jTextField7.addKeyListener(listener);
        jTextField8.addKeyListener(listener);
        jTextField9.addKeyListener(listener);
        jTextField10.addKeyListener(listener);
        
        ArrayList<ArrayList<Pair<Integer,String>>> information = new ArrayList<>();
        
        try {
            information = controller.getInfoRegister();
        } catch (SQLException ex) {
            Logger.getLogger(RegisterWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (!information.isEmpty()) {
            sexes = information.get(0);
            typesOfId = information.get(1);
            nationalities = information.get(2);
            if (sexes!= null && !sexes.isEmpty()) {
                for (Pair<Integer,String> sex:sexes) {
                    jComboBox2.addItem(sex.getSecond());
                }
            }
            if (typesOfId!= null && !typesOfId.isEmpty()) {
                for (Pair<Integer,String> typeOfId:typesOfId) {
                    jComboBox3.addItem(typeOfId.getSecond());
                }
            }
             if (nationalities!= null && !nationalities.isEmpty()) {
                for (Pair<Integer,String> nationality:nationalities) {
                    jComboBox1.addItem(nationality.getSecond());
                }
            }
        }
        
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jComboBox3 = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        labelNoNationality = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listNationalities = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Primer Nombre");

        jLabel2.setText("Fecha de nacimiento");

        jLabel3.setText("Foto");

        jLabel4.setText("Nombre de usuario");

        jLabel5.setText("Número de teléfono");

        jLabel6.setText("Correo");

        jLabel7.setText("Contraseña");

        jButton1.setText("Registrarse");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar");

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jLabel8.setText("Segundo Nombre");

        jLabel9.setText("Segundo Apellido");

        jLabel10.setText("Primer Apellido");

        jLabel11.setText("Sexo");

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton3.setText("Seleccionar archivo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setText("Crea tu cuenta");

        jLabel13.setText("No hay imagen");

        jDateChooser1.setDateFormatString("dd/mm/yyyy");

        jLabel14.setText("Nacionalidad");

        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel15.setText("Identificación");

        jButton4.setText("+");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        labelNoNationality.setForeground(new java.awt.Color(255, 0, 0));

        jScrollPane1.setViewportView(listNationalities);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(312, 312, 312)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel11)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)))
                    .addComponent(jLabel12)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jButton1)
                        .addGap(26, 26, 26)
                        .addComponent(jButton2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel8)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel10)))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jTextField9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(288, 288, 288)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel14)
                            .addComponent(labelNoNationality)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3)
                            .addComponent(jLabel13)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(34, 34, 34))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(26, 26, 26)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel12)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(40, 40, 40)
                            .addComponent(jLabel8)
                            .addGap(30, 30, 30)
                            .addComponent(jLabel10)
                            .addGap(32, 32, 32)
                            .addComponent(jLabel9))
                        .addComponent(jLabel1)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(42, 42, 42)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(24, 24, 24)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7)
                                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel5)
                                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(23, 23, 23)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel11)
                                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jButton3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelNoNationality))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(53, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 23, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    public void setTypeUser(String type) {
        typeUser = type;
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileFilter filter1 = new FileNameExtensionFilter(".png","png");
        FileFilter filter2 = new FileNameExtensionFilter(".jpeg","jpeg");
        FileFilter filter3 = new FileNameExtensionFilter(".jpg","jpg");
        fc.setFileFilter(filter1);
        fc.setFileFilter(filter2);
        fc.setFileFilter(filter3);
        int selection = fc.showOpenDialog(this);
        if (selection == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            photoDirectory = file.getPath();
            photoName = file.getName();
        }
        if (photoDirectory != null) {
            jLabel13.setText(photoName);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        labelNoNationality.setText("");
        allowRegister = true;
        date = null;
        ////////////////////Validation of required fields///////////////////////
        String firstName = jTextField1.getText();
        String firstSurname = jTextField9.getText();
        
        String idString = jTextField2.getText();
        Long id;
        if (!idString.isBlank()) {
            id = Long .valueOf(idString);
        } else {id = null;}
        if (firstName.isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío");
            allowRegister = false;
        }
        if (firstSurname.isBlank()) {
            JOptionPane.showMessageDialog(this, "El apellido no puede estar vacío");
            allowRegister = false;
        }
        if (idString.isBlank()) {
            JOptionPane.showMessageDialog(this, "La identificación no puede estar vacía");
            allowRegister = false;
        }
        
        
        ////Validate if the username and the email are not taken or are null////
        String username = jTextField4.getText();
        String email = jTextField6.getText();
        
        String phoneString = jTextField5.getText();
        Long phone;
        if (!phoneString.isBlank()) {
            phone = Long.valueOf(phoneString);
        } else {phone = null;}
        String password = jTextField7.getText();
        
        if (username.isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario no puede estar vacío");
            allowRegister = false;
        } 
        if (email.isBlank()) {
            JOptionPane.showMessageDialog(this, "El correo no puede estar vacío");
            allowRegister = false;
        }
        if (phoneString.isBlank()) {
            JOptionPane.showMessageDialog(this, "El número de teléfono no puede estar vacío");
            allowRegister = false;
        }
        if (password.isBlank()) {
            JOptionPane.showMessageDialog(this, "La contraseña no puede estar vacía");
            allowRegister = false;
        }
        try {
            //Response[0] saves the amount of usernames with input string
            //Response[1] saves the amount of emails with the input string
            //Response[2] saves the amount of phones with the input string
            boolean response;
            response = controller.checkRegister(username, email, phone);
            if (!response){
                JOptionPane.showMessageDialog(this, "El usuario/correo está ocupado");
                allowRegister = false;
            }
        } catch (Exception ex) {
            allowRegister = false;
            //Logger.getLogger(RegisterWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////////////End of username and email validation///////////////////
        
        //////////////////////////Date Validation///////////////////////////////
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        if (jDateChooser1.getDate()!=null) {
            date = dateFormat.format(jDateChooser1.getDate());
        }
        if (date == null || date.isBlank()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar una fecha");
            allowRegister = false;
        }
        
        
        byte[] image;
        if (photoDirectory != null && !photoDirectory.isBlank()) {
            try {
                hasImage = true;
                FileInputStream fis = new FileInputStream(photoDirectory);
                image = new byte[fis.available()];
                fis.read(image);
                fis.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Imagen inválida");
                allowRegister = false;
                image = new byte[1];
            }
        } else { 
            hasImage = false; 
            image = new byte[1];
        }
        
        Integer indice = jComboBox2.getSelectedIndex();
        if (sexes!=null && !sexes.isEmpty()) {
            Pair<Integer, String> pair = sexes.get(indice);
            idSex = pair.getFirst();
        }
        indice = jComboBox3.getSelectedIndex();
        if (typesOfId!=null && !typesOfId.isEmpty()) {
            Pair<Integer, String> pair = typesOfId.get(indice);
            idTypeOfId = pair.getFirst();
        }
        if (personNationalities.isEmpty()){
            allowRegister = false;
            labelNoNationality.setText("Debe seleccionar al menos una nacionalidad");
        }
        
        if (allowRegister) {
            Controller con = Controller.getInstance();
            String secondName = jTextField8.getText();
            String secondSurname = jTextField10.getText();
            if (typeUser.equals("User")) {
                try {
                    int idUser;
                    idUser = con.insertUser(idSex,firstName,secondName,firstSurname,secondSurname,
                            date,image,username,id,phone,email,password,idTypeOfId,hasImage);
                    for (int idNationality : personNationalities){
                        controller.addNationalityToPerson(idUser, idNationality);
                        
                    }
                    personNationalities.clear();
                    modelListNationalities.clear();
                    JOptionPane.showMessageDialog(this, "Creación de usuario exitosa");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "No se pudo registrar");
                    Logger.getLogger(RegisterWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                int idAdmin;
                try{
                    idAdmin = con.insertAdmin(idSex,firstName,secondName,firstSurname,secondSurname,
                            date,image,username,id,phone,email,password,idTypeOfId,hasImage);
                    for (int idNationality : personNationalities){
                        controller.addNationalityToPerson(idAdmin, idNationality);
                        
                    }
                    personNationalities.clear();
                    modelListNationalities.clear();
                    JOptionPane.showMessageDialog(this, "Se ha registrado al Administrador con éxito.");
                } catch (Exception ex) {}
            }
            dispose();
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int idComboBox = jComboBox1.getSelectedIndex();
        Pair<Integer,String> nationality = nationalities.get(idComboBox);
        int idNationality = nationality.getFirst();
        if (!personNationalities.contains(idNationality))  {
            modelListNationalities.addElement(nationality.getSecond());
            personNationalities.add(idNationality);
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void limitString(JTextField textfield) {
        String oldText = textfield.getText();
        int oldTextLength = oldText.length();
        String newText = oldText.substring(0,oldTextLength-1);
        textfield.setText(newText); 
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel labelNoNationality;
    private javax.swing.JList<String> listNationalities;
    // End of variables declaration//GEN-END:variables
}
