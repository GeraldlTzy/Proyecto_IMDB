package Interface;

import LogicClasses.Controller;
import LogicClasses.FullReview;
import LogicClasses.Product;
import LogicClasses.RenderCell;
import LogicClasses.User;
import java.awt.Component;
import java.awt.Image;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ReviewWindow extends javax.swing.JFrame {

    private javax.swing.DefaultListModel modelListComments;
    private Controller controller = Controller.getInstance();
    private User user = User.getInstance();
    private Product product;
    
    private ImageIcon imgNoFillStar;
    private ImageIcon imgFillStar;
    private int userStars;
    private boolean savedReview;
    
    
    public ReviewWindow() {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        modelListComments = new javax.swing.DefaultListModel();
        listComments.setModel(modelListComments);
        userStars = 0;
        savedReview = false;
        imgNoFillStar = new ImageIcon("Stars/no-fill-star.png");
        Image noFillStar = imgNoFillStar.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        imgNoFillStar = new ImageIcon(noFillStar);
        
        imgFillStar = new ImageIcon("Stars/fill-star.png");
        Image fillStar = imgFillStar.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        imgFillStar = new ImageIcon(fillStar);
        
        Component[] components = panelStars.getComponents();
        for (Component com : components){
            if (com instanceof JButton btn){
                btn.setBorderPainted(false);
                btn.setIcon(imgNoFillStar);
                btn.setText(null);
                btn.setContentAreaFilled(false);
            }
        }
        
        
        
    }
    
    public void setProduct(Product product){
        modelListComments.removeAllElements();
        txtCommentary.setText("");
        this.product = product;
        ArrayList<String[]> reviews;
        try {
            reviews = controller.getFullReview(product.getIdProduct());
            for (String[] review : reviews){
                if (Integer.parseInt(review[0]) == user.getId()){
                    txtCommentary.setText(review[2]);
                    userStars = Integer.parseInt(review[4]);
                    savedReview = true;
                    updateStars(userStars);
                }
                String text = "<html><b>" + review[1] + "</b><br>" + "Fecha de Publicación: " + 
                        review[3] + "<br>" + "Review: " + review[4] +
                        "<br>" + review[2] +  "</html>";
                modelListComments.addElement(text);
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ReviewWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listComments = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtCommentary = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        panelStars = new javax.swing.JPanel();
        btnStar1 = new javax.swing.JButton();
        btnStar2 = new javax.swing.JButton();
        btnStar3 = new javax.swing.JButton();
        btnStar4 = new javax.swing.JButton();
        btnStar5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        listComments.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listComments);

        jButton1.setText("Añadir reseña");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        txtCommentary.setColumns(20);
        txtCommentary.setRows(5);
        jScrollPane4.setViewportView(txtCommentary);

        jButton2.setText("Cerrar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnStar1.setText("jButton3");
        btnStar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                StarPressed(evt);
            }
        });
        btnStar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStar1ActionPerformed(evt);
            }
        });

        btnStar2.setText("jButton3");
        btnStar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                StarPressed(evt);
            }
        });
        btnStar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStar2ActionPerformed(evt);
            }
        });

        btnStar3.setText("jButton3");
        btnStar3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                StarPressed(evt);
            }
        });
        btnStar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStar3ActionPerformed(evt);
            }
        });

        btnStar4.setText("jButton3");
        btnStar4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                StarPressed(evt);
            }
        });
        btnStar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStar4ActionPerformed(evt);
            }
        });

        btnStar5.setText("jButton3");
        btnStar5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                StarPressed(evt);
            }
        });
        btnStar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStar5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelStarsLayout = new javax.swing.GroupLayout(panelStars);
        panelStars.setLayout(panelStarsLayout);
        panelStarsLayout.setHorizontalGroup(
            panelStarsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelStarsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnStar1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStar2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStar3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStar4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStar5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        panelStarsLayout.setVerticalGroup(
            panelStarsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelStarsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelStarsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStar1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStar2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStar3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStar4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStar5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addComponent(panelStars, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2)))
                .addGap(22, 22, 22))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(panelStars, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 74, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if (savedReview){
                controller.updateCommentary(user.getId(), product.getIdProduct(), txtCommentary.getText());
                controller.updateReview(user.getId(), product.getIdProduct(), userStars);
            }else{
                controller.addCommentary(user.getId(), product.getIdProduct(), txtCommentary.getText());
                controller.addReview(user.getId(), product.getIdProduct(), userStars);
            }
        } catch (SQLException ex) {
            //Logger.getLogger(ProductUser.class.getName()).log(Level.SEVERE, null, ex);
        }
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnStar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStar1ActionPerformed
        //JButton btn = (JButton) evt.getSource();
    }//GEN-LAST:event_btnStar1ActionPerformed
    private void updateStars(int stars){
        Component[] components = panelStars.getComponents();
        for (int i = 0; i < 5; i++){
            Component com = components[i];
            if (com instanceof JButton btn && i == stars-1){
                for (int j = 0; j <= i; j++){
                    JButton button = (JButton) components[j];
                    button.setIcon(imgFillStar);
                }
                for (int j = i+1; j < 5; j++){
                    JButton button = (JButton) components[j];
                    button.setIcon(imgNoFillStar);
                }
                break;
            }
        }
    }
    private void StarPressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StarPressed
        JButton btnPressed = (JButton) evt.getSource();
        
        Component[] components = panelStars.getComponents();
        for (int i = 0; i < 5; i++){
            Component com = components[i];
            if (com instanceof JButton btn && btn == btnPressed){
                for (int j = 0; j <= i; j++){
                    JButton button = (JButton) components[j];
                    button.setIcon(imgFillStar);
                }
                for (int j = i+1; j < 5; j++){
                    JButton button = (JButton) components[j];
                    button.setIcon(imgNoFillStar);
                }
                userStars = i+1;
                break;
            }
        }
    }//GEN-LAST:event_StarPressed

    private void btnStar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStar2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStar2ActionPerformed

    private void btnStar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStar3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStar3ActionPerformed

    private void btnStar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStar4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStar4ActionPerformed

    private void btnStar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStar5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStar5ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnStar1;
    private javax.swing.JButton btnStar2;
    private javax.swing.JButton btnStar3;
    private javax.swing.JButton btnStar4;
    private javax.swing.JButton btnStar5;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JList<String> listComments;
    private javax.swing.JPanel panelStars;
    private javax.swing.JTextArea txtCommentary;
    // End of variables declaration//GEN-END:variables
}
