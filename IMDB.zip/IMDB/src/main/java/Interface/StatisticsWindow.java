package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import LogicClasses.Product;
import LogicClasses.Stats;
import LogicClasses.User;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class StatisticsWindow extends javax.swing.JFrame {

    private Controller controller;
    private Stats stats;
    private javax.swing.DefaultListModel modelProducts;
    private javax.swing.DefaultListModel modelUsers;
    private boolean error;
    private DefaultTableModel modelTableProducts;
    private DefaultTableModel modelTableUsers;
    
    public StatisticsWindow() {
        initComponents();
        modelProducts = new javax.swing.DefaultListModel();
        modelUsers = new javax.swing.DefaultListModel();
        listProducts.setModel(modelProducts);
        listUsers.setModel(modelUsers);
        error = false;
        modelTableProducts = new DefaultTableModel();
        modelTableUsers = new DefaultTableModel();
    }

    public void LoadData() {
        //PRODUCTS
        controller = Controller.getInstance();
        try {
            error = false;
            stats = controller.getStatistics();
            comboBoxGenre.addItem("Total");
            comboBoxUsers.addItem("Género");
            comboBoxUsers.addItem("Edad: 0-12");
            comboBoxUsers.addItem("Edad: 13-20");
            comboBoxUsers.addItem("Edad: 21-40");
            comboBoxUsers.addItem("Edad: 40+");
            DefaultPieDataset data = new DefaultPieDataset();
            HashMap<String,Float[]> productStats = (HashMap)stats.getProductsStats();
            int iterator = 1;
            int size = productStats.size();
            float totalProducts = 0;
            String key;
            Float percentage;
            Float quantity;
            modelTableProducts.setColumnIdentifiers(new String[]{"Género","Porcentaje","Cantidad"});
            tableProducts.setModel(modelTableProducts);
            for (Map.Entry<String,Float[]> entry : productStats.entrySet()) {
                iterator++;
                if (entry.getKey().equals("Total")) {
                    totalProducts = entry.getValue()[0];

                } else {
                    key = entry.getKey();
                    percentage = entry.getValue()[0];
                    quantity = entry.getValue()[1];
                    comboBoxGenre.addItem(key);
                    modelTableProducts.addRow(new Object[]{key,String.valueOf(percentage),String.valueOf(quantity)});
                    data.setValue(key,percentage);
                }
            }
            labelProducts.setText("Total de productos: "+Float.toString(totalProducts));
            labelUsers.setText("Total de usuarios: "+String.valueOf(stats.getTotalUsers()));
            JFreeChart productsGraph = ChartFactory.createPieChart(
                    "Productos por género",
                    data,
                    true,
                    true,
                    false
            );
            ChartPanel panel = new ChartPanel(productsGraph);
            panel.setMouseWheelEnabled(true);
            panel.setPreferredSize(new Dimension(250,250));

            productsPanel.setLayout(new BorderLayout());
            productsPanel.add(panel,BorderLayout.NORTH);

            fillListProducts();

            //USERS


            fillListUsers();

            pack();
            repaint();
        } catch (SQLException ex) {
            error = true;
            JOptionPane.showMessageDialog(this, "No se pudieron cargar los datos");
            Logger.getLogger(RegisterWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void fillListUsers() {
        modelUsers.removeAllElements();
        modelTableUsers = new DefaultTableModel();
        modelTableUsers.setColumnIdentifiers(new String[]{"Nombre usuario","Sexo","Edad"});
        tableUsers.setModel(modelTableUsers);
        List<User> users = stats.getUsers();
            if (users != null) {
                String userText;
                for (User user : users) {
                    if (user.getSexId()==1) {
                        userText = user.getUsername() + " - Masculino";
                        modelTableUsers.addRow(new String[]{user.getUsername(),"Masculino",String.valueOf(user.getAge())});
                    } else {
                        userText = user.getUsername() + " - Femenino";
                        modelTableUsers.addRow(new String[]{user.getUsername(),"Femenino",String.valueOf(user.getAge())});
                    }
                    modelUsers.addElement(userText);
                }
            }
            
        //Actualizacion de grafico
        usersPanel.removeAll();
        DefaultCategoryDataset dataUser = new DefaultCategoryDataset();
        Map<String,Integer> usersBySex = stats.getUsersBySex();
        if (usersBySex != null) {
            for (Map.Entry<String,Integer> entry : usersBySex.entrySet()) {
                String sex = entry.getKey();
                Integer persons = entry.getValue();
                dataUser.setValue(persons, sex ,sex);
            }

            JFreeChart graphUser = ChartFactory.createBarChart3D(
                    "Usuarios por género",
                    "Género",
                    "Cantidad de usuarios",
                    dataUser,
                    PlotOrientation.VERTICAL,
                    true,
                    true,
                    false
            );
            ChartPanel panel = new ChartPanel(graphUser);
            panel = new ChartPanel(graphUser);
            panel.setMouseWheelEnabled(true);
            panel.setPreferredSize(new Dimension(250,250));

            usersPanel.setLayout(new BorderLayout());
            usersPanel.add(panel,BorderLayout.NORTH);
        }
    }
    
    public void fillListUsersConditional(int lowerLimit, int upperLimit) {
        modelUsers.removeAllElements();
        List<User> users = stats.getUsers();
            if (users != null) {
                String userText;
                int age;
                for (User user : users) {
                    age = user.getAge();
                    if (lowerLimit <= age && age <= upperLimit) {
                        userText = user.getUsername() + " - " +age +"años";
                        modelUsers.addElement(userText);
                    }
                    
                }
            }
    }
    
    public void graphUsersByAge() {
        usersPanel.removeAll();
        DefaultCategoryDataset dataUser = new DefaultCategoryDataset();
        int ageUsersChild = 0;
        int ageUsersTeen = 0;
        int ageUsersYoungAdult = 0;
        int ageUsersAdult = 0;
        int age;
        ArrayList<User> users = (ArrayList)stats.getUsers();
        if (users != null) {
            for (User user : users) {
                age = user.getAge();
                if (age <= 12) {
                    ageUsersChild++;
                } else 
                if (age<=20) {
                    ageUsersTeen++;
                } else 
                if (age<=40) {
                    ageUsersYoungAdult++;
                } else {
                    ageUsersAdult++;
                }
            }
        }
        dataUser.setValue(ageUsersChild,"0-12","0-12");
        dataUser.setValue(ageUsersTeen,"13-20","13-20");
        dataUser.setValue(ageUsersYoungAdult,"21-40","21-40");
        dataUser.setValue(ageUsersAdult,"40+","40+");
        JFreeChart graphUser = ChartFactory.createBarChart3D(
                "Usuarios por edad",
                "Edad",
                "Cantidad de usuarios",
                dataUser,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );
        ChartPanel panel = new ChartPanel(graphUser);
        panel = new ChartPanel(graphUser);
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new Dimension(250,250));
        usersPanel.setLayout(new BorderLayout());
        usersPanel.add(panel,BorderLayout.NORTH);
        pack();
        repaint();
    }
    
    public void fillListProducts() {
        Product product;
        String textGenres;
        String textProduct;
        ArrayList<String> genres;
        ArrayList<Pair<Integer,Product>> products = (ArrayList)stats.getProducts();
        for (Pair<Integer,Product> par : products) {
            textGenres = "";
            product = par.getSecond();
            genres = product.getStatsGenres();
            for (String genre : genres) {
                textGenres = textGenres + genre + ", ";
            }
            textProduct = product.getTitle() + " " + "- " + textGenres;
            modelProducts.addElement(textProduct);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        productsPanel = new javax.swing.JPanel();
        usersPanel = new javax.swing.JPanel();
        labelProducts = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listProducts = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        listUsers = new javax.swing.JList<>();
        comboBoxGenre = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        labelUsers = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        comboBoxUsers = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableUsers = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableProducts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout productsPanelLayout = new javax.swing.GroupLayout(productsPanel);
        productsPanel.setLayout(productsPanelLayout);
        productsPanelLayout.setHorizontalGroup(
            productsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 234, Short.MAX_VALUE)
        );
        productsPanelLayout.setVerticalGroup(
            productsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 211, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout usersPanelLayout = new javax.swing.GroupLayout(usersPanel);
        usersPanel.setLayout(usersPanelLayout);
        usersPanelLayout.setHorizontalGroup(
            usersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 216, Short.MAX_VALUE)
        );
        usersPanelLayout.setVerticalGroup(
            usersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        labelProducts.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        labelProducts.setText("Total de Productos: ");

        listProducts.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listProducts);

        jScrollPane2.setViewportView(listUsers);

        comboBoxGenre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxGenreActionPerformed(evt);
            }
        });

        jLabel1.setText("Ordenar por");

        labelUsers.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labelUsers.setText("Total de Usuarios");

        jLabel3.setText("Ordenar por");

        comboBoxUsers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxUsersActionPerformed(evt);
            }
        });

        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        tableUsers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tableUsers);

        tableProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Género", "Porcentaje", "Cantidad"
            }
        ));
        jScrollPane4.setViewportView(tableProducts);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(labelProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(productsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboBoxGenre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1)))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(usersPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(comboBoxUsers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(labelUsers))
                        .addGap(136, 136, 136)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelUsers))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(productsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(comboBoxGenre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(70, 70, 70)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18)
                                        .addComponent(comboBoxUsers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(14, 14, 14)
                                .addComponent(usersPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(4, 4, 4)))
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboBoxGenreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxGenreActionPerformed
        if (!error ){
            modelProducts.clear();
            String selectedGenre = (String)comboBoxGenre.getSelectedItem();
            if (selectedGenre.equals("Total")) {
                fillListProducts();
            } else {
                Product product;
                String textGenres;
                String textProduct;
                ArrayList<String> genres;
                ArrayList<Pair<Integer,Product>> products = (ArrayList)stats.getProducts();
                for (Pair<Integer,Product> par : products) {
                    textGenres = "";
                    product = par.getSecond();
                    genres = product.getStatsGenres();
                    if (genres.contains(selectedGenre)) {
                        textProduct = product.getTitle();
                        modelProducts.addElement(textProduct);
                    }
                }
            }
            pack();
            repaint();
        }
    }//GEN-LAST:event_comboBoxGenreActionPerformed

    private void comboBoxUsersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxUsersActionPerformed
        if (!error) {
            String selection = (String)comboBoxUsers.getSelectedItem();
            if (selection.equals("Género")) {
                fillListUsers();
            } else {
                graphUsersByAge();
                if (selection.equals("Edad: 0-12")) {
                    fillListUsersConditional(0,12);
                }
                if (selection.equals("Edad: 13-20")) {
                    fillListUsersConditional(13,20);
                }
                if (selection.equals("Edad: 21-40")) {
                    fillListUsersConditional(21,40);
                }
                if (selection.equals("Edad: 40+")) {
                    fillListUsersConditional(40,200);
                }
            }
            pack();
            repaint();
        }
    }//GEN-LAST:event_comboBoxUsersActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StatisticsWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StatisticsWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StatisticsWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StatisticsWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StatisticsWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboBoxGenre;
    private javax.swing.JComboBox<String> comboBoxUsers;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel labelProducts;
    private javax.swing.JLabel labelUsers;
    private javax.swing.JList<String> listProducts;
    private javax.swing.JList<String> listUsers;
    private javax.swing.JPanel productsPanel;
    private javax.swing.JTable tableProducts;
    private javax.swing.JTable tableUsers;
    private javax.swing.JPanel usersPanel;
    // End of variables declaration//GEN-END:variables
}
