package Interface;

import LogicClasses.Controller;
import LogicClasses.Pair;
import LogicClasses.User;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class UpdateUserWindow extends javax.swing.JFrame {
    User user = User.getInstance();
    String typeUser;
    String photoDirectory;
    String photoName;
    String date;
    Integer idSex;
    Integer idTypeOfId;
    boolean hasImage;
    boolean allowRegister;
    ArrayList<Pair<Integer,String>> sexes;
    ArrayList<Pair<Integer,String>> typesOfId;
    ArrayList<Pair<Integer,String>> nationalities;
    ArrayList<Integer> personNationalities;
    private Controller controller;
    private javax.swing.DefaultListModel modelListNationalities;
    byte[] image;
    /**
     * Creates new form RegisterWindow
     */
    public UpdateUserWindow() {
        initComponents();
        setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        modelListNationalities = new javax.swing.DefaultListModel();
        listNationalities.setModel(modelListNationalities);
        personNationalities = new ArrayList<>();
        controller = Controller.getInstance();
        typeUser = "User";
        KeyListener listener = new KeyListener() {
            @Override
            
            public void keyTyped(KeyEvent e) {
                if (txtFirstName.getText().length()>20) {
                    limitString(txtFirstName);
                }
                /*if (txtIdent.getText().length()>10) {
                    limitString(txtIdent);
                }*/
                if (txtUsername.getText().length()>20) {
                    limitString(txtUsername);
                }
                if (txtPhone.getText().length()>15) {
                    limitString(txtPhone);
                }
                if (txtMail.getText().length()>20) {
                    limitString(txtMail);
                }
                if (txtPswd.getText().length()>20) {
                    limitString(txtPswd);
                }
                if (txtSecondName.getText().length()>20) {
                    limitString(txtSecondName);
                }
                if (txtFirstSurname.getText().length()>20) {
                    limitString(txtFirstSurname);
                }
                if (txtSecondSurname.getText().length()>20) {
                    limitString(txtSecondSurname);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                char character = e.getKeyChar();
                if ((character>='0' && character<='9')|| character==8) {
                    txtPhone.setEditable(true);
                    //txtIdent.setEditable(true);
                } else {
                    txtPhone.setEditable(false);
                    //txtIdent.setEditable(false);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
              
            }
        };
        txtFirstName.addKeyListener(listener);
        //txtIdent.addKeyListener(listener);
        txtUsername.addKeyListener(listener);
        txtPhone.addKeyListener(listener);
        txtMail.addKeyListener(listener);
        txtPswd.addKeyListener(listener);
        txtSecondName.addKeyListener(listener);
        txtFirstSurname.addKeyListener(listener);
        txtSecondSurname.addKeyListener(listener);
        
        ArrayList<ArrayList<Pair<Integer,String>>> information = new ArrayList<>();
        
        try {
            information = controller.getInfoRegister();
        } catch (SQLException ex) {
            Logger.getLogger(UpdateUserWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (!information.isEmpty()) {
            sexes = information.get(0);
            typesOfId = information.get(1);
            nationalities = information.get(2);
            if (sexes!= null && !sexes.isEmpty()) {
                for (Pair<Integer,String> sex:sexes) {
                    jComboBox2.addItem(sex.getSecond());
                }
            }
            /*if (typesOfId!= null && !typesOfId.isEmpty()) {
                for (Pair<Integer,String> typeOfId:typesOfId) {
                    jComboBox3.addItem(typeOfId.getSecond());
                }
            }*/
             if (nationalities!= null && !nationalities.isEmpty()) {
                for (Pair<Integer,String> nationality:nationalities) {
                    jComboBox1.addItem(nationality.getSecond());
                }
            }
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        txtFirstName = new javax.swing.JTextField();
        txtUsername = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        txtMail = new javax.swing.JTextField();
        txtPswd = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtSecondName = new javax.swing.JTextField();
        txtFirstSurname = new javax.swing.JTextField();
        txtSecondSurname = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        lblImage = new javax.swing.JLabel();
        dateChooser = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        labelNoNationality = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listNationalities = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Primer Nombre");

        jLabel2.setText("Fecha de nacimiento");

        jLabel3.setText("Foto");

        jLabel4.setText("Nombre de usuario");

        jLabel5.setText("Número de teléfono");

        jLabel6.setText("Correo");

        jLabel7.setText("Contraseña");

        jButton1.setText("Aceptar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txtUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsernameActionPerformed(evt);
            }
        });

        txtPswd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPswdActionPerformed(evt);
            }
        });

        jLabel8.setText("Segundo Nombre");

        jLabel9.setText("Segundo Apellido");

        jLabel10.setText("Primer Apellido");

        jLabel11.setText("Sexo");

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton3.setText("Seleccionar archivo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setText("Crea tu cuenta");

        lblImage.setText("No hay imagen");

        dateChooser.setDateFormatString("dd/mm/yyyy");

        jLabel14.setText("Nacionalidad");

        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jButton4.setText("+");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        labelNoNationality.setForeground(new java.awt.Color(255, 0, 0));

        jScrollPane1.setViewportView(listNationalities);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel8)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel10)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel2))
                                .addGap(12, 12, 12))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtSecondName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtFirstSurname, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtSecondSurname, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton3))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(118, 118, 118)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(lblImage, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(labelNoNationality))))))
                            .addComponent(jLabel4))
                        .addGap(249, 307, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPswd, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMail, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                            .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2)))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel12)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel8)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel10)
                        .addGap(32, 32, 32)
                        .addComponent(jLabel9))
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(txtSecondName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtFirstSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(txtPswd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtMail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(txtSecondSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel11)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jButton3)
                            .addComponent(jLabel3))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(labelNoNationality))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblImage, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton4)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton1))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsernameActionPerformed

    public void setTypeUser(String type) {
        typeUser = type;
    }
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    public void setUser(){
        txtFirstName.setText(user.getFirstName());
        txtSecondName.setText(user.getSecondName());
        txtFirstSurname.setText(user.getFirstSurname());
        txtSecondSurname.setText(user.getSecondSurname());
        txtPhone.setText(user.getPhoneNumber());
        txtMail.setText(user.getEmail());
        txtUsername.setText(user.getUsername());
        //txtIdent.setText(""+user.getIdentification());
        image = user.getPhoto();
        dateChooser.setDateFormatString("yyyy-MM-dd");
        UpdateImage();
        Date date;
        try {
            date = dateFormat.parse(user.getBirthdate());
            dateChooser.setDate(date);
        } catch (ParseException ex) {}
        try {
            user.setNationalities(controller.getPersonNationalities(user.getId()));
        } catch (Exception ex) {}
        
        user.getNationalities().forEach((key, value) -> { 
            modelListNationalities.addElement(value);
            personNationalities.add(key);
        });
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        FileFilter filter1 = new FileNameExtensionFilter(".png","png");
        FileFilter filter2 = new FileNameExtensionFilter(".jpeg","jpeg");
        FileFilter filter3 = new FileNameExtensionFilter(".jpg","jpg");
        fc.setFileFilter(filter1);
        fc.setFileFilter(filter2);
        fc.setFileFilter(filter3);
        int selection = fc.showOpenDialog(this);
        if (selection == JFileChooser.APPROVE_OPTION) {
            //File file = fc.getSelectedFile();
            File file = new File(fc.getSelectedFile().getAbsolutePath());
            String imagePath = file.toString();
            FileInputStream fis;
            try {
                fis = new FileInputStream(imagePath);
                image = new byte[fis.available()];
                fis.read(image);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(UpdateUserWindow.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(UpdateUserWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        UpdateImage();
    }//GEN-LAST:event_jButton3ActionPerformed
    public void UpdateImage(){
        try{
            lblImage.setText("");
            ImageIcon imageIcon = new ImageIcon(image); // load the image to a imageIcon
            Image imageTemp = imageIcon.getImage(); // transform it 
            imageTemp = imageTemp.getScaledInstance(lblImage.getWidth(), lblImage.getHeight(),  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
            imageIcon = new ImageIcon(imageTemp);
            lblImage.setIcon(imageIcon);
        } catch (Exception e){
            lblImage.setIcon(null);
            lblImage.setText("No se encontró imagen");
        }
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        labelNoNationality.setText("");
        allowRegister = true;
        date = null;
        ////////////////////Validation of required fields///////////////////////
        String firstName = txtFirstName.getText();
        String firstSurname = txtFirstSurname.getText();
        
        /*String idString = txtIdent.getText();
        Long id;
        if (!idString.isBlank()) {
            id = Long .valueOf(idString);
        } else {id = null;}*/
        if (firstName.isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío");
            allowRegister = false;
        }
        if (firstSurname.isBlank()) {
            JOptionPane.showMessageDialog(this, "El apellido no puede estar vacío");
            allowRegister = false;
        }
        /*if (idString.isBlank()) {
            JOptionPane.showMessageDialog(this, "La identificación no puede estar vacía");
            allowRegister = false;
        }*/
        
        ////Validate if the username and the email are not taken or are null////
        String username = txtUsername.getText();
        String email = txtMail.getText();
        String phoneString = txtPhone.getText();
        Long phone;
        
        if (!phoneString.isBlank()) {
            phone = Long.valueOf(phoneString);
        } else {phone = null;}
        String password = txtPswd.getText();
        
        if (username.isBlank()) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario no puede estar vacío");
            allowRegister = false;
        } 
        if (email.isBlank()) {
            JOptionPane.showMessageDialog(this, "El correo no puede estar vacío");
            allowRegister = false;
        }
        if (phoneString.isBlank()) {
            JOptionPane.showMessageDialog(this, "El número de teléfono no puede estar vacío");
            allowRegister = false;
        }
        if (password.isBlank()) {
            JOptionPane.showMessageDialog(this, "La contraseña no puede estar vacía");
            allowRegister = false;
        }
        try {
            boolean response;
            if (!username.equals(user.getUsername())){
                response = controller.checkRegister(username, email, phone);
            } else{
                response = true;
            }
            if (!response){
                JOptionPane.showMessageDialog(this, "El usuario/correo está ocupado");
                allowRegister = false;
            }
        } catch (Exception ex) {
            allowRegister = false;
            //Logger.getLogger(RegisterWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////////////End of username and email validation///////////////////
        
        //////////////////////////Date Validation///////////////////////////////
        if (dateChooser.getDate()!=null) {
            date = dateFormat.format(dateChooser.getDate());
        }
        if (date == null || date.isBlank()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar una fecha");
            allowRegister = false;
        }
        
        if (image != null) {
            hasImage = true;
        } else { 
            hasImage = false; 
            image = new byte[1];
        }
        Integer indice = jComboBox2.getSelectedIndex();
        if (sexes!=null && !sexes.isEmpty()) {
            Pair<Integer, String> pair = sexes.get(indice);
            idSex = pair.getFirst();
        }
        /*indice = jComboBox3.getSelectedIndex();
        if (typesOfId!=null && !typesOfId.isEmpty()) {
            Pair<Integer, String> pair = typesOfId.get(indice);
            idTypeOfId = pair.getFirst();
        }*/
        if (allowRegister) {
            String secondName = txtSecondName.getText();
            String secondSurname = txtSecondSurname.getText();
            
            try {
                int id = 0;
                controller.updateUser(user.getId(), idSex,firstName,secondName,firstSurname,secondSurname,
                        date,image,username,id,phone,email,password,idTypeOfId,hasImage);
                for (int idNationality : personNationalities){
                    if (!user.getNationalities().containsKey(idNationality))
                        controller.addNationalityToPerson(user.getId(), idNationality);
                }
                personNationalities.clear();
                modelListNationalities.clear();
                JOptionPane.showMessageDialog(this, "Actualización de usuario exitosa");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar");
               Logger.getLogger(UpdateUserWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
            updateUser();
            dispose();
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    private void updateUser(){
        Pair<ArrayList<String>,byte[]> userInfo;
        
        userInfo = controller.validUser(txtUsername.getText(), txtPswd.getText());
        if (userInfo != null) {
            ArrayList<String> listInfo = userInfo.getFirst();
            
            String userType = listInfo.get(0);
            int id = Integer.parseInt(listInfo.get(1));
            String firstName = listInfo.get(2);
            String firstSurname = listInfo.get(3);
            String birthdate = listInfo.get(4);
            String username = listInfo.get(5);
            String phoneNumber = listInfo.get(6);
            String email = listInfo.get(7);
            byte[] image = userInfo.getSecond();
            String sex = listInfo.get(9);
            String secondName = listInfo.get(10);
            String secondSurname = listInfo.get(11);
            int identification = Integer.parseInt(listInfo.get(12));
            user.UpdateUser(userType, id, firstName, firstSurname, birthdate,
                    image, username, phoneNumber, email,sex, secondName, 
                    secondSurname, identification);
            dispose();
        }
    }
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int idComboBox = jComboBox1.getSelectedIndex();
        Pair<Integer,String> nationality = nationalities.get(idComboBox);
        int idNationality = nationality.getFirst();
        if (!personNationalities.contains(idNationality))  {
            modelListNationalities.addElement(nationality.getSecond());
            personNationalities.add(idNationality);
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void txtPswdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPswdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPswdActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void limitString(JTextField textfield) {
        String oldText = textfield.getText();
        int oldTextLength = oldText.length();
        String newText = oldText.substring(0,oldTextLength-1);
        textfield.setText(newText); 
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelNoNationality;
    private javax.swing.JLabel lblImage;
    private javax.swing.JList<String> listNationalities;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtFirstSurname;
    private javax.swing.JTextField txtMail;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtPswd;
    private javax.swing.JTextField txtSecondName;
    private javax.swing.JTextField txtSecondSurname;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
