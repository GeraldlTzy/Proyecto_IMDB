package Interface;

import LogicClasses.Controller;
import LogicClasses.ImgNText;
import LogicClasses.Product;
import LogicClasses.Render;
import LogicClasses.Triple;
import LogicClasses.User;
import java.awt.Image;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

public class ViewProductsWindow extends javax.swing.JDialog {
    private ArrayList<Triple<Integer, String, byte[]>> objects;
    private ArrayList<Product> backupObjects;
    private ArrayList<String> genres;
    private javax.swing.DefaultListModel modelListObject;
    private Controller controller;
    String typeOfUser = "Admin";
    String typeOfObject = null;
    ProductUser productUser;
    ProductWindow productWindow;
    ParticipantWindow participantWindow;
    User user;
    
    public ViewProductsWindow(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        controller = Controller.getInstance();
        user = User.getInstance();
        objects = new ArrayList<>();
        backupObjects = new ArrayList<>();
        genres = new ArrayList<>();
        modelListObject = new javax.swing.DefaultListModel();
        listObjects.setModel(modelListObject);
        productUser = new ProductUser();
        productWindow = new ProductWindow();
        participantWindow = new ParticipantWindow();
        cmbGenres.removeAllItems();
    }
  
    public void LoadData(String typeOfUser, String typeOfObject) {
        modelListObject.clear();
        this.typeOfUser = typeOfUser;
        this.typeOfObject = typeOfObject;
        if (typeOfUser.equals("User")) {
            btnDeleteProduct.setVisible(false);
            btnFill.setVisible(false);
            parameter.setVisible(false);
            btnFill.setEnabled(false);
        } else {
            btnFill.setVisible(true);
            parameter.setVisible(true);
            btnFill.setEnabled(true);
        }
        
        try {
            if (typeOfObject.equals("Product")){
                LogicClasses.Pair<ArrayList<Product>, java.util.Map<Integer, String>> data;
                data = controller.getProducts();
                backupObjects = data.getFirst();
                for (Product p : backupObjects){
                    objects.add(new Triple<>(p.getIdProduct(), p.getTitle(), 
                            p.getImages().get(0).getSecond()));
                }
                data.getSecond().forEach((key, value) -> {
                    //genres.add(value);
                    cmbGenres.addItem(value);
                });
                btnSeeProduct.setText("Ver producto");
                btnDeleteProduct.setText("Eliminar producto");
            } else{
                objects = controller.getParticipants();
                btnSeeProduct.setText("Ver participante");
                btnDeleteProduct.setText("Eliminar participante");
            }
                
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = new ImageIcon(object.getThird());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(object.getSecond(),imageIcon));
            }
            listObjects.setCellRenderer(new Render());
            listObjects.setModel(modelListObject);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void loadProduct(){
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listObjects = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        btnSeeProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        btnFill = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnPurchasesHistory = new javax.swing.JButton();
        spMonth = new javax.swing.JSpinner();
        cmbGenres = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        parameter = new javax.swing.JSpinner();
        btnRating = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        listObjects.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listObjects);

        jButton1.setText("Cerrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnSeeProduct.setText("Ver producto");
        btnSeeProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeeProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setText("Eliminar producto");

        btnFill.setText("Filtar por compras");
        btnFill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFillActionPerformed(evt);
            }
        });

        btnPurchasesHistory.setText("Historial de compras");
        btnPurchasesHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchasesHistoryActionPerformed(evt);
            }
        });

        cmbGenres.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jButton2.setText("Recientes");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnRating.setText("Rating");
        btnRating.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRatingActionPerformed(evt);
            }
        });

        jButton3.setText("Categoría");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnPurchasesHistory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnRating)
                            .addComponent(jButton3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(spMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPurchasesHistory)
                    .addComponent(spMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnRating)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(84, Short.MAX_VALUE))
        );

        jLabel2.setText("Filtrado");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSeeProduct)
                                    .addComponent(btnDeleteProduct))
                                .addComponent(btnFill))
                            .addComponent(jLabel2))
                        .addGap(196, 196, 196)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnSeeProduct)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDeleteProduct)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFill)
                .addGap(41, 41, 41)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSeeProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeeProductActionPerformed
        
        /*The arraylist products have the same order that the listProducts
         * so index 0 in products it's equals to index 0 in listProducts
         */
        if (listObjects.getSelectedIndex() >=0) { 
        int indexObject = listObjects.getSelectedIndex();
        int idObject = objects.get(indexObject).getFirst();
    
        if (typeOfObject.equals("Product")) {
            if (typeOfUser.equals("User")){
                productUser.setAtributes(idObject);
                productUser.setVisible(true);
                productUser.update();
            } else if (typeOfUser.equals("Admin")){
                productWindow = new ProductWindow();
                productWindow.setPurpose("Edit");
                productWindow.setProductInformation(idObject);
                productWindow.setVisible(true);
            }
        } else {
            participantWindow.setParticipant(idObject);
            participantWindow.setPurpose("Edit");
            participantWindow.setVisible(true);
        }
        
        dispose();
        }
    }//GEN-LAST:event_btnSeeProductActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnFillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFillActionPerformed
        try{
            int N = (Integer) parameter.getValue();
            objects = controller.getTopNPurchases(N);
            modelListObject.clear();
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = new ImageIcon(object.getThird());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(
                        "<html>" + object.getSecond() + "<br>Cantidad de compras: " + object.getId() + "</html>",imageIcon));
            }
        } catch(IOException | SQLException e){System.out.println(""+e.getMessage());}
        
    }//GEN-LAST:event_btnFillActionPerformed

    private void btnPurchasesHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchasesHistoryActionPerformed
        int month = (Integer) spMonth.getValue();
        ArrayList<Integer> pIds;
        try {
            pIds = controller.getPurchasesHistory(user.getId(), month);
        } catch (SQLException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
            pIds = new ArrayList();
        }
        objects.clear();
        modelListObject.clear();
        for (Product p : backupObjects){
                    objects.add(new Triple<>(p.getIdProduct(), p.getTitle(), 
                            p.getImages().get(0).getSecond()));
                }
        for (Product p : backupObjects){
            if (pIds.contains(p.getIdProduct())){
                objects.add(new Triple<>(p.getIdProduct(), p.getTitle(), 
                            p.getImages().get(0).getSecond()));
                ImageIcon imageIcon = new ImageIcon(p.getImages().get(0).getSecond());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(
                        "<html>" + p.getTitle() + "</html>",imageIcon));
            }
        }
    }//GEN-LAST:event_btnPurchasesHistoryActionPerformed

    private void btnRatingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRatingActionPerformed
        
        //controller.getPurchasesHistory(user.getId(), )
    }//GEN-LAST:event_btnRatingActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        objects.clear();
        modelListObject.clear();
        String selectedGenre = (String) cmbGenres.getSelectedItem();
        for (Product p : backupObjects){
            for (LogicClasses.Pair<Integer, String> genre : p.getGenres()){
                if (genre.getSecond().equals(selectedGenre)){
                    objects.add(new Triple<>(p.getIdProduct(), p.getTitle(), 
                            p.getImages().get(0).getSecond()));
                    ImageIcon imageIcon = new ImageIcon(p.getImages().get(0).getSecond());
                    Image image = imageIcon.getImage(); // transform it 
                    image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                    imageIcon = new ImageIcon(image);
                    modelListObject.addElement(new ImgNText(
                            "<html>" + p.getTitle() + "</html>",imageIcon));
                    break;
                }
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JButton btnFill;
    private javax.swing.JButton btnPurchasesHistory;
    private javax.swing.JButton btnRating;
    private javax.swing.JButton btnSeeProduct;
    private javax.swing.JComboBox<String> cmbGenres;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JList<String> listObjects;
    private javax.swing.JSpinner parameter;
    private javax.swing.JSpinner spMonth;
    // End of variables declaration//GEN-END:variables
}
