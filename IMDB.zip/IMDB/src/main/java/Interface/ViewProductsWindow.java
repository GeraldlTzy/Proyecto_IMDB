package Interface;

import LogicClasses.Controller;
import LogicClasses.ImgNText;
import LogicClasses.Product;
import LogicClasses.Render;
import LogicClasses.Triple;
import LogicClasses.User;
import java.awt.Image;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

public class ViewProductsWindow extends javax.swing.JDialog {
    private ArrayList<Triple<Integer, String, byte[]>> objects;
    private ArrayList<Product> backupObjects;
    private ArrayList<String> genres;
    private javax.swing.DefaultListModel modelListObject;
    private List<Integer> recentlyVisited;
    private Controller controller;
    String typeOfUser = "Admin";
    String typeOfObject = null;
    ProductUser productUser;
    ProductWindow productWindow;
    ParticipantWindow participantWindow;
    ShoppingCart shoppingCart;
    User user;
    
    public ViewProductsWindow(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        controller = Controller.getInstance();
        user = User.getInstance();
        objects = new ArrayList<>();
        recentlyVisited = new ArrayList<>();
        backupObjects = new ArrayList<>();
        genres = new ArrayList<>();
        modelListObject = new javax.swing.DefaultListModel();
        listObjects.setModel(modelListObject);
        productUser = new ProductUser();
        productWindow = new ProductWindow();
        shoppingCart = new ShoppingCart();
        cmbGenres.removeAllItems();
    }
    
    public void enableFills(boolean state){
        if (typeOfUser.equals("User")){
            btnFill.setVisible(false);
            btnFill.setEnabled(false);
            parameter.setVisible(false);
            btnDeleteProduct.setVisible(false);
        } else {
            btnFill.setVisible(state);
            btnFill.setEnabled(state);
            parameter.setVisible(state);
            btnDeleteProduct.setVisible(true);
        }
        
        btnGenres.setVisible(state);
        btnGenres.setEnabled(state);
        cmbGenres.setVisible(state);
        btnPurchasesHistory.setVisible(state);
        btnPurchasesHistory.setEnabled(state);
        cmbMonth.setVisible(state);
        lblFill.setVisible(state);
        btnRecently.setVisible(state);
        btnRecently.setEnabled(state);
        btnRating.setVisible(state);
        btnRating.setEnabled(state);
        spRating.setVisible(state);
    }
    
    public void LoadData(String typeOfUser, String typeOfObject) {
        modelListObject.clear();
        this.typeOfUser = typeOfUser;
        this.typeOfObject = typeOfObject;
        if (typeOfUser.equals("User")) {
            try {
                recentlyVisited = controller.getRecentlyVisited(user.getId());
            } catch (Exception ex) {
                Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        try {
            if (typeOfObject.equals("Product")){
                LogicClasses.Pair<ArrayList<Product>, java.util.Map<Integer, String>> data;
                data = controller.getProducts();
                backupObjects = data.getFirst();
                for (Product p : backupObjects){
                    objects.add(new Triple<>(p.getIdProduct(), p.getTitle(), 
                            p.getImages().get(0).getSecond()));
                }
                data.getSecond().forEach((key, value) -> {
                    cmbGenres.addItem(value);
                });
                btnSeeProduct.setText("Ver producto");
                btnDeleteProduct.setText("Eliminar producto");
                enableFills(true);
                
            } else{
                objects = controller.getParticipants();
                btnSeeProduct.setText("Ver participante");
                btnDeleteProduct.setText("Eliminar participante");
                enableFills(false);
            }
                
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = getImage(object.getThird());
                modelListObject.addElement(new ImgNText(object.getSecond(),imageIcon));
            }
            listObjects.setCellRenderer(new Render());
            listObjects.setModel(modelListObject);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void loadProduct(){
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listObjects = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        btnSeeProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        btnFill = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnPurchasesHistory = new javax.swing.JButton();
        cmbGenres = new javax.swing.JComboBox<>();
        btnRecently = new javax.swing.JButton();
        btnRating = new javax.swing.JButton();
        spRating = new javax.swing.JSpinner();
        btnGenres = new javax.swing.JButton();
        cmbMonth = new javax.swing.JComboBox<>();
        lblFill = new javax.swing.JLabel();
        btnClearFill = new javax.swing.JButton();
        parameter = new javax.swing.JSpinner();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        listObjects.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listObjects);

        jButton1.setText("Cerrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnSeeProduct.setText("Ver producto");
        btnSeeProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeeProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setText("Eliminar producto");

        btnFill.setText("Filtar por compras");
        btnFill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFillActionPerformed(evt);
            }
        });

        btnPurchasesHistory.setText("Comprados");
        btnPurchasesHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchasesHistoryActionPerformed(evt);
            }
        });

        cmbGenres.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnRecently.setText("Recientes");
        btnRecently.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecentlyActionPerformed(evt);
            }
        });

        btnRating.setText("Rating");
        btnRating.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRatingActionPerformed(evt);
            }
        });

        btnGenres.setText("Categoría");
        btnGenres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenresActionPerformed(evt);
            }
        });

        cmbMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "3", "6", "All" }));

        lblFill.setText("Filtrar productos");

        btnClearFill.setText("Quitar filtro");
        btnClearFill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFillActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblFill)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnPurchasesHistory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGenres, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnRecently, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnRating, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(cmbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(spRating, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnClearFill)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(lblFill)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGenres)
                    .addComponent(cmbGenres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPurchasesHistory)
                    .addComponent(cmbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRecently)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRating)
                    .addComponent(spRating, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnClearFill)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jButton2.setText("Ver carrito");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnSeeProduct)
                                .addComponent(btnDeleteProduct))
                            .addComponent(btnFill))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(142, 142, 142)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btnSeeProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDeleteProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnFill)
                            .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(19, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenresActionPerformed

        objects.clear();
        modelListObject.clear();
        String selectedGenre = (String) cmbGenres.getSelectedItem();
        for (Product p : backupObjects){
            for (LogicClasses.Pair<Integer, String> genre : p.getGenres()){
                if (genre.getSecond().equals(selectedGenre)){
                    objects.add(new Triple<>(p.getIdProduct(), p.getTitle(),
                        p.getImages().get(0).getSecond()));
                    ImageIcon imageIcon = getImage(p.getImages().get(0).getSecond());
                    modelListObject.addElement(new ImgNText(
                    "<html>" + p.getTitle() + "</html>",imageIcon));
                    break;
                }
            }
        }
    }//GEN-LAST:event_btnGenresActionPerformed

    private void btnRatingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRatingActionPerformed

        //controller.getPurchasesHistory(user.getId(), )
    }//GEN-LAST:event_btnRatingActionPerformed

    private void btnRecentlyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecentlyActionPerformed
        objects.clear();
        modelListObject.clear();
        for (Product p: backupObjects) {
            if (recentlyVisited.contains(p.getIdProduct())) {
                objects.add(new Triple<>(p.getIdProduct(), p.getTitle(),
                    p.getImages().get(0).getSecond()));
            ImageIcon imageIcon = getImage(p.getImages().get(0).getSecond());
            modelListObject.addElement(new ImgNText(
                "<html>" + p.getTitle() + "</html>",imageIcon));
            }
        }
    }//GEN-LAST:event_btnRecentlyActionPerformed

    private void btnPurchasesHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchasesHistoryActionPerformed
        int index = cmbMonth.getSelectedIndex();
        int month;
        month = switch (index) {
            case 0 -> 3;
            case 1 -> 6;
            default -> 0;
        };

        ArrayList<Integer> pIds;
        try {
            pIds = controller.getPurchasesHistory(user.getId(), month);
        } catch (SQLException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
            pIds = new ArrayList();
        }
        objects.clear();
        modelListObject.clear();
        for (Product p : backupObjects){
            objects.add(new Triple<>(p.getIdProduct(), p.getTitle(),
                p.getImages().get(0).getSecond()));
        }
        for (Product p : backupObjects){
            if (pIds.contains(p.getIdProduct())){
                objects.add(new Triple<>(p.getIdProduct(), p.getTitle(),
                    p.getImages().get(0).getSecond()));
                ImageIcon imageIcon = getImage(p.getImages().get(0).getSecond());
                modelListObject.addElement(new ImgNText(
                    "<html>" + p.getTitle() + "</html>",imageIcon));
            }
        }
    }//GEN-LAST:event_btnPurchasesHistoryActionPerformed

    private void btnFillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFillActionPerformed
        try{
            int N = (Integer) parameter.getValue();
            objects = controller.getTopNPurchases(N);
            modelListObject.clear();
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = getImage(object.getThird());
                modelListObject.addElement(new ImgNText(
                    "<html>" + object.getSecond() + "<br>Cantidad de compras: " + object.getId() + "</html>",imageIcon));
        }
        } catch(IOException | SQLException e){System.out.println(""+e.getMessage());}

    }//GEN-LAST:event_btnFillActionPerformed

    private void btnSeeProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeeProductActionPerformed

        /*The arraylist products have the same order that the listProducts
        * so index 0 in products it's equals to index 0 in listProducts
        */
        if (listObjects.getSelectedIndex() >=0) {
            int indexObject = listObjects.getSelectedIndex();
            int idObject = objects.get(indexObject).getFirst();

            if (typeOfObject.equals("Product")) {
                if (typeOfUser.equals("User")){
                    productUser.setAtributes(idObject);
                    productUser.setVisible(true);
                    productUser.update();
                } else if (typeOfUser.equals("Admin")){
                    productWindow = new ProductWindow();
                    productWindow.setPurpose("Edit");
                    productWindow.setProductInformation(idObject);
                    productWindow.setVisible(true);
                }
            } else {
                participantWindow = new ParticipantWindow();
                participantWindow.setParticipant(idObject);
                participantWindow.setPurpose("Edit");
                participantWindow.setVisible(true);
            }

            dispose();
        }
    }//GEN-LAST:event_btnSeeProductActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed
    private ImageIcon getImage(byte[] blob){
        ImageIcon imageIcon = new ImageIcon(blob);
        Image image = imageIcon.getImage(); // transform it 
        image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
        return (new ImageIcon(image));
    }
    private void btnClearFillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearFillActionPerformed
        for (Product p : backupObjects){
            ImageIcon imageIcon = getImage(p.getImages().get(0).getSecond());
            modelListObject.addElement(new ImgNText(p.getTitle(),imageIcon));
        }
    }//GEN-LAST:event_btnClearFillActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        shoppingCart.setVisible(true);
        shoppingCart.loadData(backupObjects);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClearFill;
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JButton btnFill;
    private javax.swing.JButton btnGenres;
    private javax.swing.JButton btnPurchasesHistory;
    private javax.swing.JButton btnRating;
    private javax.swing.JButton btnRecently;
    private javax.swing.JButton btnSeeProduct;
    private javax.swing.JComboBox<String> cmbGenres;
    private javax.swing.JComboBox<String> cmbMonth;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFill;
    private javax.swing.JList<String> listObjects;
    private javax.swing.JSpinner parameter;
    private javax.swing.JSpinner spRating;
    // End of variables declaration//GEN-END:variables
}
