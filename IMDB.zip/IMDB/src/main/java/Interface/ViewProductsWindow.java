package Interface;

import LogicClasses.Controller;
import LogicClasses.ImgNText;
import LogicClasses.Render;
import LogicClasses.Triple;
import LogicClasses.User;
import java.awt.Image;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

public class ViewProductsWindow extends javax.swing.JDialog {
    private ArrayList<Triple<Integer, String, byte[]>> objects;
    private ArrayList<Triple<Integer, String, byte[]>> backupObjects;
    private javax.swing.DefaultListModel modelListObject;
    private Controller controller;
    String typeOfUser = "Admin";
    String typeOfObject = null;
    ProductUser productUser;
    ProductWindow productWindow;
    ParticipantWindow participantWindow;
    User user;
    
    public ViewProductsWindow(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        controller = Controller.getInstance();
        user = User.getInstance();
        objects = new ArrayList<>();
        backupObjects = new ArrayList<>();
        modelListObject = new javax.swing.DefaultListModel();
        listObjects.setModel(modelListObject);
        productUser = new ProductUser();
        productWindow = new ProductWindow();
        participantWindow = new ParticipantWindow();
    }
  
    public void LoadData(String typeOfUser, String typeOfObject) {
        modelListObject.clear();
        this.typeOfUser = typeOfUser;
        this.typeOfObject = typeOfObject;
        if (typeOfUser.equals("User")) {
            btnDeleteProduct.setVisible(false);
            btnFill.setVisible(false);
            parameter.setVisible(false);
            btnFill.setEnabled(false);
        } else {
            btnFill.setVisible(true);
            parameter.setVisible(true);
            btnFill.setEnabled(true);
        }
        
        try {
            if (typeOfObject.equals("Product")){
                objects = controller.getProducts();
                backupObjects = objects;
                btnSeeProduct.setText("Ver producto");
                btnDeleteProduct.setText("Eliminar producto");
            } else{
                objects = controller.getParticipants();
                btnSeeProduct.setText("Ver participante");
                btnDeleteProduct.setText("Eliminar participante");
            }
                
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = new ImageIcon(object.getThird());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(object.getSecond(),imageIcon));
            }
            listObjects.setCellRenderer(new Render());
            listObjects.setModel(modelListObject);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void loadProduct(){
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listObjects = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        btnSeeProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        btnFill = new javax.swing.JButton();
        parameter = new javax.swing.JSpinner();
        btnPurchasesHistory = new javax.swing.JButton();
        spMonth = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        listObjects.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listObjects);

        jButton1.setText("Cerrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnSeeProduct.setText("Ver producto");
        btnSeeProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeeProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setText("Eliminar producto");

        btnFill.setText("Filtar por compras");
        btnFill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFillActionPerformed(evt);
            }
        });

        btnPurchasesHistory.setText("Historial de compras");
        btnPurchasesHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchasesHistoryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSeeProduct)
                            .addComponent(btnDeleteProduct)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnPurchasesHistory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnFill, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(spMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(112, 112, 112)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btnSeeProduct)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDeleteProduct)
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnFill)
                            .addComponent(parameter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPurchasesHistory)
                            .addComponent(spMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSeeProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeeProductActionPerformed
        
        /*The arraylist products have the same order that the listProducts
         * so index 0 in products it's equals to index 0 in listProducts
         */
        if (listObjects.getSelectedIndex() >=0) { 
        int indexObject = listObjects.getSelectedIndex();
        int idObject = objects.get(indexObject).getFirst();
    
        if (typeOfObject.equals("Product")) {
            if (typeOfUser.equals("User")){
                productUser.setAtributes(idObject);
                productUser.setVisible(true);
                productUser.update();
            } else if (typeOfUser.equals("Admin")){
                productWindow.setPurpose("Edit");
                productWindow.setProductInformation(idObject);
                productWindow.setVisible(true);
            }
        } else {
            participantWindow.setParticipant(idObject);
            participantWindow.setPurpose("Edit");
            participantWindow.setVisible(true);
        }
        
        dispose();
        }
    }//GEN-LAST:event_btnSeeProductActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnFillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFillActionPerformed
        try{
            int N = (Integer) parameter.getValue();
            objects = controller.getTopNPurchases(N);
            modelListObject.clear();
            for (Triple<Integer, String, byte[]> object : objects){
                ImageIcon imageIcon = new ImageIcon(object.getThird());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(
                        "<html>" + object.getSecond() + "<br>Cantidad de compras: " + object.getId() + "</html>",imageIcon));
            }
        } catch(IOException | SQLException e){System.out.println(""+e.getMessage());}
        
    }//GEN-LAST:event_btnFillActionPerformed

    private void btnPurchasesHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchasesHistoryActionPerformed
        int month = (Integer) spMonth.getValue();
        ArrayList<Integer> pIds;
        try {
            pIds = controller.getPurchasesHistory(user.getId(), month);
        } catch (SQLException ex) {
            Logger.getLogger(ViewProductsWindow.class.getName()).log(Level.SEVERE, null, ex);
            pIds = new ArrayList();
        }
        objects.clear();
        modelListObject.clear();
        for (Triple<Integer, String, byte[]> product : backupObjects){
            if (pIds.contains(product.getFirst())){
                objects.add(product);
                ImageIcon imageIcon = new ImageIcon(product.getThird());
                Image image = imageIcon.getImage(); // transform it 
                image = image.getScaledInstance(200, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
                imageIcon = new ImageIcon(image);
                modelListObject.addElement(new ImgNText(
                        "<html>" + product.getSecond() + "<br>Cantidad de compras: " + product.getId() + "</html>",imageIcon));
            }
        }
    }//GEN-LAST:event_btnPurchasesHistoryActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JButton btnFill;
    private javax.swing.JButton btnPurchasesHistory;
    private javax.swing.JButton btnSeeProduct;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> listObjects;
    private javax.swing.JSpinner parameter;
    private javax.swing.JSpinner spMonth;
    // End of variables declaration//GEN-END:variables
}
