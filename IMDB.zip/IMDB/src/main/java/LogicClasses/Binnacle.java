package LogicClasses;

import java.util.ArrayList;

public class Binnacle {
    private ArrayList<String[]> data;
    public Binnacle(){
        data = new ArrayList();
    }
    public void addTuple(int idProduct, String title, int oldPrice, int newPrice, String date){
        //data.add(new Tuple(idProduct, title, oldPrice, newPrice, date));
        String info[] = new String[5];
        info[0] = "" + idProduct;
        info[1] = title;
        info[2] = "" + oldPrice;
        info[3] = "" + newPrice;
        info[4] = date;
        data.add(info);
    }
    public ArrayList<String[]> getData(){
        return data;
    }
    public void addTuplee (int argc, String ... argv){
        //String info[] = new String[argc];
        data.add(argv);
        /*for (int i = 0; i < argc; i++){
            info[i] = argv[i];
        }*/
    }
}


class Tuple{
    private int idProduct;
    private String title;
    private int oldPrice;
    private int newPrice;
    private String date;

    Tuple(int idProduct, String title, int oldPrice, int newPrice, String date) {
        this.idProduct = idProduct;
        this.title = title;
        this.oldPrice = oldPrice;
        this.newPrice = newPrice;
        this.date = date;
    }
    
    
}