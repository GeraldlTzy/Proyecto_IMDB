package LogicClasses;

public interface Complex {
    public int getId();
    public String getInfo();
}
