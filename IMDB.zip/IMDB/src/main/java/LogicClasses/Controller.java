/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import Connect.ConnectDB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kakas
 */
public class Controller {
    private static Controller instance = null;
    private Connection conn;
    private Controller(){
        conn = ConnectDB.getConnection();
    }
    
    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }
    
    
    public static ArrayList<String> validUser (String username, String password){
        try {
            return Person.validUser(username, password);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void insertNationality(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertNationality(?)}");
        sql.setString(1, name);
        sql.execute();
    }
}
