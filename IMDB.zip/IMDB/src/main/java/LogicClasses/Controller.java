package LogicClasses;

import Connect.ConnectDB;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kakas
 */
public class Controller {
    private static Controller instance = null;
    private ConnectDB conn;
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    private Controller(){
        conn = ConnectDB.getObject();
    }
    
    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }
    
    public void insertUser (int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, Long identification, Long phoneNumber, 
            String email, String password, int typeOfID, int nationality, boolean hasImage)throws FileNotFoundException, IOException, Exception{
        try {
        conn.insertUser(sex, firstName, secondName, firstSurname, secondSurname, 
                birthdate, image, username, identification, phoneNumber, email, password, typeOfID, nationality, hasImage);
        } catch (Exception e) {
            throw e;
        }
    }
    
    public static void insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            Integer pIdNationality, String pBiography, Integer pHeight, String pTrivia, String pPhotoPath) throws Exception {
        
        ConnectDB.insertParticipant(pSex, pFirstName, pSecondName, pFirstSurname, 
                pSecondSurname, pDateBirth, pCity, pIdNationality, pBiography, pHeight, pTrivia, pPhotoPath);
    }
    
    public static Pair<ArrayList<String>,byte[]> validUser (String username, String password){
        try {
            return ConnectDB.validUser(username, password);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void insertNationality(String name) throws SQLException {
        conn.insertNationality(name);
    }
     public void insertCountry(String name) throws SQLException {
        conn.insertCountry(name);
    }
    public void insertCity(String name, Integer idCountry) throws SQLException {
        conn.insertCity(name, idCountry);
    }
    public void insertTypeIdent(String name) throws SQLException {
        conn.insertTypeIdent(name);
    }
    public void insertTypeParticipant(String name) throws SQLException {
        conn.insertTypeParticipant(name);
    }
    public void insertTypeProduct(String name) throws SQLException {
        conn.insertTypeProduct(name);
    }
    public void insertCatalog(String name) throws SQLException {
        conn.insertCatalog(name);
    }
    public void insertPlatform(String name) throws SQLException {
        conn.insertPlatform(name);
    }
    public void insertSex(String name) throws SQLException {
        conn.insertSex(name);
    }
    public ArrayList<ArrayList<Pair<Integer,String>>> getInfoRegister() throws SQLException {
        return conn.getInfoRegister();
    }
    public ArrayList<Map<Integer, String>> getInfoInsertParticipant (Integer id) throws SQLException {
        return conn.getInfoInsertParticipant(id);
    }
    public ArrayList<Pair<byte[], ArrayList<String>>> getParticipant (Integer id) throws SQLException {
        return conn.getParticipants(id);
    }
    //Cambiar para que las nacionalidades sean un arreglo
    public Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        return conn.getInfoCreationProduct();
    }
    public Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException {
        return conn.insertProduct(idTypeProduct, releaseYear, title, duration, trailer, synopsis, price);
    }
    public void updateProduct(Integer idProduct, Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        conn.updateProduct(idProduct, idTypeProduct, releaseYear, title, duration, trailer, synopsis, price);
    }
    public void addParticipantToProduct(Integer pIdProduct, Integer pIdParticipant, Integer pIdRol) throws SQLException{
        conn.addParticipant(pIdProduct, pIdParticipant, pIdRol);
    }
    public void removeParticipantToProduct(int idProduct, int id) throws SQLException{
        conn.removeParticipantToProduct(idProduct, id);
    }
    public Integer addSeason(Integer pIdProduct, Integer pNumberSeason,
            Integer pDuration) throws SQLException {
        return conn.addSeason(pIdProduct, pNumberSeason, pDuration);
    }
    public void removeSeason(int pIdSeason) throws SQLException{
        conn.removeSeason(pIdSeason);
    }
            
    public void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        conn.addEpisode(pIdSeason, pNumberEpisode, pName, pDuration);
    }
    public void removeEpisode(int idEpisode) throws SQLException{
        conn.removeEpisode(idEpisode);
    }
    
    public void addImageToProduct(int idProduct, String imagePath) throws Exception {
        conn.addPhoto(idProduct, imagePath);
    }
    public ArrayList<Triple<Integer, String, byte[]>> getProducts() throws SQLException, IOException {
        return conn.getProducts();
    }
    public Product getProductInfo(int pIdProduct) throws SQLException, IOException {
        return conn.getProduct(pIdProduct);
    }

    public int[] checkRegister(String username, String email, Long phone) throws SQLException {
        return conn.checkRegister(username, email, phone);
    }
}
