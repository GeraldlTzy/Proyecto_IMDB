package LogicClasses;

import Connect.ConnectDB;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Controller {
    private static Controller instance = null;
    private ConnectDB conn;
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    private Controller(){
        conn = ConnectDB.getObject();
    }
    
    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }
    
    public int insertUser (int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, Long identification, Long phoneNumber, 
            String email, String password, int typeOfID, boolean hasImage)throws FileNotFoundException, IOException, Exception{
        try {
        return conn.insertUser(sex, firstName, secondName, firstSurname, secondSurname, 
                birthdate, image, username, identification, phoneNumber, email, password, typeOfID, hasImage);
        } catch (Exception e) {
            throw e;
        }
    }
    
    public int insertAdmin (int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, Long identification, Long phoneNumber, 
            String email, String password, int typeOfID, boolean hasImage)throws FileNotFoundException, IOException, Exception{
        try {
        return conn.insertAdmin(sex, firstName, secondName, firstSurname, secondSurname, 
                birthdate, image, username, identification, phoneNumber, email, password, typeOfID, hasImage);
        } catch (Exception e) {
            throw e;
        }
    }
    
    public int insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws Exception {
        
        return conn.insertParticipant(pSex, pFirstName, pSecondName, pFirstSurname, 
                pSecondSurname, pDateBirth, pCity, pBiography, pHeight, pTrivia, pPhoto);
    }
    
    public void updateParticipant (int pId, Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            String pBiography, Integer pHeight, String pTrivia, byte[] pPhoto) throws Exception {
        
        conn.updateParticipant(pId, pSex, pFirstName, pSecondName, pFirstSurname, 
                pSecondSurname, pDateBirth, pCity, pBiography, pHeight, pTrivia, pPhoto);
    }
    public void addNationalityToPerson(int idPerson, int idNationality) throws SQLException{
        conn.addNationalityToPerson(idPerson, idNationality);
    }
    
    public static Pair<ArrayList<String>,byte[]> validUser (String username, String password){
        try {
            return ConnectDB.validUser(username, password);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public ArrayList<ArrayList<Pair<Integer,String>>> getInfoRegister() throws SQLException {
        return conn.getInfoRegister();
    }
    public ArrayList<ArrayList<Pair<Integer, String>>> getInfoInsertParticipant (Integer id) throws SQLException {
        return conn.getInfoInsertParticipant(id);
    }
    public ArrayList<Participant> getParticipant (Integer id) throws SQLException {
        return conn.getParticipants(id);
    }
    
    public ArrayList<Triple<Integer, String, byte[]>> getParticipants() throws SQLException, IOException{
        return conn.getInfoParticipants();
    }
    
    //Cambiar para que las nacionalidades sean un arreglo
    public DataCreation getInfoCreationProduct() throws SQLException {
        return conn.getInfoCreationProduct();
    }
    public Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException {
        return conn.insertProduct(idTypeProduct, releaseYear, title, duration, trailer, synopsis, price);
    }
    public void updateProduct(Integer idProduct, Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        conn.updateProduct(idProduct, idTypeProduct, releaseYear, title, duration, trailer, synopsis, price);
    }
    public void addParticipantToProduct(Integer pIdProduct, Integer pIdParticipant, Integer pIdRol) throws SQLException{
        conn.addParticipant(pIdProduct, pIdParticipant, pIdRol);
    }
    public void removeParticipantToProduct(int idProduct, int id) throws SQLException{
        conn.removeParticipantToProduct(idProduct, id);
    }
    public Integer addSeason(Integer pIdProduct, Integer pNumberSeason) throws SQLException {
        return conn.addSeason(pIdProduct, pNumberSeason);
    }
    public void removeSeason(int pIdSeason) throws SQLException{
        conn.removeSeason(pIdSeason);
    }
            
    public void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        conn.addEpisode(pIdSeason, pNumberEpisode, pName, pDuration);
    }
    public void removeEpisode(int idEpisode) throws SQLException{
        conn.removeEpisode(idEpisode);
    }
    
    public void addImageToProduct(int idProduct, byte[] image) throws Exception {
        conn.addPhoto(idProduct, image);
    }
    public void removePhoto(int idImage) throws SQLException{
        conn.removePhoto(idImage);
    }
    
    public Pair<ArrayList<Product>, java.util.Map<Integer, String>> getProducts() throws SQLException, IOException {
        return conn.getProducts();
    }
    public Product getProductInfo(int pIdProduct) throws SQLException, IOException {
        return conn.getProduct(pIdProduct);
    }
    
    public ArrayList<String[]> getFullReview (int pIdProduct) throws SQLException, IOException {
        return conn.getFullReview(pIdProduct);
    }

    public boolean checkRegister(String username, String email, Long phone) throws SQLException {
        return conn.checkRegister(username, email, phone);
    }
    
    public void addCommentary(int idUser, int idProduct, String comment) throws SQLException{
        conn.addCommentary(idUser, idProduct, comment);
    }
    public void addReview(int idUser, int idProduct, int stars) throws SQLException {
        conn.addReview(idUser, idProduct, stars);
    }
    
    public void updateCommentary(int idUser, int idProduct, String comment) throws SQLException{
        conn.updateCommentary(idUser, idProduct, comment);
    }
    public void updateReview(int idUser, int idProduct, int stars) throws SQLException {
        conn.updateReview(idUser, idProduct, stars);
    }
    
    public void insertCard(int idUser, int cardNumber, String date, int ccv, String owner) throws SQLException{
        conn.insertCard(idUser, cardNumber, date, ccv, owner);
    }
    public ArrayList<String[]> getPaymentMethods(int idUser) throws SQLException{
        return conn.getPaymentMethods(idUser);
    }
    public void buyProduct(int idUser, int idProduct, int idPayment) throws SQLException{
        conn.buyProduct(idUser, idProduct, idPayment);
    }
    public void addFavorite(int idUser, int idProduct) throws SQLException{
        conn.addFavorite(idUser, idProduct);
    }

    public ArrayList<Triple<Integer, String, byte[]>> getUserFavorites(int idUser) throws SQLException {
        return conn.getUserFavorites(idUser);
    }

    public void insertBasicObject(String objectToAdd, String name, int second) throws SQLException {
        conn.insertBasicObject(objectToAdd, name, second);
    }
    
    public ArrayList<Pair<Integer, String>> getBasicObject(String objectToAdd) throws SQLException {
        return conn.getBasicObject(objectToAdd);
    }

    public void updateBasicObject(String objectToAdd, int editIdObject, String text, int third) throws SQLException {
        conn.updateBasicObject(objectToAdd, editIdObject, text, third);
    }
    public void removeBasicObject(String objectToRemove, int id) throws SQLException{
        conn.removeBasicObject(objectToRemove, id);
    }
    public void addGenreProduct(int idGenre, int idProduct) throws SQLException {
        conn.addGenreProduct(idGenre, idProduct);
    }

    public void addPlatformProduct(int idPlatform, int idProduct) throws SQLException {
        conn.addPlatformProduct(idPlatform, idProduct);
    }
    public Stats getStatistics() throws SQLException {
        return conn.getStatistics();
    }
    public void deleteFavorite(int idUser, int idProduct) throws SQLException{
        conn.deleteFavorite(idUser, idProduct);
    }
    public ArrayList<Triple<Integer, String, byte[]>> getTopNPurchases(int N) throws SQLException, IOException{
        return conn.getTopNPurchases(N);
    }
    public ArrayList<Integer> getPurchasesHistory(int idUser, int month) throws SQLException{
        return conn.getPurchasesHistory(idUser, month);
    }
    public ArrayList<String[]> getBinnacle() throws SQLException{
        return conn.getBinnacle();
    }
    public List<Integer> getRecentlyVisited(int idUser) throws Exception {
        return conn.getRecentlyVisited(idUser);
    }
    public void visitProduct(int idUser, int idProduct) {
        try {
            conn.visitProduct(idUser,idProduct);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void insertRelative(int idParticipant, int idRelative, int idKindship) throws SQLException{
        conn.insertRelative(idParticipant, idRelative, idKindship);
    }
    public void deleteParticipant(int id) throws SQLException{
        conn.deleteParticipant(id);
    }
    public void deleteProduct(int id) throws SQLException{
        conn.deleteProduct(id);
    }
}
