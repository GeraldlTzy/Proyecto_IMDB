/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import Connect.ConnectDB;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Controller {
    private static Controller instance = null;
    private Connection conn;
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    private Controller(){
        conn = ConnectDB.getConnection();
    }
    
    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }
    
    public static void insertUser (int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            byte[] image, String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID, int nationality, boolean hasImage)throws FileNotFoundException, IOException, Exception{
        try {
            Person.insertUser(sex, firstName, secondName, firstSurname, secondSurname,
                    birthdate, image, username, identification, phoneNumber, email,
                    password, typeOfID, nationality, hasImage);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            Integer pIdNationality, String pBiography, Integer pHeight, String pTrivia, String pPhotoPath) throws Exception {
        
        Person.insertParticipant (pSex, pFirstName, pSecondName,
            pFirstSurname, pSecondSurname, pDateBirth, pCity,
            pIdNationality, pBiography, pHeight, pTrivia, pPhotoPath);
    }
    
    public static ArrayList<String> validUser (String username, String password){
        try {
            return Person.validUser(username, password);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void insertNationality(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertNationality(?)}");
        sql.setString(1, name);
        sql.execute();
    }
     public void insertCountry(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCountry(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertCity(String name, Integer idCountry) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCity(?, ?)}");
        sql.setString(1, name);
        sql.setInt(2, idCountry);
        sql.execute();
    }
    public void insertTypeIdent(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeIdent(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertTypeParticipant(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeParticipant(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertTypeProduct(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertTypeProduct(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertCatalog(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertCatalog(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertPlatform(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertPlatform(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public void insertSex(String name) throws SQLException {
        CallableStatement sql;
        sql = conn.prepareCall("{call pkgBasic.insertSex(?)}");
        sql.setString(1, name);
        sql.execute();
    }
    public TreeMap<Integer, String> getNationality(Integer id) throws SQLException {
        TreeMap<Integer, String> nationalities = new TreeMap<>();
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getNationality(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        if (id != null) sql.setInt(2, id);
        else sql.setNull(2, OracleTypes.NULL);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        
        while (rs.next()){
            nationalities.put(rs.getInt(1), rs.getString(2));
            System.out.println("Id: " + rs.getInt(1) + "Nombre: " + rs.getString(2));
        }
        return nationalities;
    }
    public ArrayList<Map<Integer, String>> getInfoRegisterParticipant (Integer id) throws SQLException {
        ArrayList<Map<Integer, String>> data = new ArrayList<>();
        TreeMap<Integer, String> nationalities = new TreeMap<>();
        LinkedHashMap<Integer, String> cities = new LinkedHashMap<>();
        
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getInfoRegisterParticipant(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        if (id != null) sql.setInt(2, id);
        else sql.setNull(2, OracleTypes.NULL);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        
        while (rs.next()){
            if (rs.getString(3).equals("Nationality"))
                nationalities.put(rs.getInt(1), rs.getString(2));
            else
                cities.put(rs.getInt(1), rs.getString(2));
            //System.out.println("Id: " + rs.getInt(1) + " Nombre: " + rs.getString(2));
        }
        data.add(nationalities);
        data.add(cities);
        return data;
    }
    public ArrayList<Pair<byte[], ArrayList<String>>> getParticipant (Integer id) throws SQLException {
        return Person.getParticipants(id);
    }
    //Cambiar para que las nacionalidades sean un arreglo
    public Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        return Product.getInfoCreationProduct();
    }
    public Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException {
        return Product.insertProduct(idTypeProduct, releaseYear, title, duration, trailer, synopsis, price);
    }
    public void addParticipantToProduct(Integer pIdProduct, Integer pIdParticipant, Integer pIdRol) throws SQLException{
        Product.addParticipant(pIdProduct, pIdParticipant, pIdRol);
    }
    public Integer addSeason(Integer pIdProduct, Integer pNumberSeason,
            Integer pDuration) throws SQLException {
        return Product.addSeason(pIdProduct, pNumberSeason, pDuration);
    }
    public void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        Product.addEpisode(pIdSeason, pNumberEpisode, pName, pDuration);
    }
    public void addImageToProduct(int idProduct, String imagePath) throws Exception {
        Product.addPhoto(idProduct, imagePath);
    }
}
