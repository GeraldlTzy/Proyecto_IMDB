package LogicClasses;


import java.util.ArrayList;

public class DataCreation {
    private ArrayList<Pair<byte[], String>> participants;
    private ArrayList<Pair<Integer, String>> roles;
    private ArrayList<Pair<Integer, String>> types;
    private ArrayList<Pair<Integer, String>> genres;
    private ArrayList<Pair<Integer, String>> platforms;
    
    public DataCreation(){
        participants = new ArrayList();
        roles = new ArrayList();
        types = new ArrayList();
        genres = new ArrayList();
        platforms = new ArrayList();
    }

    public ArrayList<Pair<Integer, String>> getPlatforms() {
        return platforms;
    }
    
    public void addParticipant(int id, byte[] image, String name){
        Pair<byte[], String> participant = new Pair(image, name);
        participant.setId(id);
        participants.add(participant);
    }
    public void addRol(int id, String name){
        Pair<Integer, String> role = new Pair(id, name);
        roles.add(role);
    }
    public void addType(int id, String name){
        Pair<Integer, String> type = new Pair(id, name);
        types.add(type);
    }
    
    public void addGenre(int id, String name){
        Pair<Integer, String> genre = new Pair(id, name);
        genres.add(genre);
    }
    public void addPlatform(int id, String name){
        platforms.add(new Pair(id, name));
    }

    public ArrayList<Pair<byte[], String>> getParticipants() {
        return participants;
    }

    public ArrayList<Pair<Integer, String>> getRoles() {
        return roles;
    }

    public ArrayList<Pair<Integer, String>> getTypes() {
        return types;
    }

    public ArrayList<Pair<Integer, String>> getGenres() {
        return genres;
    }
}
