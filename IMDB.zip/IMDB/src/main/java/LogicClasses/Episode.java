package LogicClasses;

public class Episode implements Complex {
    public int id;
    public int idSeason;
    public int duration;
    public String name;
    public int number;

    public Episode(int id, int idSeason, int duration, String name, int number) {
        this.id = id;
        this.idSeason = idSeason;
        this.duration = duration;
        this.name = name;
        this.number = number;
    
    }
    
    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getInfo() {
        return name;
    }    
}
