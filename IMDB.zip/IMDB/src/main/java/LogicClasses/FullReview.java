package LogicClasses;

public class FullReview implements Complex {
    int idUser;
    String username;
    String comment;
    String dateComment;
    int review;
    String text;
    
    public FullReview(int idUser, String username, String comment, String dateComment, int review) {
        this.idUser = idUser;
        this.username = username;
        this.comment = comment;
        this.dateComment = dateComment;
        this.review = review;
    }

    public void setText(String text){
        this.text = text;
    }

    public String getUsername() {
        return username;
    }

    public String getComment() {
        return comment;
    }

    public String getDateComment() {
        return dateComment;
    }

    public int getReview() {
        return review;
    }
    
    
    @Override
    public int getId() {
        return idUser;
    }

    @Override
    public String getInfo() {
        return text;
    }
    
}
