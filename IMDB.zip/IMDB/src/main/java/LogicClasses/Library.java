/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author kakas
 */
public class Library {
    public static byte[] image_to_byte(String path) throws Exception {
        byte[] image;
        try {
            FileInputStream fis = new FileInputStream(path);
            image = new byte[fis.available()];
            fis.read(image);
            return image;
        }catch (FileNotFoundException e) {
            throw new Exception("Error: No se encontró la imagen.");
        }catch (IOException ex) {
            throw new Exception("Error: No se pudo leer la imagen.");
        }
    }
}
