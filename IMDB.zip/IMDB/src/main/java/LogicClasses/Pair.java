package LogicClasses;

public class Pair<F, S> implements Complex{
    private F first;
    private S second;
    private int id;
    private String text;
    public Pair(F first, S second){
        this.first = first;
        this.second = second;
    }
    public void setFirst(F first) {this.first = first;}
    public void setSecond(S second){this.second = second;}
    public F getFirst() {return first;}
    public S getSecond(){return second;}
    public boolean equals (Pair<F, S> other){
        if (other.first != this.first) return false;
        if (other.second != this.second) return false;
        return true;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getInfo() {
        return text;
    }
    public void setId(int id){this.id = id;}
    public void setText(String text){this.text = text;}
}
