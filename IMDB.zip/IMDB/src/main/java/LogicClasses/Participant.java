package LogicClasses;
import java.util.ArrayList;

public class Participant {
    public int idParticipant;
    public String firstName;
    public String secondName;
    public String firstSurname;
    public String secondSurname;
    public String birthdate;
    public byte[] photo;
    /*public String nameCity;
    public String nameCountry;*/
    public int idCity;
    public String biography;
    public int heigth;
    public String trivia;
    public int idSex;
    private ArrayList<Integer> nationalities, relatives;
    
    public Participant(int idParticipant, String firstName, String secondName, String firstSurname, String secondSurname, String birthdate, byte[] photo, int idCity, String biography, int heigth, String trivia, int idSex) {
        this.idParticipant = idParticipant;
        this.firstName = firstName;
        this.secondName = secondName;
        this.firstSurname = firstSurname;
        this.secondSurname = secondSurname;
        this.birthdate = birthdate;
        this.photo = photo;
        this.idCity = idCity;
        this.biography = biography;
        this.heigth = heigth;
        this.trivia = trivia;
        this.idSex = idSex;
        nationalities = new ArrayList();
        relatives = new ArrayList();
    }
    public ArrayList<Integer> getNationalities(){
        return nationalities;
    }
    public void addNationality(int idNat){
        nationalities.add(idNat);
    }
    public ArrayList<Integer> getRelatives(){
        return relatives;
    }
    public void addRelative(int idRelative){
        relatives.add(idRelative);
    }
    
}
