package LogicClasses;

import Connect.ConnectDB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Person {
    public static ArrayList<String> getUserInfo() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call pkgEnd_user.getInfo(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<String> userInfo = new ArrayList<>();
        
        userInfo.add(rs.getString("NombreColumna"));
        userInfo.add(Integer.toString(rs.getInt("idUser")));
        userInfo.add("Hola");
        
        return userInfo;
    }
    public static Integer validUser(String username, String password) throws SQLException {
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getSystemUserInfo('GeraldC', '@22[^Q8xhj#')}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        /*sql.setString(2, username);
        sql.setString(3, password);*/
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        //for (int i = 0; i < 5; i++){
        
        //}
        while (rs.next()){
            System.out.println("Valor " + 1 + ": " + rs.getString(1));
            //System.out.println("Valor " + 1 + ": " + rs.getString(2));
            //System.out.println("Valor " + 1 + ": " + rs.getString(3));
        }
        
        
        
        //return (Integer) sql.getObject(1);
        return 1;
    }
}
