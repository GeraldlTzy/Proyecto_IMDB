package LogicClasses;

import Connect.ConnectDB;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Person {
    private static Connection conn = ConnectDB.getConnection();
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    /*private Person(){
        conn = ConnectDB.getConnection();
    }*/
    public static boolean checkRegister(String username, int phoneNumber, String email)throws SQLException {
        CallableStatement stmt = conn.prepareCall("{existsUsername(?)}");
        stmt.registerOutParameter(2, Types.VARCHAR);
        stmt.setString(1, username);
        stmt.execute();
        ResultSet rs1 = (ResultSet) stmt.getObject(2);
        
        CallableStatement stmt2 = conn.prepareCall("{existsEmail(?)}");
        stmt2.registerOutParameter(2, Types.VARCHAR);
        stmt2.setString(1, email);
        stmt2.execute();
        ResultSet rs2 = (ResultSet) stmt2.getObject(2);
        //If the username or the email already exists, returns false
        if (rs1.getInt("usernamesCount")>0 && rs2.getInt("emailCount")>0) {
            return false;
        } else 
        return true;
    }
    
    public static void insertAdmin(int sex, String firstName, String secondName,
            String firstSurname, String secondSurname, String birthdate, 
            String username, int identification, int phoneNumber, 
            String email, String password, int typeOfID) throws SQLException {
        
        //Connection conn = ConnectDB.getConnection();
        
        CallableStatement stmt = conn.prepareCall("{ call pkgAdmin.insertAdmin(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?,?)}");
        stmt.setInt(1, sex);
        stmt.setString(2, firstName);
        stmt.setString(3, secondName);
        stmt.setString(4, firstSurname);
        stmt.setString(5, secondSurname);
        stmt.setString(6, birthdate);
        stmt.setString(7, username);
        stmt.setInt(8, identification);
        stmt.setInt(9, phoneNumber);
        stmt.setString(10, email);
        stmt.setString(11, password);
        stmt.setInt(12, typeOfID);
        stmt.execute();
    }
    
    public static void insertParticipant (Integer pSex, String pFirstName, String pSecondName,
            String pFirstSurname, String pSecondSurname, String pDateBirth, Integer pCity,
            Integer pIdNationality, String pBiography, Integer pHeight, String pTrivia, String pPhotoPath) throws SQLException, Exception
            
            
        /*(pSex IN NUMBER, pFirstName IN VARCHAR2, pSecondName IN VARCHAR2,
    pFirstSurname IN VARCHAR2, pSecondSurname IN VARCHAR2, pDateBirth IN DATE,
    pCity IN NUMBER, pIdNationality IN NUMBER, pBiography IN VARCHAR2, pHeight IN NUMBER, 
    pTrivia IN VARCHAR2, pPhoto IN BLOB)*/{
    
        CallableStatement sql = conn.prepareCall("{ call pkgParticipant.insertParticipant(?,?,?,?,?,TO_DATE(?,'DD/MM/YYYY'),?,?,?,?,?,?)}");
        
        byte[] image;
        try {
            FileInputStream fis = new FileInputStream(pPhotoPath);
            image = new byte[fis.available()];
            fis.read(image);
        }catch (FileNotFoundException e) {
            throw new Exception("Error: No se encontró la imagen.");
        }catch (IOException ex) {
            throw new Exception("Error: No se pudo leer la imagen.");
        }
        
        sql.setInt(1, pSex);
        sql.setString(2, pFirstName);
        sql.setString(3, pSecondName);
        sql.setString(4, pFirstSurname);
        sql.setString(5, pSecondSurname);
        sql.setString(6, pDateBirth);
        sql.setInt(7, pCity);
        sql.setInt(8, pIdNationality);
        sql.setString(9, pBiography);
        sql.setInt(10, pHeight);
        sql.setString(11, pTrivia);
        sql.setBytes(12, image);
        sql.execute();
    }
    
    public static ArrayList<String> getUserInfo() throws SQLException{
        //Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call pkgEnd_user.getInfo(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<String> userInfo = new ArrayList<>();
        
        userInfo.add(rs.getString("NombreColumna"));
        userInfo.add(Integer.toString(rs.getInt("idUser")));
        userInfo.add("Hola");
        
        return userInfo;
    }
    public static ArrayList<String> validUser(String username, String password) throws SQLException {
        //Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call pkgBasic.getSystemUserInfo(?, ?)}");
        
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.setString(2, username);
        sql.setString(3, password);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        //for (int i = 0; i < 5; i++){
        ArrayList<String> userInfo = new ArrayList();
        //}
        while (rs.next()){
            if (rs.getInt(1) != 2) {
                return null;
            }
            System.out.println("Valor " + 1 + ": " + rs.getString(1));
            System.out.println("Valor " + 1 + ": " + rs.getString(2));
            System.out.println("Valor " + 1 + ": " + rs.getString(3));
            
            userInfo.add(rs.getString(1));
            userInfo.add(rs.getString(2));
        }
        
        
        //return (Integer) sql.getObject(1);
        return userInfo;
    }
        
    public static ArrayList<Pair<byte[], ArrayList<String>>> getParticipants(Integer id) throws SQLException {
        ArrayList<Pair<byte[], ArrayList<String>>> participants = new ArrayList();
        ArrayList<String> participant;
        CallableStatement sql = conn.prepareCall("{? = call pkgParticipant.getParticipant(?)}");
        
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        if (id != null) sql.setInt(2, id);
        else sql.setNull(2, OracleTypes.NULL);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        //for (int i = 0; i < 5; i++){
        //ArrayList<String> userInfo = new ArrayList();
        //}
        while (rs.next()){
            participant = new ArrayList<>();
            participant.add(rs.getString(1));
            participant.add(rs.getString(2));
            participant.add(rs.getString(3));
            participant.add(rs.getString(4));
            participant.add(rs.getString(5));
            Date datebirth = rs.getDate(6);
            String date = formatDate.format(datebirth);
            participant.add(date);
                        
            Blob blob = rs.getBlob(7);
            byte[] blobBytes = blob.getBytes(1, (int) blob.length());
                      
            System.out.println(date);
            
            //ImageIcon imageIcon = new ImageIcon(blobBytes);
            //participant.add(rs.getString(7));
            participant.add(rs.getString(8));
            participant.add(rs.getString(9));
            participant.add(rs.getString(10));
            participant.add(rs.getString(11));
            
            //System.out.println(rs.getString(1) + rs.getString(2));
            Pair<byte[], ArrayList<String>> data = new Pair<byte[], ArrayList<String>>(blobBytes, participant);
            participants.add(data);
        }
        
        return participants;
    }
}
/*class KVPair(){
    public KVPair(K key, V value){}
}*/
