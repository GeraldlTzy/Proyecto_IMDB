/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import Connect.ConnectDB;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Product {
    private static Connection conn = ConnectDB.getConnection();
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    //Cambiar para que las nacionalidades sean un arreglo
    public static Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgBasic.getInfoCreationProduct(?, ?, ?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rsParticipants = (ResultSet) sql.getObject(1);
        ResultSet rsTypeParticipants = (ResultSet) sql.getObject(2);
        ResultSet rsTypeProducts = (ResultSet) sql.getObject(3);
        /**********************************************************************/
        ArrayList<Pair<byte[], String[]>> participants = new ArrayList<>();
        ArrayList<String[]> typeParticipants = new ArrayList<>();
        ArrayList<String[]> typeProducts = new ArrayList<>();
        String[] participant = new String[12];
        String[] typeParticipant = new String[2];
        String[] typeProduct = new String[2];
        Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> data;
        data = new Triple<>(typeParticipants, typeProducts, participants);
        /**********************************************************************/
        while (rsParticipants.next()){
            participant[0] = rsParticipants.getString(1);
            participant[1] = rsParticipants.getString(2);
            participant[2] = rsParticipants.getString(3);
            participant[3] = rsParticipants.getString(4);
            participant[4] = rsParticipants.getString(5);
            Date datebirth = rsParticipants.getDate(6);
            String date = formatDate.format(datebirth);
            participant[5] = date;
            Blob blob = rsParticipants.getBlob(7);
            byte[] blobBytes = blob.getBytes(1, (int) blob.length());
            participant[6] = rsParticipants.getString(8);
            participant[7] = rsParticipants.getString(9);
            participant[8] = rsParticipants.getString(10);
            participant[9] = rsParticipants.getString(11);
            participant[10] = rsParticipants.getString(12);
            participant[11] = rsParticipants.getString(13);
            Pair<byte[], String[]> dataParticipant = new Pair<byte[], String[]>(blobBytes, participant);
            participants.add(dataParticipant);
        }
        while (rsTypeParticipants.next()){
            typeParticipant[0] = rsTypeParticipants.getString(1);
            typeParticipant[1] = rsTypeParticipants.getString(2);
            typeParticipants.add(typeParticipant);
        }
        while (rsTypeProducts.next()) {
            typeProduct[0] = rsTypeProducts.getString(1);
            typeProduct[1] = rsTypeProducts.getString(2);
            typeProducts.add(typeProduct);
        }
        /**********************************************************************/
        return data;
    }
    public static Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgProduct.insertProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idTypeProduct);
        sql.setInt(2, releaseYear);
        sql.setString(3, title);
        sql.setInt(4, duration);
        sql.setString(5, synopsis);
        sql.setString(6, trailer);
        sql.setInt(7, price);
        sql.registerOutParameter(8, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdProduct = sql.getInt(8);
        System.out.println(""+rsIdProduct);
        return rsIdProduct;
        /**********************************************************************/
    }
    /*PROCEDURE addParticipant(pIdProduct IN NUMBER, pIdParticipant IN NUMBER, pRol IN NUMBER);
    PROCEDURE addSeason(pIdProduct IN NUMBER, pNumberSeason IN NUMBER, pDuration IN NUMBER);
    PROCEDURE addEpisode(pIdSeason IN NUMBER,pNumberEpisode IN NUMBER, pName IN VARCHAR2,
    pDuration IN NUMBER);
    PROCEDURE addPhoto(pIdProduct IN NUMBER, pImage IN BLOB);*/
    public static void addParticipant(Integer pIdProduct, Integer pIdParticipant,
            Integer pRol) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addParticipant(?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdParticipant);
        sql.setInt(3, pRol);
        sql.execute();
    }
    public static Integer addSeason(Integer pIdProduct, Integer pNumberSeason,
            Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addSeason(?, ?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pNumberSeason);
        sql.setInt(3, pDuration);
        sql.registerOutParameter(4, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdSeason = sql.getInt(4);
        return rsIdSeason;
    }
    public static void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addEpisode(?, ?, ?, ?)}");
        sql.setInt(1, pIdSeason);
        sql.setInt(2, pNumberEpisode);
        sql.setString(3, pName);
        sql.setInt(4, pDuration);
        sql.execute();
    }
    public static void addPhoto(int pIdProduct, String pImagePath) throws SQLException, Exception {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addPhoto(?, ?)}");
        byte[] image;
        
        try {
            FileInputStream fis = new FileInputStream(pImagePath);
            image = new byte[fis.available()];
            fis.read(image);
        }catch (FileNotFoundException e) {
            throw new Exception("Error: No se encontró la imagen.");
        }catch (IOException ex) {
            throw new Exception("Error: No se pudo leer la imagen.");
        }
        
        sql.setInt(1, pIdProduct);
        sql.setBytes(2, image);
        sql.execute();
    }
}
