/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import Connect.ConnectDB;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author kakas
 */
public class Product {
    private static Connection conn = ConnectDB.getConnection();
    private static SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    //Cambiar para que las nacionalidades sean un arreglo
    public static Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> getInfoCreationProduct() throws SQLException {
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgBasic.getInfoCreationProduct(?, ?, ?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rsParticipants = (ResultSet) sql.getObject(1);
        ResultSet rsTypeParticipants = (ResultSet) sql.getObject(2);
        ResultSet rsTypeProducts = (ResultSet) sql.getObject(3);
        /**********************************************************************/
        ArrayList<Pair<byte[], String[]>> participants = new ArrayList<>();
        ArrayList<String[]> typeParticipants = new ArrayList<>();
        ArrayList<String[]> typeProducts = new ArrayList<>();
        String[] participant = new String[12];
        String[] typeParticipant = new String[2];
        String[] typeProduct = new String[2];
        Triple<ArrayList<String[]>,ArrayList<String[]>, ArrayList<Pair<byte[], String[]>>> data;
        data = new Triple<>(typeParticipants, typeProducts, participants);
        /**********************************************************************/
        while (rsParticipants.next()){
            participant[0] = rsParticipants.getString(1);
            participant[1] = rsParticipants.getString(2);
            participant[2] = rsParticipants.getString(3);
            participant[3] = rsParticipants.getString(4);
            participant[4] = rsParticipants.getString(5);
            Date datebirth = rsParticipants.getDate(6);
            String date = formatDate.format(datebirth);
            participant[5] = date;
            Blob blob = rsParticipants.getBlob(7);
            byte[] blobBytes = blob.getBytes(1, (int) blob.length());
            participant[6] = rsParticipants.getString(8);
            participant[7] = rsParticipants.getString(9);
            participant[8] = rsParticipants.getString(10);
            participant[9] = rsParticipants.getString(11);
            participant[10] = rsParticipants.getString(12);
            participant[11] = rsParticipants.getString(13);
            Pair<byte[], String[]> dataParticipant = new Pair<byte[], String[]>(blobBytes, participant);
            participants.add(dataParticipant);
        }
        while (rsTypeParticipants.next()){
            typeParticipant[0] = rsTypeParticipants.getString(1);
            typeParticipant[1] = rsTypeParticipants.getString(2);
            typeParticipants.add(typeParticipant);
        }
        while (rsTypeProducts.next()) {
            typeProduct[0] = rsTypeProducts.getString(1);
            typeProduct[1] = rsTypeProducts.getString(2);
            typeProducts.add(typeProduct);
        }
        /**********************************************************************/
        return data;
    }
    public static Integer insertProduct(Integer idTypeProduct, Integer releaseYear, String title, 
            Integer duration, String trailer, String synopsis, Integer price) throws SQLException{
        /**********************************************************************/
        CallableStatement sql = conn.prepareCall("{call pkgProduct.insertProduct(?, ?, ?, ?, ?, ?, ?, ?)}");
        
        sql.setInt(1, idTypeProduct);
        sql.setInt(2, releaseYear);
        sql.setString(3, title);
        sql.setInt(4, duration);
        sql.setString(5, synopsis);
        sql.setString(6, trailer);
        sql.setInt(7, price);
        sql.registerOutParameter(8, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdProduct = sql.getInt(8);
        System.out.println(""+rsIdProduct);
        return rsIdProduct;
        /**********************************************************************/
    }
    /*PROCEDURE addParticipant(pIdProduct IN NUMBER, pIdParticipant IN NUMBER, pRol IN NUMBER);
    PROCEDURE addSeason(pIdProduct IN NUMBER, pNumberSeason IN NUMBER, pDuration IN NUMBER);
    PROCEDURE addEpisode(pIdSeason IN NUMBER,pNumberEpisode IN NUMBER, pName IN VARCHAR2,
    pDuration IN NUMBER);
    PROCEDURE addPhoto(pIdProduct IN NUMBER, pImage IN BLOB);*/
    public static void addParticipant(Integer pIdProduct, Integer pIdParticipant,
            Integer pRol) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addParticipant(?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pIdParticipant);
        sql.setInt(3, pRol);
        sql.execute();
    }
    public static Integer addSeason(Integer pIdProduct, Integer pNumberSeason,
            Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addSeason(?, ?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.setInt(2, pNumberSeason);
        sql.setInt(3, pDuration);
        sql.registerOutParameter(4, OracleTypes.NUMBER);
        sql.execute();
        Integer rsIdSeason = sql.getInt(4);
        return rsIdSeason;
    }
    public static void addEpisode(Integer pIdSeason, Integer pNumberEpisode,
            String pName, Integer pDuration) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addEpisode(?, ?, ?, ?)}");
        sql.setInt(1, pIdSeason);
        sql.setInt(2, pNumberEpisode);
        sql.setString(3, pName);
        sql.setInt(4, pDuration);
        sql.execute();
    }
    public static void addPhoto(int pIdProduct, String pImagePath) throws SQLException, Exception {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.addPhoto(?, ?)}");
        byte[] image;
        
        try {
            FileInputStream fis = new FileInputStream(pImagePath);
            image = new byte[fis.available()];
            fis.read(image);
        }catch (FileNotFoundException e) {
            throw new Exception("Error: No se encontró la imagen.");
        }catch (IOException ex) {
            throw new Exception("Error: No se pudo leer la imagen.");
        }
        
        sql.setInt(1, pIdProduct);
        sql.setBytes(2, image);
        sql.execute();
    }
    public static ArrayList<Triple<Integer, String, byte[]>> getProducts() throws SQLException, FileNotFoundException, IOException{
        CallableStatement sql = conn.prepareCall("{? = call pkgProduct.getProducts}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Triple<Integer, String, byte[]>> products = new ArrayList<>();
        Triple<Integer, String, byte[]> product;
        int idProduct = -1;
        while (rs.next()) {
            if (rs.getInt(1) != idProduct) {
                idProduct = rs.getInt(1);
                String title = rs.getString(2);
                Blob blob = rs.getBlob(3);
                byte[] blobBytes;
                if (blob != null) {
                    blobBytes = blob.getBytes(1, (int) blob.length());
                } else {
                    FileInputStream fis = new FileInputStream("DefaultImageProduct.png");
                    blobBytes = new byte[fis.available()];
                    fis.read(blobBytes);
                    fis.close();
                }
                product = new Triple<>(idProduct, title, blobBytes);
                products.add(product);
            }
        }
        return products;
        
    }
    public static void getProduct(int pIdProduct) throws SQLException {
        CallableStatement sql = conn.prepareCall("{call pkgProduct.getProductInfo(?, ?, ?, ?)}");
        sql.setInt(1, pIdProduct);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(3, OracleTypes.REF_CURSOR);
        sql.registerOutParameter(4, OracleTypes.REF_CURSOR);
        //sql.registerOutParameter(5, OracleTypes.REF_CURSOR);
        sql.execute();
        ResultSet rsInfoProduct = (ResultSet) sql.getObject(2);
        ResultSet rsParticipantsProduct = (ResultSet) sql.getObject(3);
        ResultSet rsSeasonsProduct = (ResultSet) sql.getObject(4);
        //ResultSet rsImagesProduct = (ResultSet) sql.getObject(5);
        String infoProduct[] = new String[8];
        /*Extract basic information about products*/
        while (rsInfoProduct.next()) {
            infoProduct[0] = rsInfoProduct.getString(1);
            infoProduct[1] = rsInfoProduct.getString(2);
            infoProduct[2] = rsInfoProduct.getString(3);
            infoProduct[3] = rsInfoProduct.getString(4);
            infoProduct[4] = rsInfoProduct.getString(5);
            infoProduct[5] = rsInfoProduct.getString(6);
            infoProduct[6] = rsInfoProduct.getString(7);
            infoProduct[7] = rsInfoProduct.getString(8);
        }
        /*Particpant x product*/
        String participantsProduct[] = new String[2];
        while (rsParticipantsProduct.next()) {
            participantsProduct[0] = rsParticipantsProduct.getString(1);
            participantsProduct[1] = rsParticipantsProduct.getString(2);
        }
        LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>> seasons;
        seasons = new LinkedHashMap();
        String infoSeason[] = new String[2];
        Pair<String[], ArrayList<String[]>> season;
        ArrayList<String[]> episodes;
        int lastId = -1;
        while (rsSeasonsProduct.next()) {
            /*Season atributes*/
            int idSeason = rsSeasonsProduct.getInt(1);
            if (idSeason == lastId) {
                addEpisodeToSeason(rsSeasonsProduct, seasons.get(idSeason).getSecond());
            } else {
                infoSeason[0] = rsSeasonsProduct.getString(2);
                infoSeason[1] = rsSeasonsProduct.getString(3);
                episodes = new ArrayList();
                addEpisodeToSeason(rsSeasonsProduct, episodes);
                season = new Pair(infoSeason, episodes);
                seasons.put(idSeason, season);
            }
        }
    }
    private static void addEpisodeToSeason(ResultSet rs, ArrayList<String[]> episodes) throws SQLException {
        Integer id = rs.getInt(4);
        if (id == null) {
        } else {
            String[] infoEpisode = new String[4];
            infoEpisode[0] = rs.getString(4);
            infoEpisode[1] = rs.getString(5);
            infoEpisode[2] = rs.getString(6);
            infoEpisode[3] = rs.getString(7);
            episodes.add(infoEpisode);
            System.out.println("Temporada: " + rs.getInt(1) + "Episodio: " + id);
        }
    }
}


