package LogicClasses;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class Product {
   
    private int idProduct;
    private int idType;
    private int releaseYear;
    private String title;
    private int duration;
    private String trailer;
    private String Synopsis;
    private int price;
    private ArrayList<Pair<Integer, String>> genres;
    private ArrayList<String> statsGenres;
    private ArrayList<Pair<Integer, String>> platforms;
    private ArrayList<Pair<Integer, byte[]>> images;
    private ArrayList<FullReview> fullReviews;
    
    //private int idProduct;
    private LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>> seasons;
    public ArrayList<Pair<Integer,String>> participants;
    
    public Product(int idProduct, String title) {
        this.idProduct = idProduct;
        this.title = title;
        images = new ArrayList<>();
        genres = new ArrayList<>();
    }
    
    public Product(int idProduct, int idType, int releaseYear, String title, int duration,
            String trailer, String Synopsis, int price){
       this.idProduct = idProduct;
       this.idType = idType;
       this.releaseYear = releaseYear;
       this.title = title;
       this.duration = duration;
       this.trailer = trailer;
       this.Synopsis = Synopsis;
       this.price = price;
       seasons = new LinkedHashMap();
       participants = new ArrayList<>();
       images = new ArrayList<>();
       fullReviews = new ArrayList<>();
       genres = new ArrayList<>();
       platforms = new ArrayList();
    }
    public void addSeason(int idSeason, String[] seasonInfo) {
        Pair<String[], ArrayList<String[]>> temp = new Pair<>(seasonInfo, new ArrayList<>());
        seasons.put(idSeason, temp);
    }
    public void addEpisodes(int idSeason, String[] episodeInfo) {
        Pair<String[], ArrayList<String[]>> temp = seasons.get(idSeason);
        temp.getSecond().add(episodeInfo);
    }
    public void addParticipant(int idParticipant, String info){
        participants.add(new Pair<>(idParticipant, info));
    }
    public void addImage(Integer id, byte[] image){
        images.add(new Pair<>(id, image));
    }
    public void addGenre(Integer id, String name){
        genres.add(new Pair<>(id, name));
    }
    public void addPlatform(Integer id, String name){
        platforms.add(new Pair<>(id, name));
    }

    public ArrayList<Pair<Integer, String>> getPlatforms() {
        return platforms;
    }
    public ArrayList<Pair<Integer, byte[]>> getImages(){
        return images;
    }
    public int getIdProduct() {
        return idProduct;
    }

    public ArrayList<Pair<Integer, String>> getGenres() {
        return genres;
    }

    public int getIdType() {
        return idType;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getTitle() {
        return title;
    }

    public int getDuration() {
        return duration;
    }

    public String getTrailer() {
        return trailer;
    }

    public String getSynopsis() {
        return Synopsis;
    }

    public int getPrice() {
        return price;
    }

    public LinkedHashMap<Integer, Pair<String[], ArrayList<String[]>>> getSeasons() {
        return seasons;
    }

    public ArrayList<Pair<Integer, String>> getParticipants() {
        return participants;
    }
    public void deleteParticipant(int idParticipant){
        for(int i = 0; i < participants.size(); i++){
            if (participants.get(i).getFirst() == idParticipant){
                participants.remove(i);
                break;
            }
        }
    }
    public boolean contains(int idParticipant){
        for(int i = 0; i < participants.size(); i++){
            if (participants.get(i).getFirst() == idParticipant){
                return true;
            }
        }
        return false;
    }
    
    public boolean containsGenre(Pair<Integer, String> genre){
        return genres.contains(genre);
    }
    
    public ArrayList<FullReview> getComments(){
        return fullReviews;
    }
    public void addFullReview(FullReview review){
        fullReviews.add(review);
    }
    public void setStatsGenres(ArrayList<String> genres) {
        statsGenres = genres;
    }
    public ArrayList<String> getStatsGenres () {
        return statsGenres;
    }
}



