/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

    

public class Stats {
    private List<Pair<Integer,Product>> products;
    private Map<String,Float> productsStats;
    private List<User> users;
    private Map<String,Integer> usersBySex;
    
    public Stats() {}
    
    public void setProductsStats(Map<String,Float> products) {
        this.productsStats = products;
    }
    
    public void setProducts(List<Pair<Integer,Product>> products) {
        this.products = products;
    }
    
    public void setUsers(List<User> users) {
        this.users = users;
    }
    
    public void setUsersBySex(Map<String,Integer> usersBySex) {
        this.usersBySex = usersBySex;
    }
    
    public Map<String,Float> getProductsStats() {
        return productsStats;
    }
      
    public Map<String,Integer> getUsersBySex() {
        return usersBySex;
    }
       
    public List<Pair<Integer,Product>> getProducts() {
        return products;
    }
    
    public List<User> getUsers() {
        return users;
    }
}


