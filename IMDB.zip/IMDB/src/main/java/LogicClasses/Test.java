/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author kakas
 */
public class Test {
    public static void main(String[] args){
        System.out.println("Hola");
        String jdbcUrl = "jdbc:mariadb://localhost:3307/su";
        String username = "su";
        String password = "su";

        Connection connection = null;
        CallableStatement callableStatement = null;
        ResultSet rs = null;

        try {
            connection = DriverManager.getConnection(jdbcUrl, username, password);

            
            String sql;
            sql = "{CALL getTypesIdents()}";
            callableStatement = connection.prepareCall(sql);
            
            rs = callableStatement.executeQuery();
            while (rs.next()) {
                
                System.out.println("" + rs.getInt(1) + "Nombre: " + rs.getString(2));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
