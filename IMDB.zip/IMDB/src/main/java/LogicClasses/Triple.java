/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

/**
 *
 * @author kakas
 */
public class Triple<F, S, T> extends Pair<F, S> {
    private T third;
    public Triple(F first, S second, T third) {
        super(first, second);
        this.third = third;
    }
    public void setThird(T third){this.third = third;}
    public T getThird(){return third;}
    @Override
    public boolean equals(Object obj){
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Triple other = (Triple) obj;
        return (other.third == this.third && other.getFirst() == this.getFirst()
                && other.getSecond() == this.getSecond());
    }
}
