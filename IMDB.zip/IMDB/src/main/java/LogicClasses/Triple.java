/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

/**
 *
 * @author kakas
 */
public class Triple<F, S, T> extends Pair {
    private T third;
    public Triple(F first, S second, T third) {
        super(first, second);
        this.third = third;
    }
    public void setThird(T third){this.third = third;}
    public T getThird(){return third;}
}
