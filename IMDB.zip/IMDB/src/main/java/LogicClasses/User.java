/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicClasses;

/**
 *
 * @author kakas
 */
public class User {
    private static User instance = null;
    private String userType;
    private int id;
    private String firstName;
    private String firstSurname;
    private String birthdate;
    private byte[] photo;
    private String username;
    private String phoneNumber;
    private String email;
    
    private User(){}
    
    public void UpdateUser(String userType, int id, String firstName, String firstSurname, 
            String birthdate, byte[] photo, String username, String phoneNumber, String email) {
        this.userType = userType;
        this.id = id;
        this.firstName = firstName;
        this.firstSurname = firstSurname;
        this.birthdate = birthdate;
        this.photo = photo;
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public static User getInstance() {
        if (instance == null) {
            instance = new User();
        }
        return instance;
    }
    
    public int getId() {
        return id;
    }

    public byte[] getPhoto() {
        return photo;
    }
}
