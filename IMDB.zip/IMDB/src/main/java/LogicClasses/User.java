package LogicClasses;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kakas
 */
public class User {
    private static User instance = null;
    private String userType;
    private int id;
    private String firstName;
    private String firstSurname;
    private String birthdate;
    private byte[] photo;
    private String username;
    private String phoneNumber;
    private String email;
    private String sex;
    private int idSex;
    private int age;
    private List<int[]> shoppingCart;
    
    public User(){
        shoppingCart = new ArrayList<int[]>();
    }
    
    public void UpdateUser(String username, String birthdate, int idSex, int age) {
        this.username = username;
        this.birthdate = birthdate;
        this.idSex = idSex;
        this.age = age;
    }
    
    public void UpdateUser(String userType, int id, String firstName, String firstSurname, 
            String birthdate, byte[] photo, String username, String phoneNumber, String email, String sex) {
        this.userType = userType;
        this.id = id;
        this.firstName = firstName;
        this.firstSurname = firstSurname;
        this.birthdate = birthdate;
        this.photo = photo;
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.sex = sex;
        //this.identification = identification;
    }

    public String getSex() {
        return sex;
    }
    
    public int getSexId() {
        return idSex;
    }
    
    public int getAge() {
        return age;
    }
    
    public static User getInstance() {
        if (instance == null) {
            instance = new User();
        }
        return instance;
    }
    
    public int getId() {
        return id;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public String getUserType() {
        return userType;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getFirstSurname() {
        return firstSurname;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public String getUsername() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }
    
    public List<int[]> getShoppingCart() {
        return shoppingCart;
    }
    
    public void addToShoppingCart(int idUser, int idProduct, int idPayment) {
        int[] data = {idUser,idProduct,idPayment};
        shoppingCart.add(data);
    } 
    
    public void deleteFromShoppinCart(int idProduct) {
        int i = 0;
        for (int[] product : shoppingCart) {
            if (product[1] == idProduct) {
                break;
            }
            i++;
        }
        shoppingCart.remove(i);
    }
    
    public boolean containsIndex(int idProduct) {
        for (int[] product : shoppingCart) {
            if (product[1]==idProduct) {
                return true;
            }
        }
        return false;
    }
    
    public void clearShoppingCart() {
        shoppingCart.clear();
    }
}
