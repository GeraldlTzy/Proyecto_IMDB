# Proyecto_IMDB
Repositorio del proyecto 2 del curso Bases de Datos 1
